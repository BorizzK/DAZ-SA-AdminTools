//ADMIN MOD

//Based on DaOne's idea and code
//Author: Borizz.K (s-platoon.ru) (aka [G.P.]NOIZZ(MC2))
//ThanX Mizev, DaOne, 123new, NoNameUltima, DrTauren, S4MT3K, ASTRALEX and O.P.G.
	
//Version 14.04.2019.1726 [redesigned for mods/solo]

// I change all CALL_CATEGORY_GAMEPLAY to CALL_CATEGORY_SYSTEM in all .CallLater !!!

/*
//COMMANDS [ for server config additional parameters see next Section ]
//--------------------------------------------------------------------------------------------------------

		--- Commands Help.
		
		//---Saves
		/savepoint <name>					- Save current position to json file //not worjing at this moment
		
		//---Strip
		/strip <name/uid/id>				- strip player //Remove all items
		/drop <name/uid/id>					- drop player all items //Drop all items to ground
		
		//---Teleport commands
		//---Admin teleport
		/tpap <name/uid/id> 				- teleport admin to player (original pos has been saved, teleport back to saved pos by /tpc command)
		/tpto <location name>				- teleport to location (see m_TPLocations array) (original pos has been saved, admin can teleport to saved pos by /tpc command)
		/tpc <x z y> 						- teleport (/tpc x z y) (original pos has been saved, admin can teleport to saved pos by /tpc command)
		
		//---Player teleport
		/tppa <name/uid/id> 				- teleport player to admin (original pos has been saved, admin can teleport to saved pos by /tpback command)
		/tpback <name/uid/id> 				- teleport player back to saved pos if saved pos is present (saved pos present if one time telrported to admin by /tpp or /tpalltome command)
		/tpalltome 							- teleport all players to admin position (original pos has been saved for each teleported player, telepost back all players by /tpalltome command, or /tpback for individual player)
		/tppc <name/uid/id> 				- teleport player to position /tppc name/uid/id 7600 0 9200
		/tppto <location name> 				- teleport player to to city (see m_TPLocations array) (original pos has been saved, can teleport to saved pos by /tpback command) /tppto name/uid/id CityName
		
		//---Spawn object commands
		/spi <class name>					- spawn class name in inventory: /spi akm /spi akm, Mag_AKM_30Rnd, Mag_AKM_Drum75Rnd
		/spg <class name> | <quantity>		- spawn class name to ground: /spg akm | /spg akm, Mag_AKM_30Rnd, Mag_AKM_Drum75Rnd | /spg offroadhatchback | /spg akm 10 (with quantity) 
		/spawn <class name> <z z y>|z 		- spawn class name to admin position, or specified position, or admin position on cpecified altitude: /spawn akm | /spawn akm 6000 0 6000 | /spawn akm 50 (quantity in progress)
		/water 								- spawn waterpump
		/spawncar 							- spawn Niva (offroadhatchback)
		/spawnhatchback						- spawn Niva (offroadhatchback)
		/spawntruck							- spawn V3S (V3S_Cargo)
		/spawnsedan							- spawn Volga (CivilianSedan)
		/refuel								- add fuel to nearest cars / object if object is car
		//---Spawned object commands // for m_SpawnedObject !!!
		/objdel								- delete spawned object
		/objpos								- set spawned object position (cars changes synchronize after relog or if admin seated in the car)
		/objori								- set spawned objectorientation : directrion angleX, angleY (cars changes synchronize after relog or if admin seated in the car)
		/objdir								- set spawned direction (cars changes synchronize after relog or if admin seated in the car)
		/objheal							- set spawned object health 0.001 - 1000
		/objdamag							- set spawned object allow damage false/true
		/objinfo							- get spawned object info: position, orientation, direction, health, network id [low:high] (one per line)
		/objgrav							- set gravity ON / OFF [ /objgravity ]
		//--
		/objtpc								- teleport object to coordinates //in progress
		/objtpto							- teleport object to target place (like /tpto) //in progress
		//--
		/objtptp							- teleport object to player //in progress
		
		//---Object commands
		/check <radius>					 			- Check objects in radius and print info in chat to admin - /check 20 and save objects to objects array for future use in objects commands
		/list										- list objects from objects array saved by /check command
		/del <objectname | num from list>			- /del LargeTent<ae134968> | /del 1 - delete object by name or number from list from /check command results
		/osp <objectname | num from list> <x z y>	- /osp LargeTent<ae134968> 6000 0 6000 | /osp 1 6000 0 6000 - set object position  [ /pos ] (cars changes synchronize after relog or if admin seated in the car)
		/oso <objectname | num from list> <x z y>	- /oso LargeTent<ae134968> 6000 0 6000 | /oso 1 6000 0 6000 - set object orientation [ /ori ] (cars changes synchronize after relog or if admin seated in the car)
		/osd <objectname | num from list> <x z y>	- /osd LargeTent<ae134968> 6000 0 6000 | /osd 1 6000 0 6000 - set object direction [ /dir ] (cars changes synchronize after relog or if admin seated in the car)
		/oinfo <objectname | num from list>			- /info LargeTent<ae134968> | /info 1 - get object properties: position, orientation, direction, health, network id [low:high] (one per line)
		/odamag <objectname | num from list>		- object allow damage false/true
		/oheal <objectname | num from list>			- /oheal LargeTent<ae134968> | /oheal 1 - set object health
		/ograv <objectname | num from list>			- set gravity ON / OFF [ /ogravity ]

		//---Particles
		/grenade <x z y>|<alt>			- spawn rgd grenade effect. /grenade | /grenade 70 | /grenade 5000 0 7000
		
		//---Spawn Subcommands
		/export <name/uid/id> <filename> 	- export current equipment to text file //in progress
		/ammo <name/uid/id>				 	- charge magazine of weapon in hands //in progress
		/loadouts 						 	//in progress
		/loadouttype 					 	//in progress
		/customLoadouts 				 	//in progress
		/spawnarmed 					 	//in progress
		/updateloadouts 				 	//in progress

		//---Jump/Move commands
		/jump <z y z> 					 	- Jump admin from current position to new position with ballistic trajectory with visualisation //in progress //my experiments!
		
		//---Players info commands
		/listplayers 					 	- list players on server [1 string - players count, 2 string - num: nickname, 3 string - num: server id: steam uid, 4 string - num: position coordinates X Z Y]
		/inventory <name/uid/id>		 	- list of inventory of admin or specified player: /inventory | /inventory name/uid/id
		/listids							- list players ids
		/idinfo								- info abour player id
		
		//---Time commands
		/date 							 	- show or change date on server: /date | /date 06.11.2010
		/time 								- show or change time on server: /time | /time 20:00

		//---Time Subcommands
		/nighttime 						 	- switch time to night //constant
		/everningtime  					 	- switch time to everning //constant
		/daytime 						 	- switch time to middle of day //constant
		/morningtime 					 	- switch time to morning //constant
		
		//---Weather commands
		/rain								- /rain | /rain ? | /rain 20 // in progress
		/fog								- /fog | /fog ? | /fog 30 // in progress
		/overcast							- /overcast | /overcast ? | /overcast 55 // in progress
		/windvector							- /windvector | /windvector ? | /windvector 6000 0 6000 // in progress
		/windspeed							- /windspeed | /windspeed ? | windspeed 0.1 // in progress
		/storm								- /storm | /storm 99 // in progress
		/wreset								- /wreset //weather reset to values to values at server startup
		/daytemp							- show world day temperature (???)
		/nighttemp							- show world night temperature (???)

		//---Health / State commands.
		/godmode <name/uid/id>				- enable/disable godmode: /godmode - for current admin, /fullhealth name/uid/id - for specified player //saved in server profile!
		/heal <name/uid/id> 			 	- add health: /heal - for current admin /heal name/uid/id - for specified player

		/fullstamina <name/uid/id> 			- enable/disable constant full stamina: /fullstamina - for current admin, /fullstamina name/uid/id - for specified player //saved in server profile!
		/fullstate <name/uid/id> 			- enable/disable constant full state: /fullstate - for current admin, /fullstate name/uid/id - for specified player //saved in server profile!
		/fullhealth <name/uid/id> 			- enable/disable constant full health: /fullhealth - for current admin, /fullhealth name/uid/id - for specified player //saved in server profile!
		/fullhealthloot <name/uid/id>
		/fullhealthtweapon <name/uid/id>
		/fullammo <name/uid/id>
		/fullstatetweapon <name/uid/id>

		/serverfullstamina 					- enable/disable full stamina for all players //not saved in server profile! //can configured in server.cfg
		/serverfullstate 					- enable/disable full state for all players //can configured in server.cfg
		/serverfullhealth 					- enable/disable full health for all players //can configured in server.cfg
		/serverfullhealthloot 				- enable/disable full health loot for all players //can configured in server.cfg
		/serverfullhealthweapon 			- enable/disable full health weapon in hands for all players //can configured in server.cfg
		/serverfullammo 					- enable/disable full ammo in current weapon in hands for all players //can configured in server.cfg
		/serverfullstateweapon 				- enable/disable full state weapon in hands (health and ammo) for all players //can configured in server.cfg
		
		//---Spectator -  (w - forward, s - backward, q - decrease speed, e - increase speed (increase/decrease speed also can reverse w and s), camera direction changed by mouse movement)
		/testcam <camera type>				- admin testcamera - just for test cameras instance
		/freecam 							- admin freecamera
		/spectator <name/id/uid>			- admin spectrator to player/position //for some reason it doesnt work
		
		//---Testfreeze
		/freeze								- freeze admin player on/off
		
		//---Debug monitor
		/debug 								- enable debug monitor (for new connected players)
		
		//---Kill commands
		/suicide 							- Admin suicide
		/killall 							- Kill all players (excluding AdminPlayer's)
		/kill <name/uid/id> 				- Kill player /kill name/uid/id
		/killzombies <radius>				- Kill all zombies in radius
		/killanimals <radius>				- Kill all animals in radius

		//---Airmove //in progress
		/airmove 						    - Airmove mod start/stop/pause/settings //in progress
		
		//---Chat commands
		/chattest 							- Send test global chat messages - just for test
		/gccd <int>							- Global chat clear delay in milliseconds - just for test
		
		//---Server settings commands
		/respawntime <int>					- Change/show global respawn time in seconds (1-120)
		/spawntime <int>					- Change/show global spawn time in seconds (1-120)
		/servermode 						- Change server mode //can configured in server.cfg //in progress
		/missiontype						- Change mission type //can configured in server.cfg //in progress
		
		//---Server commands!
		/restart 							- Restart server //in progress
		/shutdown 							- Shutdown server //in progress
		/machinerestart						- Restart host server //in progress
		
		//End Commands Help ---
//--------------------------------------------------------------------------------------------------------
*/

/*
//--------------------------------------------------------------------------------------------------------
// server.cfg additional parameters for AdminMod and modded EEKilled / EEHitby (Playerbase class)
// This parameters read from AdminMod (function LoadServerSettings()) and save to text variables with the same name in server profile
// Function LoadServerSettings() called from Init() (You must add call of Init() in yuor init.c ( MissionServer class ) in OnInit function.

//Server settings
//Adds to server.cfg
//===========================================================================================================================================================================================================================================================================================================================
//===========================================================================================================================================================================================================================================================================================================================
//Любые параметры из этого файла можно читать в функциях enscript командой GetGame().ServerConfigGetInt("имя значения");
//Например: int servermod = GetGame().ServerConfigGetInt("servermod");
//В итоге переменная servermod типа int в функции получит значение servermod из этого файла - то есть 1 ))) Удобная штука
//===========================================================================================================================================================================================================================================================================================================================

//Init and Mission / AdminMod
serverMode = 1;							//0 - default, 1 - PVP in Stariy sobor, 2 - PVP on SZ, 3 - PVP in Berezino
missionType = 1;						//0 - default, 1 - PVP, 2 - PVE, 3 - RP, 4 - RolePlay
christmasTreesSpawn = 1;				//Spawn christmas trees - depending on the servermod
buildSpawn = 1;							//Spawn buildings - depending on the servermod
carSpawn = 1;							//Spawn buildings - depending on the servermod
addCarSpawn = 1;						//Spawn additional cars - depending on the servermod

//InGame / Mission
enableCountPlayersMessages		= 1;				//1 = enabled, 0 = disabled // Enable/Disable InGame player counter message in global chat
freqCountPlayersMessages  		= 300;				//Seconds -messages freq
enableCountPlayersMessagesToAdmins = 0;				//1 = enabled, 0 = disabled // Enable/Disable InGame player disconnect message to Admins
enableCountPlayersMessagesToArbitrators = 0;		//1 = enabled, 0 = disabled // Enable/Disable InGame player disconnect message to Arbitrators

enablePlayersConnectMessages	= 1;				//1 = enabled, 0 = disabled // Enable/Disable InGame player connect message in global chat
enablePlayersConnectMessagesToAdmins = 0;			//1 = enabled, 0 = disabled
enablePlayersConnectMessagesToArbitrators = 0;		//1 = enabled, 0 = disabled

enablePlayersDisConnectMessages	= 1;				//1 = enabled, 0 = disabled // Enable/Disable InGame player disconnect message in global chat
enablePlayersDisConnectMessagesToAdmins = 0;	 	//1 = enabled, 0 = disabled
enablePlayersDisConnectMessagesToArbitrators = 0;	//1 = enabled, 0 = disabled

//Playerbase
enableKillsScore = 1; 				// 1 = enabled, 0 = disabled // Enable/Disable kills counters for players
enableDeathesScore = 1; 			// 1 = enabled, 0 = disabled // Enable/Disable die counters for players
enableSaveKills = 1; 				// 1 = enabled, 0 = disabled // Save kills to server profile by player UID // if enabled, count of kills load after each kill, encreases and save to profile
enableSaveDeathes = 1; 				// 1 = enabled, 0 = disabled // Save dies to server profile by player UID // if enabled, count of dies load after each kill, encreases and save to profile
enableKillMessages = 1;				// 1 = enabled, 0 = disabled // Enable/Disable kill messages in global chat
enableKillMessagesToAdmins = 0;		// 1 = enabled, 0 = disabled // Enable/Disable kill messages to Admins
enableKillMessagesToArbitrators	= 0;// 1 = enabled, 0 = disabled // Enable/Disable kill messages to Arbitrators
enableKillLog = 1;					// 1 = enabled, 0 = disabled // Enable/Disable extended kill log in to file //default in $profile: KillLog.log // Uses LogClass server mod.

//Init / Mission / AdminMod
spawnTime = 5;						//Spawn delay timer //Default is 15
//===========================================================================================================================================================================================================================================================================================================================
//===========================================================================================================================================================================================================================================================================================================================
*/

//class MyPlayerBase extends PlayerBase
/*
modded class PlayerBase
{
	override void EEKilled( Object killer )
	{
		Print("::: [AdminMod_Class] ::: [MyPlayerBase] ::: EEKilled : killer = " + killer.ToString());
		super.EEKilled(killer);
	}
}
*/

class AdminMod_Class
{
	//Admin Functions debug
	static bool 					admFuncDebug				= false; //Use /adminfuncdebug in admin console for enable/disable admin functions debug
	
	// ================================================================================================================================================================================
	//Config files
	static string 					m_SettingsPath 				= "$CurrentDir:\\mpmissions\\dayzOffline.chernarusplus\\_CONF\\"; //Folder with config files - .ini or .lst
	static string 					m_AdminsListFile 			= "ADMINS_LIST.lst"; //List of admins UIDs (one uid per string) - if exists only admins with uids in this file can use admin-chat 
	static string 					m_ArbitratorsListFile 		= "ARBITRATORS_LIST.lst"; //List of admins UIDs (one uid per string) - if exists only admins with uids in this file can use admin-chat 
	static string 					m_AdminsPointsListFile		= "ADMINS_SPAWNPOINTS_LIST.lst"; //List of admins points //my idea in progress
	static string 					m_ArbitratorsPointsListFile	= "ARBITRATORS_SPAWNPOINTS_LIST.lst"; //List of admins points //my idea in progress

	// ================================================================================================================================================================================
	//Lists
	static ref map<string,string> 	m_AdminsList;						//AdminsList
	static ref TStringArray 		loadedProfileAdminsListArray;		//Loaded from profile 
	static ref TStringArray 		m_AdminsListArray;					//Template for save to profile and use
	static ref map<string, string> 	m_ArbitratorsList;					//ArbitratorsList
	static ref TStringArray 		loadedProfileArbitratorsListArray;	//Loaded from profile
	static ref TStringArray 		m_ArbitratorsListArray;				//Template for save to profile and use

	//Objects lists
	static ref array<Object> 	 	m_NearestObjectsList;				//Objects list - see /check //nearest_objects
	static ref array<Object> 	 	m_HatchbacksList;					//All hatchbacks on map
	static ref array<Object> 	 	m_SedansList;						//All sedans on map
	
	// ================================================================================================================================================================================
	//Server settings
	//You can define in server.cfg or change default values here
	static int						serverMode									 = 0;  // 0,1 etc..
	static int						missionType									 = 1;  // 0,1 etc...

	static int						freqCountPlayersMessages  					 = 300;  //Seconds
	static int 						freqCountPlayersMessagesAdmArb				 = 60;
	static bool						enableCountPlayersMessages					 = false;
	static bool						enableCountPlayersMessagesToAdmins			 = true;
	static bool						enableCountPlayersMessagesToArbitrators		 = true;
	static bool						enablePlayersConnectMessages				 = false;
	static bool						enablePlayersConnectMessagesToAdmins 		 = true;
	static bool						enablePlayersConnectMessagesToArbitrators 	 = true;
	static bool						enablePlayersDisConnectMessages				 = false;
	static bool						enablePlayersDisConnectMessagesToAdmins 	 = true;
	static bool						enablePlayersDisConnectMessagesToArbitrators = true;
	
	static bool						enableKillsScore							 = false; //0 true (enable), 1 - false (disable)
	static bool						enableDeathesScore							 = false; //0 or 1
	static bool						enableSaveKills								 = false; //0 or 1
	static bool						enableSaveDeathes							 = false; //0 or 1
	static bool						enableKillMessages							 = false; //0 or 1
	static bool						enableKillMessagesToAdmins					 = true;  //0 or 1
	static bool						enableKillMessagesToArbitrators				 = true;  //0 or 1
	static bool						enableKillLog								 = true;  //0 or 1
	static string					killLogPath									 = "$profile:"; //Server profile folder
	static string					killLogName 								 = "KillLog.log";

	static int						spawnTime									 = 5;
	static int						respawnTime									 = 5;

	// ================================================================================================================================================================================
	//Connections
 	static bool						m_connect_new_Enable	= true; //Enable/disable connect NEW players and kick after connect (without create character)
	static bool						m_connect_Enable		= true; //Enable/disable connect players and kick after connect
	static ref TStringArray			m_Disabled_UIDS; 				//Manually banned players by admin
	static ref TStringArray			m_Enabled_UIDS;	 				//Manually unbanned players by admin

	// ================================================================================================================================================================================
	//Players
	static bool						m_AdminFullStamina    		= false;
	static bool 					m_AdminFullState     		= false;
	static bool						m_AdminFullHealth			= false;
	static bool						m_AdminFullHealthLoot   	= false;
	static bool 					m_AdminFullHealthWeapon 	= false;
	static bool						m_AdminFullAmmo				= false;
	static bool 					m_AdminFullStateWeapon  	= false;
	
	static bool						m_ServerFullStamina    		= false;
	static bool						m_ServerFullState   		= false;
	static bool						m_ServerFullHealth    		= false;
	static bool						m_ServerFullHealthLoot		= false;
	static bool						m_ServerFullHealthWeapon	= false;
	static bool						m_ServerFullAmmo			= false;
	static bool						m_ServerFullStateWeapon		= false;
	
	static bool						m_FullStamina    			= false;
	static bool 					m_FullState     			= false;
	static bool						m_FullHealth				= false;
	static bool						m_FullHealthLoot    		= false;
	static bool 					m_FullHealthWeapon     		= false;
	static bool						m_FullAmmo					= false;
	static bool 					m_FullStatethWeapon    		= false;
	
	static ref array<string> 		m_GodModeList 				= new array<string>;
	static ref array<string> 		m_FullStaminaList 			= new array<string>;
	static ref array<string> 		m_FullStateList 			= new array<string>;
	static ref array<string> 		m_FullHealthList 			= new array<string>;
	static ref array<string>		m_FullHealthLootList		= new array<string>;
	static ref array<string>		m_FullHealthWeaponList		= new array<string>;
	static ref array<string>		m_FullAmmoList				= new array<string>;
	static ref array<string>		m_FullStateWeaponList		= new array<string>;
	
	// ================================================================================================================================================================================
	//AdminMod settings
	static ref map<string,int> 		m_AdminChatCommands;	//Admin commands
	static ref map<string, vector>	m_TPLocations;			//Teleport Locations
	static ref TStringArray 		ZombiesList; 			//Zombies

	//AdminMod flags
	static bool 					m_TpAllToMe				= false;
	
	//Teleport
	static vector					m_tpCorrect			= "0.5 0 0.5";

	//Freecams / Debug
	static string					o_FreeCamera			= "FreeCamera";
	static string					o_SpectatorCamera		= "DayZSpectator";
	static bool						m_TestCamera			= false;
	static bool 					m_FreeCamera 			= false;
	static bool 					m_Spectator 			= false;
	
	static bool						m_Freezed				= false;
	
	//Debug Monitor
    static bool						m_IsDebugRunning 		= false;
	
	//Gravity
	static bool						m_Gravity				= true; //BY DEFAULT

	//Moving objects
	static bool 					m_MoveObject			= false;
	static Object					m_MovedObject;
	static vector					m_MovedObjectStartPos;
	static vector					m_MovedObjectFinishPos;
	
	//Spawned objects
	static Object					m_SpawnedObject			= NULL;
	static Object					MyWaterPump				= NULL;

	//Spawn object max qty
	static int						m_MaxSpgQty					= 10; //default

	//Moving players
	static bool 					m_MovePlayer			= false;
	static PlayerBase				m_MovedPlayer;
	static vector					m_MovedPlayerStartPos;
	static vector					m_MovedPlayerFinishPos;
	
	//Hide Admin
	static bool						m_AdminHidden			= false;
	static bool						m_AdminHoldPosition		= false;
	static vector					m_AdminInitPos;
	static vector					m_AdminHeldPos;
	static int						m_AdminHoldPosDelay		= 4000;
	static EntityAI					m_hidderSpawn			= NULL;
	static string					m_hidderObj				= "Rag"; //"Land_Misc_Toilet_Mobile"; //"Land_Water_Station"; //"Land_Shed_W5"; //hiding object
	static vector					m_hideAltCorr			= "0 1 0"; //Height offset relative to hiding object
	static vector					m_hideSpecCorr			= "-5 -5 -5"; //Offset relative to spectating object
	static float					m_hidderAlt				= 750; //meters
	static int						m_specCamDelay			= 2000;
	static int						m_freeCamDelay			= 2000;
	static int						m_hidderMoveDelay		= 2000;
	static int						m_hidderRemoveDelay		= 4000;

	//Current Admin
    static PlayerBase 				AdminPlayer;
	static Object					AdminObject;
    static PlayerIdentity 			AdminIdentity;
	static EntityAI 				AdminEntity;
	static Man						AdminMan;
	static string 					AdminNAME, AdminUID, GUID, PlayerUID, NewAdminUID;
	static float					m_AdminBodyMass = 1.1;
	
	//Admin tool Exec flag
	static bool 					adm_ChatRequestExec 	= false; //OnEvent working indicator
	
	//Admin tool params
	static int 						maxCheckRadius 			= 100; //used in /check command
	static float					msgDelay 				= 2;  //used in /check and /listplayers commands
	static float					m_GChatClear_delay		= 3;  //used in call GlobalChatClear after admin command processing

	static int 						maxKillRadius 			= 100; //used in /killzombies and /killanimals command
	
	static float 					srv_Fps;
	static int						ontick_Counter			= 0;
	
	// ================================================================================================================================================================================
	//For AirMove mod conrol!
	//AirMove mod enable/disable / settings
	static bool						m_AirMove_Enable					= true;
	static bool						m_AirMove_Reset						= false;
	static bool						m_AirMove_Edit						= false;
	static bool						m_AirMove_Change					= false;
	static float					m_AirMove_AirPlaneSpeed				= 0.15;
	static float					m_AirMove_AirPlaneAltitude			= 500;
	static float					m_AirMove_AirPlaneStartSpawnTime	= 120; //How much time will pass from the server start to first AirMove
	static float					m_AirMove_AirPlaneSpawnTimer		= 0;
	//AirMove mod enable/disable / settings
	// ================================================================================================================================================================================

	// ================================================================================================================================================================================
	//For AirDrop mod conrol!
	//AirDrop mod enable/disable / settings
	static bool						m_AirDrop_Enable					= true;
	static bool						m_AirDrop_Reset						= false;
	static bool						m_AirDrop_Edit						= false;
	static bool						m_AirDrop_Change					= false;
	static float					m_AirDrop_AirPlaneSpeed				= 0.15;
	static float					m_AirDrop_AirPlaneAltitude			= 500;
	static float					m_AirDrop_AirPlaneStartSpawnTime	= 120; //How much time will pass from the server start to first AirDrop
	static float					m_AirDrop_AirPlaneSpawnTimer		= 0;
	//AirDrop mod enable/disable / settings
	// ================================================================================================================================================================================

	// ================================================================================================================================================================================
	void AdminMod_Class()
	{
		Print("::: [AdminMod_Class] ::: Init :::");
	}

	void ~AdminMod_Class()
	{
		if (m_AdminHidden || m_AdminHoldPosition)
		{
			AdminPlayerHide(false,"",NULL);
			m_AdminHoldPosition = false;
			m_AdminHidden = false;
			if (m_hidderSpawn) GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(DelayedRemoveEntity, 1000, false, m_hidderSpawn);
		}
		Print("::: [AdminMod_Class] ::: UnInit.");
	}
	// ================================================================================================================================================================================
	
	//============================================================================================================================================
	//Class setup begin
	
	//Call this function from OnInit() function in your mission class for AdminMod initialization: AdminMod_Class.Init();
	static void Init()
	{
		Print("::: [AdminMod_Class] ::: Init() Begin :::");
		
		LoadServerSettings();
		LoadAdminsList();
		LoadArbitratorsList();
		LoadCommandsSettings();
		LoadTPLocations();
		LoadFullStatesLists();
		LoadZombiesList();
		
		if (enableCountPlayersMessages || enableCountPlayersMessagesToAdmins || enableCountPlayersMessagesToArbitrators)
		{
			Print("::: [AdminMod_Class] ::: AdminModInit() ::: Enabling CountPlayersMessage ::: freqCountPlayersMessages = " + freqCountPlayersMessages);
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(CountPlayersMessage,(freqCountPlayersMessages * 1000),true); // sec * in milliseconds
		}

		Print("::: [AdminMod_Class] ::: Init() End :::");
	}

	static void LoadFullStatesLists()
	{
		Print("::: [AdminMod_Class] ::: LoadFullStatesLists() :::"); //in progress
		//Load m_FullStaminaList
		m_FullStaminaList = {};
		//Load m_FullStateList
		m_FullStateList = {};
		//Load m_FullHealthList
		m_FullHealthList = {};
	}

	//!====================================================================================================================================================================================!
	//Read server.cfg
	static void LoadServerSettings()
	{
		//Server mode
		if (GetGame().ServerConfigGetInt("serverMode")) 
		{ 
			serverMode = GetGame().ServerConfigGetInt("serverMode");
		}
		else
		{
			serverMode = 0;
		}
		GetGame().SetProfileString("serverMode",serverMode.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : serverMode = " + serverMode);
		
		if (GetGame().ServerConfigGetInt("missionType")) 
		{ 
			missionType = GetGame().ServerConfigGetInt("missionType");
		} 
		else
		{
			missionType = 0;
		}
		GetGame().SetProfileString("missionType",missionType.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : missionType = " + missionType);
		//Server mode

		//Additional spawns

		//Additional spawns

		//InGame messages 
		// ================================================================================================================================================================================
		//Players count messages
		if (GetGame().ServerConfigGetInt("enableCountPlayersMessages")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableCountPlayersMessages") == 1)
			{
				enableCountPlayersMessages = true;
			}
			else if (GetGame().ServerConfigGetInt("enableCountPlayersMessages") == 0)
			{
				enableCountPlayersMessages = false;
			}
		}
		GetGame().SetProfileString("enableCountPlayersMessages",enableCountPlayersMessages.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableCountPlayersMessages = " + enableCountPlayersMessages.ToString());
		
		//Players count messages frequency
		if (GetGame().ServerConfigGetInt("freqCountPlayersMessages")) 
		{ 
			freqCountPlayersMessages = GetGame().ServerConfigGetInt("freqCountPlayersMessages");
		}
		GetGame().SetProfileString("freqCountPlayersMessages",freqCountPlayersMessages.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : freqCountPlayersMessages = " + freqCountPlayersMessages.ToString());

		//Players count messages to Admins
		if (GetGame().ServerConfigGetInt("enableCountPlayersMessagesToAdmins")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableCountPlayersMessagesToAdmins") == 1)
			{
				enableCountPlayersMessagesToAdmins = true;
				enableCountPlayersMessages = false;
				freqCountPlayersMessages = freqCountPlayersMessagesAdmArb;
			}
			else if (GetGame().ServerConfigGetInt("enableCountPlayersMessagesToAdmins") == 0)
			{
				enableCountPlayersMessagesToAdmins = false;
			}
		}
		GetGame().SetProfileString("enableCountPlayersMessagesToAdmins",enableCountPlayersMessagesToAdmins.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableCountPlayersMessagesToAdmins = " +enableCountPlayersMessagesToAdmins.ToString());

		//Players count messages to Arbitrators
		if (GetGame().ServerConfigGetInt("enableCountPlayersMessagesToArbitrators")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableCountPlayersMessagesToArbitrators") == 1)
			{
				enableCountPlayersMessagesToArbitrators = true;
				enableCountPlayersMessages = false;
				freqCountPlayersMessages = freqCountPlayersMessagesAdmArb;
			}
			else if (GetGame().ServerConfigGetInt("enableCountPlayersMessagesToArbitrators") == 0)
			{
				enableCountPlayersMessagesToArbitrators = false;
			}
		}
		GetGame().SetProfileString("enableCountPlayersMessagesToArbitrators",enableCountPlayersMessagesToArbitrators.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableCountPlayersMessagesToArbitrators = " + enableCountPlayersMessagesToArbitrators.ToString());
		// ================================================================================================================================================================================

		// ================================================================================================================================================================================
		//Players connect messages
		if (GetGame().ServerConfigGetInt("enablePlayersConnectMessages")) 
		{ 
			if (GetGame().ServerConfigGetInt("enablePlayersConnectMessages") == 1)
			{
				enablePlayersConnectMessages = true;
			}
			else if (GetGame().ServerConfigGetInt("enablePlayersConnectMessages") == 0)
			{
				enablePlayersConnectMessages = false;
			}
		}
		GetGame().SetProfileString("enablePlayersConnectMessages",enablePlayersConnectMessages.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enablePlayersConnectMessages = " + enablePlayersConnectMessages.ToString());

		//Players connect messages to Admins
		if (GetGame().ServerConfigGetInt("enablePlayersConnectMessagesToAdmins")) 
		{ 
			if (GetGame().ServerConfigGetInt("enablePlayersConnectMessagesToAdmins") == 1)
			{
				enablePlayersConnectMessagesToAdmins = true;
				enablePlayersConnectMessages = false;
			}
			else if (GetGame().ServerConfigGetInt("enablePlayersConnectMessagesToAdmins") == 0)
			{
				enablePlayersConnectMessagesToAdmins = false;
			}
		}
		GetGame().SetProfileString("enablePlayersConnectMessagesToAdmins",enablePlayersConnectMessagesToAdmins.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enablePlayersConnectMessagesToAdmins = " + enablePlayersConnectMessagesToAdmins.ToString());

		//Players connect messages to Arbitrators
		if (GetGame().ServerConfigGetInt("enablePlayersConnectMessagesToArbitrators")) 
		{ 
			if (GetGame().ServerConfigGetInt("enablePlayersConnectMessagesToArbitrators") == 1)
			{
				enablePlayersConnectMessagesToArbitrators = true;
				enablePlayersConnectMessages = false;
			}
			else if (GetGame().ServerConfigGetInt("enablePlayersConnectMessagesToArbitrators") == 0)
			{
				enablePlayersConnectMessagesToArbitrators = false;
			}
		}
		GetGame().SetProfileString("enablePlayersConnectMessagesToArbitrators",enablePlayersConnectMessagesToArbitrators.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enablePlayersConnectMessagesToArbitrators = " + enablePlayersConnectMessagesToArbitrators.ToString());
		// ================================================================================================================================================================================

		// ================================================================================================================================================================================
		//Players disconnect messages
		if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessages")) 
		{ 
			if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessages") == 1)
			{
				enablePlayersDisConnectMessages = true;
			}
			else if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessages") == 0)
			{
				enablePlayersDisConnectMessages = false;
			}
		}
		GetGame().SetProfileString("enablePlayersDisConnectMessages",enablePlayersDisConnectMessages.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enablePlayersDisConnectMessages = " + enablePlayersDisConnectMessages.ToString());

		//Players disconnect messages to Admins
		if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessagesToAdmins")) 
		{ 
			if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessagesToAdmins") == 1)
			{
				enablePlayersDisConnectMessagesToAdmins = true;
				enablePlayersDisConnectMessages = false;
			}
			else if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessagesToAdmins") == 0)
			{
				enablePlayersDisConnectMessagesToAdmins = false;
			}
		}
		GetGame().SetProfileString("enablePlayersDisConnectMessagesToAdmins",enablePlayersDisConnectMessagesToAdmins.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enablePlayersDisConnectMessagesToAdmins = " + enablePlayersDisConnectMessagesToAdmins.ToString());

		//Players disconnect messages to Arbitrators
		if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessagesToArbitrators")) 
		{ 
			if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessagesToArbitrators") == 1)
			{
				enablePlayersDisConnectMessagesToArbitrators = true;
				enablePlayersDisConnectMessages = false;
			}
			else if (GetGame().ServerConfigGetInt("enablePlayersDisConnectMessagesToArbitrators") == 0)
			{
				enablePlayersDisConnectMessagesToArbitrators = false;
			}
		}
		GetGame().SetProfileString("enablePlayersDisConnectMessagesToArbitrators",enablePlayersDisConnectMessagesToArbitrators.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enablePlayersDisConnectMessagesToArbitrators = " + enablePlayersDisConnectMessagesToArbitrators.ToString());
		// ================================================================================================================================================================================
		//InGame messages

		// ================================================================================================================================================================================
		//Kill scores, messages and log //EEKilled //PlayerBase Class
		//Kills Score
		if (GetGame().ServerConfigGetInt("enableKillsScore")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableKillsScore") == 1)
			{
				enableKillsScore = true;
			}
			else if (GetGame().ServerConfigGetInt("enableKillsScore") == 0)
			{
				enableKillsScore = false;
			}
		}
		GetGame().SetProfileString("enableKillsScore",enableKillsScore.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableKillsScore = " + enableKillsScore.ToString());
		//Kills Score
		
		//Deathes Score
		if (GetGame().ServerConfigGetInt("enableDeathesScore")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableDeathesScore") == 1)
			{
				enableDeathesScore = true;
			}
			else if (GetGame().ServerConfigGetInt("enableDeathesScore") == 0)
			{
				enableDeathesScore = false;
			}
		}
		GetGame().SetProfileString("enableDeathesScore",enableDeathesScore.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableDeathesScore = " + enableDeathesScore.ToString());
		//Deathes Score
		// ================================================================================================================================================================================
		
		// ================================================================================================================================================================================
		//Save kills
		if (GetGame().ServerConfigGetInt("enableSaveKills")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableSaveKills") == 1)
			{
				enableSaveKills = true;
			}
			else if (GetGame().ServerConfigGetInt("enableSaveKills") == 0)
			{
				enableSaveKills = false;
			}
		}
		GetGame().SetProfileString("enableSaveKills",enableSaveKills.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableSaveKills = " + enableSaveKills.ToString());
		//Save kills
		
		//Save deathes
		if (GetGame().ServerConfigGetInt("enableSaveDeathes")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableSaveDeathes") == 1)
			{
				enableSaveDeathes = true;
			}
			else if (GetGame().ServerConfigGetInt("enableSaveDeathes") == 0)
			{
				enableSaveDeathes = false;
			}
		}
		GetGame().SetProfileString("enableSaveDeathes",enableSaveDeathes.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableSaveDeathes = " + enableSaveDeathes.ToString());
		//Save deathes
		// ================================================================================================================================================================================

		// ================================================================================================================================================================================
		//Kill messages
		if (GetGame().ServerConfigGetInt("enableKillMessages"))
		{ 
			if (GetGame().ServerConfigGetInt("enableKillMessages") == 1)
			{
				enableKillMessages = true;
			}
			else if (GetGame().ServerConfigGetInt("enableKillMessages") == 0)
			{
				enableKillMessages = false;
			}
		}
		GetGame().SetProfileString("enableKillMessages",enableKillMessages.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableKillMessages = " + enableKillMessages.ToString());
		//Kill messages

		//Kill messages to Admins
		if (GetGame().ServerConfigGetInt("enableKillMessagesToAdmins"))
		{ 
			if (GetGame().ServerConfigGetInt("enableKillMessagesToAdmins") == 1)
			{
				enableKillMessagesToAdmins = true;
			}
			else if (GetGame().ServerConfigGetInt("enableKillMessagesToAdmins") == 0)
			{
				enableKillMessagesToAdmins = false;
			}
		}
		GetGame().SetProfileString("enableKillMessagesToAdmins",enableKillMessagesToAdmins.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableKillMessagesToAdmins = " + enableKillMessagesToAdmins.ToString());
		//Kill messages to Admins

		//Kill messages to Arbitrators
		if (GetGame().ServerConfigGetInt("enableKillMessagesToArbitrators"))
		{ 
			if (GetGame().ServerConfigGetInt("enableKillMessagesToArbitrators") == 1)
			{
				enableKillMessagesToArbitrators = true;
			}
			else if (GetGame().ServerConfigGetInt("enableKillMessagesToArbitrators") == 0)
			{
				enableKillMessagesToArbitrators = false;
			}
		}
		GetGame().SetProfileString("enableKillMessagesToArbitrators",enableKillMessagesToArbitrators.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableKillMessagesToArbitrators = " + enableKillMessagesToArbitrators.ToString());
		//Kill messages to Arbitrators
		// ================================================================================================================================================================================

		// ================================================================================================================================================================================
		//Kill Log (need LogClass or AdminMod_LogClass)
		if (GetGame().ServerConfigGetInt("enableKillLog")) 
		{ 
			if (GetGame().ServerConfigGetInt("enableKillLog") == 1)
			{
				enableKillLog = true;
			}
			else
			{
				enableKillLog = false;
			}
		} 
		GetGame().SetProfileString("enableKillLog",enableKillLog.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : enableKillLog = " + enableKillLog.ToString());
		//Kill Log (need LogClass or AdminMod_LogClass)
		//Kill scores, messages and log //EEKilled //PlayerBase Class
		// ================================================================================================================================================================================
		
		// ================================================================================================================================================================================
		//Spawn and respawn times
		if (GetGame().ServerConfigGetInt("spawnTime")) 
		{ 
			spawnTime = GetGame().ServerConfigGetInt("spawnTime");
		} 
		GetGame().SetProfileString("spawnTime",spawnTime.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : spawnTime = " + spawnTime);
		
		if (GetGame().ServerConfigGetInt("respawnTime")) 
		{ 
			respawnTime = GetGame().ServerConfigGetInt("respawnTime");
		} 
		GetGame().SetProfileString("spawnTime",respawnTime.ToString());
		Print("::: [AdminMod_Class] ::: Read server config : respawnTime = " + respawnTime);
		//Spawn and respawn times
		// ================================================================================================================================================================================

		// ================================================================================================================================================================================
		//Stamina
		if (GetGame().ServerConfigGetInt("ServerFullStamina"))
		{
			if (GetGame().ServerConfigGetInt("ServerFullStamina") == 1 )
			{ 
				m_ServerFullStamina = true;
				g_Game.SetProfileString("ServerFullStamina","true");
			}
			else if (GetGame().ServerConfigGetInt("ServerFullStamina") == 0 )
			{
				m_ServerFullStamina = false;
				g_Game.SetProfileString("ServerFullStamina","false");
			}
		}
		Print("::: [AdminMod_Class] ::: Read server config : m_ServerFullStamina = " + m_ServerFullStamina.ToString());
		//Stamina
		// ================================================================================================================================================================================
	}
	//!====================================================================================================================================================================================!

	// ================================================================================================================================================================================
	//Read Admins list
	static void LoadAdminsList()
	{
		Print("::: [AdminMod_Class] ::: LoadAdminsList() :::");
		m_AdminsList 					= new map<string, string>;	//AdminsList //defined in class
		m_AdminsListArray 				= new TStringArray;
		loadedProfileAdminsListArray	= new TStringArray;

		array<string> 		f_Line;
		

		g_Game.GetProfileStringList("adminsList",loadedProfileAdminsListArray);
		if (loadedProfileAdminsListArray.Count() >0 )
		{
			Print("::: [AdminMod_Class] ::: Debug: Loaded from server profile Admins list count: " + loadedProfileAdminsListArray.Count());
			for (int i = 0; i < loadedProfileAdminsListArray.Count(); i++)
			{
				Print("::: [AdminMod_Class] ::: Debug: Loaded from server profile Admin: " + loadedProfileAdminsListArray.Get(i));
			}
		}
		loadedProfileAdminsListArray.Clear();
		
		Print("::: [AdminMod_Class] ::: OpenFile: " + m_SettingsPath + m_AdminsListFile +" :::");
		FileHandle file = OpenFile(m_SettingsPath + m_AdminsListFile, FileMode.READ);
		if (file != 0)
		{ 
			string line_content = "";
			while ( FGets(file, line_content) >= 0)    
			{
				f_Line = new array<string>;
				line_content.Split(" ",f_Line);
				
				if (f_Line.Count() > 0 && f_Line.Get(0).Length() == 17)
				{
					if (m_AdminsList.Count() > 0 && m_AdminsList.Contains(f_Line.Get(0)))
					{
						Print("::: [AdminMod_Class] ::: Duplicated UID " + f_Line.Get(0) + " in AdminsList file. Check file: " +  m_SettingsPath + m_AdminsListFile);
					}
					else
					{
						m_AdminsList.Insert(f_Line.Get(0), "null");
						m_AdminsListArray.Insert(f_Line.Get(0));
						Print("::: [AdminMod_Class] ::: Add Admin: " + f_Line.Get(0) + " to admins List.");
					}
				}
				else
				{
					Print("::: [AdminMod_Class] ::: Error loading AdminsList. Check file: " +  m_SettingsPath + m_AdminsListFile);
				}
			}
			if (m_AdminsListArray.Count() > 0)
			{
				g_Game.SetProfileStringList("adminsList",m_AdminsListArray);
				Print("::: [AdminMod_Class] ::: Server Profile Admins List Array count: " + m_AdminsListArray.Count());
				for ( i = 0; i < m_AdminsListArray.Count(); i++ )
				{
					Print("::: [AdminMod_Class] ::: Add Admin to server Profile: " + m_AdminsListArray.Get(i));
				}

			}
			else {
				g_Game.SetProfileStringList("adminsList",{""});
			}
			CloseFile(file);
			g_Game.SaveProfile();
		}
		else
		{
			Print("::: [AdminMod_Class] ::: OpenFile error: " + m_SettingsPath + m_AdminsListFile + " :::");
		}

		//debug
		g_Game.GetProfileStringList("adminsList",loadedProfileAdminsListArray);
		if (loadedProfileAdminsListArray.Count() >0 )
		{
			Print("::: [AdminMod_Class] ::: Debug: ReLoaded from server profile Admins list count: " + loadedProfileAdminsListArray.Count());
			for (i = 0; i < loadedProfileAdminsListArray.Count(); i++)
			{
				Print("::: [AdminMod_Class] ::: Debug: ReLoad from server profile Admin: " + loadedProfileAdminsListArray.Get(i));
			}
		}
		//debug

		Print("::: [AdminMod_Class] ::: Admins list count: " + m_AdminsList.Count() + " :::");
	}
	// ================================================================================================================================================================================
	
	// ================================================================================================================================================================================
	//Read Arbitrators list
	static void LoadArbitratorsList()
	{
		Print("::: [AdminMod_Class] ::: LoadArbitratorsList() :::");
		m_ArbitratorsList 					= new map<string, string>;	//ArbitratorsList //defined in class
		m_ArbitratorsListArray 				= new TStringArray;
		loadedProfileArbitratorsListArray 	= new TStringArray;
		
		array<string> 		f_Line;
		
		g_Game.GetProfileStringList("arbitratorsList",loadedProfileArbitratorsListArray);
		if (loadedProfileArbitratorsListArray.Count() >0 )
		{
			Print("::: [AdminMod_Class] ::: Debug: Loaded from server profile Arbitrators list count: " + loadedProfileArbitratorsListArray.Count());
			for (int i = 0; i < loadedProfileArbitratorsListArray.Count(); i++)
			{
				Print("::: [AdminMod_Class] ::: Debug: Load from server profile Arbitrator: " + loadedProfileArbitratorsListArray.Get(i));
			}
		}
		loadedProfileArbitratorsListArray.Clear();
		
		Print("::: [AdminMod_Class] ::: OpenFile: " + m_SettingsPath + m_ArbitratorsListFile +" :::");
		FileHandle file = OpenFile(m_SettingsPath + m_ArbitratorsListFile, FileMode.READ);
		if (file != 0)
		{ 
			string line_content = "";
			while ( FGets(file, line_content) >= 0)    
			{
				f_Line = new array<string>;
				line_content.Split(" ",f_Line);
				
				if (f_Line.Count() > 0 && f_Line.Get(0).Length() == 17)
				{
					if (m_ArbitratorsList.Count() > 0 && m_ArbitratorsList.Contains(f_Line.Get(0)))
					{
						Print("::: [AdminMod_Class] ::: Duplicated UID " + f_Line.Get(0) + " in ArbitratorsList file. Check file: " +  m_SettingsPath + m_ArbitratorsListFile);
					}
					else
					{
						m_ArbitratorsList.Insert(f_Line.Get(0), "null");
						m_ArbitratorsListArray.Insert(f_Line.Get(0));
						Print("::: [AdminMod_Class] ::: Add Arbitrator: " + f_Line.Get(0) + " to arbitrators List.");
					}
				}
				else
				{
					Print("::: [AdminMod_Class] ::: Error loading ArbitratorsList. Check file: " +  m_SettingsPath + m_ArbitratorsListFile);
				}
			}
			if (m_ArbitratorsListArray.Count() > 0)
			{
				g_Game.SetProfileStringList("arbitratorsList",m_ArbitratorsListArray);
				Print("::: [AdminMod_Class] ::: Server Profile Arbitrators List Array count: " + m_ArbitratorsListArray.Count());
				for ( i = 0; i < m_ArbitratorsListArray.Count(); i++ )
				{
					Print("::: [AdminMod_Class] ::: Add Arbitrator to server Profile:: " + m_ArbitratorsListArray.Get(i));
				}
			}
			else {
				g_Game.SetProfileStringList("arbitratorsList",{""});
			}
			CloseFile(file);
			g_Game.SaveProfile();
		}
		else
		{
			Print("::: [AdminMod_Class] ::: OpenFile error: " + m_SettingsPath + m_ArbitratorsListFile + " :::");
		}

		//debug
		g_Game.GetProfileStringList("arbitratorsList",loadedProfileArbitratorsListArray);
		if (loadedProfileArbitratorsListArray.Count() >0 )
		{
			Print("::: [AdminMod_Class] ::: Debug: ReLoaded from server profile Arbitrators list count: " + loadedProfileArbitratorsListArray.Count());
			for (i = 0; i < loadedProfileArbitratorsListArray.Count(); i++)
			{
				Print("::: [AdminMod_Class] ::: Debug: ReLoad from server profile Arbitrator: " + loadedProfileArbitratorsListArray.Get(i));
			}
		}
		//debug
		
		Print("::: [AdminMod_Class] ::: Arbitrators list count: " + m_ArbitratorsList.Count() + " :::");
	}
	// ================================================================================================================================================================================
	
	// ================================================================================================================================================================================
	static void CheckPlayer(PlayerBase Player)
	{
		string UID = Player.GetIdentity().GetPlainId();
		
		/** //Template for usage in another scripts!
		TStringArray m_AdminsListArray 		= new TStringArray;
		TStringArray m_ArbitratorsListArray 	= new TStringArray;
		g_Game.GetProfileStringList("adminsList",m_AdminsListArray);
		g_Game.GetProfileStringList("arbitratorsList",m_ArbitratorsListArray);
		**/ //Template for usage in another scripts!

		string GodMode = "";
		g_Game.GetProfileString("GodMode"+UID,GodMode);
		if (GodMode == "true")
		{
			Player.SetAllowDamage(false); //GodMode
			Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " in GodMode! :::");
		}
		else
		{
			Player.SetAllowDamage(true); //Not GodMode
		}
		
		if (m_AdminsList.Count() > 0 && m_AdminsList.Contains(UID))
		{
			Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " in m_AdminsList :::");
			AdminLoginResetPosition(Player);
		}
		else
		{
			//Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " Not in m_AdminsList :::");
		}
		if ( m_AdminsListArray.Count() > 0 && m_AdminsListArray.Find(UID) >= 0 )
		{
			//Player.Is_Admin = true;
			Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " Is_Admin :::");
		} 
		else
		{
			//Player.Is_Admin = false;
			//Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " Not Is_Admin :::");
		}
		if ( m_ArbitratorsListArray.Count() > 0 && m_ArbitratorsListArray.Find(UID) >= 0 )
		{
			//Player.Is_Arbitrator = true;
			Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " Is_Arbitrator :::");
		}
		else
		{
			//Player.Is_Arbitrator = false;
			//Print("::: [AdminMod_Class] ::: CheckPlayer ::: Player: " + UID + " Not Is_Arbitrator :::");
		}
	}
	// ================================================================================================================================================================================
	
	// ================================================================================================================================================================================
	static void CountPlayersMessage()
	{
		//ServerDebugFps(); //debug
		
		array<Man> players = new array<Man>; 
		GetGame().GetPlayers( players ); 
		if (players.Count() > 0)
		{
			private string Message = "Players online: [" + players.Count() + "]";
			if ( enableCountPlayersMessages )
			{
				GetGame().ChatPlayer(Message);
				Print("::: [AdminMod_Class] ::: CountPlayersMessage() ::: enableCountPlayersMessages: " + Message);
			}
			else if ( (enableCountPlayersMessagesToAdmins && m_AdminsListArray.Count() >= 0) || (enableCountPlayersMessagesToArbitrators && m_ArbitratorsListArray.Count() >= 0) )
			{
				for ( int i = 0; i < players.Count(); ++i )
				{
					PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
					if (selectedPlayer && selectedPlayer.IsAlive() && selectedPlayer.GetIdentity())
					{
						PlayerIdentity selectedIdentity = selectedPlayer.GetIdentity();
						Param1<string> Msgparam = new Param1<string>( Message );
						if ( m_AdminsListArray.Find(selectedIdentity.GetPlainId()) >= 0 || m_ArbitratorsListArray.Find(selectedIdentity.GetPlainId()) >= 0 )
						{
							GetGame().RPCSingleParam(selectedPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, selectedIdentity);
							Print("::: [AdminMod_Class] ::: CountPlayersMessage() ::: enableCountPlayersMessagesToAdmins || enableCountPlayersMessagesToArbitrators: " + selectedIdentity.GetName() + ": " + Message);
						}
					}
				}
			}
		}
	}
	// ================================================================================================================================================================================

	// ================================================================================================================================================================================
	static void ConnectPlayersMessage(PlayerIdentity connectedIdentity)
	{
		//ServerDebugFps(); //debug
		
		array<Man> players = new array<Man>; 
		GetGame().GetPlayers( players ); 
		if (players.Count() > 0)
		{
			private string Message = "Player " + connectedIdentity.GetName() + " connected";
			if ( enablePlayersConnectMessages )
			{
				GetGame().ChatPlayer(Message);
			}
			else if ( (enablePlayersConnectMessagesToAdmins && m_AdminsListArray.Count() > 0) || (enablePlayersConnectMessagesToArbitrators && m_ArbitratorsListArray.Count() > 0) )
			{
				for ( int i = 0; i < players.Count(); ++i )
				{
					PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
					if (selectedPlayer && selectedPlayer.GetIdentity())
					{
						PlayerIdentity selectedIdentity = selectedPlayer.GetIdentity();
						Param1<string> Msgparam = new Param1<string>( Message );
						if ( m_AdminsListArray.Find(selectedIdentity.GetPlainId()) >= 0 || m_ArbitratorsListArray.Find(selectedIdentity.GetPlainId()) >= 0 )
						{
							GetGame().RPCSingleParam(selectedPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, selectedIdentity);
							Print("::: [AdminMod_Class] ::: ConnectPlayersMessage() ::: enablePlayersConnectMessagesToAdmins || enablePlayersConnectMessagesToArbitrators: " + selectedIdentity.GetName() + ": " + Message);
						}
					}
				}
			}
			Print("::: [AdminMod_Class] ::: ConnectPlayersMessage() ::: " + Message + ". Player UID: " + connectedIdentity.GetPlainId());
		}
	}
	// ================================================================================================================================================================================

	// ================================================================================================================================================================================
	static void DisConnectPlayersMessage(string playerNAME, string playerUID)
	{
		//ServerDebugFps(); //debug
		
		array<Man> players = new array<Man>; 
		GetGame().GetPlayers( players ); 
		if (players.Count() > 0)
		{
			private string Message = "Player " + playerNAME + " disconnected";
			if ( enablePlayersDisConnectMessages )
			{
				GetGame().ChatPlayer(Message);
			}
			else if ( (enablePlayersDisConnectMessagesToAdmins && m_AdminsListArray.Count() > 0) || (enablePlayersDisConnectMessagesToArbitrators && m_ArbitratorsListArray.Count() > 0) )
			{
				for ( int i = 0; i < players.Count(); ++i )
				{
					PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
					if (selectedPlayer && selectedPlayer.IsAlive() && selectedPlayer.GetIdentity())
					{
						PlayerIdentity selectedIdentity = selectedPlayer.GetIdentity();
						Param1<string> Msgparam = new Param1<string>( Message );
						if ( m_AdminsListArray.Find(selectedIdentity.GetPlainId()) >= 0 || m_ArbitratorsListArray.Find(selectedIdentity.GetPlainId()) >= 0 )
						{
							GetGame().RPCSingleParam(selectedPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, selectedIdentity);
							Print("::: [AdminMod_Class] ::: DisConnectPlayersMessage() ::: enablePlayersDisConnectMessagesToAdmins || enablePlayersDisConnectMessagesToArbitrators: " + selectedIdentity.GetName() + ": " + Message);
						}
					}
				}
			}
			Print("::: [AdminMod_Class] ::: DisConnectPlayersMessage() ::: " + Message + ". Player UID: " + playerUID);
		}
	}
	// ================================================================================================================================================================================

	static void LoadCommandsSettings()
	{
		Print("::: [AdminMod_Class] ::: LoadCommandsSettings :::");
	}
	
	//TP LOCATIONS
	static void LoadTPLocations()
	{
		m_TPLocations 		= new map<string, vector>;	//name of town, pos

		//Add Towns to TP array
		m_TPLocations.Insert( "severograd", "8461.42 0.0 12751.1" ); //28.01.2019
		m_TPLocations.Insert( "severograds", "8706.0 0.0 12797.0" ); //16.03.2019
		m_TPLocations.Insert( "svergino", "9520.0 0.0 13657.0" ); //16.03.2019
		m_TPLocations.Insert( "novodmitr", "11356.0 0.0 14470.0" ); //16.03.2019
        m_TPLocations.Insert( "krasnostav", "11172.0 0.0 12314.1" ); //12072 0 12574
        m_TPLocations.Insert( "mogilevka", "7537.8 0.0 5211.55" );
        m_TPLocations.Insert( "stary", "6046.94 0.0 7733.97" );
        m_TPLocations.Insert( "msta", "11322.55 0.0 5463.36" );
        m_TPLocations.Insert( "vybor", "3784.16 0.0 8923.48" );
        m_TPLocations.Insert( "gorka", "9514.27 0.0 8863.69" );
        m_TPLocations.Insert( "solni", "13418.01 0.0 6264.01" );
        m_TPLocations.Insert( "nwafs", "4540.52 0.0 9645.84" );
		m_TPLocations.Insert( "nwafc", "4823.43 0.0 10457.16" );
		m_TPLocations.Insert( "nwafn", "4214.84 0.0 10977.78" );
        m_TPLocations.Insert( "baf", "4499.08 0.0 2520.55" ); //Balota. //28.01.2019
        m_TPLocations.Insert( "neaf", "11784.7 0.0 12575.0" ); //Krasnostav. //28.01.2019
        m_TPLocations.Insert( "chernoc", "6649.22 0.0 2710.03" );
        m_TPLocations.Insert( "chernow", "6374.08 0.0 2361.01" );
        m_TPLocations.Insert( "chernoe", "7331.70 0.0 2850.03" );
        m_TPLocations.Insert( "electrow", "10077.17 0.0 1988.65" );
        m_TPLocations.Insert( "electroe", "10553.55 0.0 2313.37" );
        m_TPLocations.Insert( "berezc", "12319.54 0.0 9530.15" );
        m_TPLocations.Insert( "berezs", "11991.42 0.0 9116.95" );
        m_TPLocations.Insert( "berezn", "12823.14 0.0 10078.97" );
        m_TPLocations.Insert( "svet", "13900.82 0.0 13258.12" );	
        m_TPLocations.Insert( "zelenos", "2572.80 0.0 5105.09" );
        m_TPLocations.Insert( "zelenon", "2741.48 0.0 5416.69" );
		m_TPLocations.Insert( "lopatino", "2714.74 0.0 9996.33" );
		m_TPLocations.Insert( "tisy", "1723.10 0.0 13983.88" );
		m_TPLocations.Insert( "novaya", "3395.28 0.0 13013.61" );
		m_TPLocations.Insert( "novy", "7085.73 0.0 7720.85" );
		m_TPLocations.Insert( "grishino", "5952.15 0.0 10367.71" );
		m_TPLocations.Insert( "kabanino", "5363.97 0.0 8594.39" );
		m_TPLocations.Insert( "tvtower", "3715.0 0.0 5984.00" );
		m_TPLocations.Insert( "zelgora", "3715.0 0.0 5984.00" );
		m_TPLocations.Insert( "altar", "8167.30 0.0 9081.95" );
		m_TPLocations.Insert( "sz", "4386.0 0.0 10301.0" );
		m_TPLocations.Insert( "bogatyrka", "1565.0 0.0 8984.0" ); //16.03.2019
		
		m_TPLocations.Insert( "ostrov", "23880.0 0.0 -2.0" ); //29.03.2019
		m_TPLocations.Insert( "kymirna", "8351.0 0.0 5980.0" ); //29.03.2019
		m_TPLocations.Insert( "alkatraz", "2659.0 0.0 1383.0" ); //29.03.2019
		m_TPLocations.Insert( "skalisty", "13493.95 0.0 3256.42" ); //29.03.2019
		m_TPLocations.Insert( "ozero", "6531.0 0.0 9240.0" ); //29.03.2019
	}
	
	static void listTPLocations()
	{
		
	}
	//TP LOCATIONS
	
	static void LoadZombiesList()
	{
		//Zombies for spawn
		ZombiesList = {
			"ZmbM_HermitSkinny_Beige","ZmbM_HermitSkinny_Black","ZmbM_HermitSkinny_Green","ZmbM_HermitSkinny_Red",
			"ZmbM_FarmerFat_Beige","ZmbM_FarmerFat_Blue","ZmbM_FarmerFat_Brown","ZmbM_FarmerFat_Green",
			"ZmbF_CitizenANormal_Beige","ZmbF_CitizenANormal_Brown","ZmbF_CitizenANormal_Blue","ZmbM_CitizenASkinny_Blue",
			"ZmbM_CitizenASkinny_Brown","ZmbM_CitizenASkinny_Grey","ZmbM_CitizenASkinny_Red","ZmbM_CitizenBFat_Blue",
			"ZmbM_CitizenBFat_Red","ZmbM_CitizenBFat_Green","ZmbF_CitizenBSkinny","ZmbM_PrisonerSkinny",
			"ZmbM_FirefighterNormal","ZmbM_FishermanOld_Blue","ZmbM_FishermanOld_Green","ZmbM_FishermanOld_Grey",
			"ZmbM_FishermanOld_Red","ZmbM_JournalistSkinny","ZmbF_JournalistNormal_Blue","ZmbF_JournalistNormal_Green",
			"ZmbF_JournalistNormal_Red","ZmbF_JournalistNormal_White","ZmbM_ParamedicNormal_Blue","ZmbM_ParamedicNormal_Green",
			"ZmbM_ParamedicNormal_Red","ZmbM_ParamedicNormal_Black","ZmbF_ParamedicNormal_Blue","ZmbF_ParamedicNormal_Green",
			"ZmbF_ParamedicNormal_Red","ZmbM_HikerSkinny_Blue","ZmbM_HikerSkinny_Green","ZmbM_HikerSkinny_Yellow",
			"ZmbF_HikerSkinny_Blue","ZmbF_HikerSkinny_Grey","ZmbF_HikerSkinny_Green","ZmbF_HikerSkinny_Red",
			"ZmbM_HunterOld_Autumn","ZmbM_HunterOld_Spring","ZmbM_HunterOld_Summer","ZmbM_HunterOld_Winter",
			"ZmbF_SurvivorNormal_Blue","ZmbF_SurvivorNormal_Orange","ZmbF_SurvivorNormal_Red",
			"ZmbF_SurvivorNormal_White","ZmbM_SurvivorDean_Black","ZmbM_SurvivorDean_Blue","ZmbM_SurvivorDean_Grey",
			"ZmbM_PolicemanFat","ZmbF_PoliceWomanNormal","ZmbM_PolicemanSpecForce","ZmbM_SoldierNormal",
			"ZmbM_usSoldier_normal_Woodland","ZmbM_usSoldier_normal_Desert","ZmbM_CommercialPilotOld_Blue",
			"ZmbM_CommercialPilotOld_Olive","ZmbM_CommercialPilotOld_Brown","ZmbM_CommercialPilotOld_Grey",
			"ZmbM_PatrolNormal_PautRev","ZmbM_PatrolNormal_Autumn","ZmbM_PatrolNormal_Flat","ZmbM_PatrolNormal_Summer",
			"ZmbM_JoggerSkinny_Blue","ZmbM_JoggerSkinny_Green","ZmbM_JoggerSkinny_Red","ZmbF_JoggerSkinny_Blue",
			"ZmbF_JoggerSkinny_Brown","ZmbF_JoggerSkinny_Green","ZmbF_JoggerSkinny_Red","ZmbM_MotobikerFat_Beige",
			"ZmbM_MotobikerFat_Black","ZmbM_MotobikerFat_Blue","ZmbM_VillagerOld_Blue","ZmbM_VillagerOld_Green",
			"ZmbM_VillagerOld_White","ZmbM_SkaterYoung_Blue","ZmbM_SkaterYoung_Brown","ZmbM_SkaterYoung_Green",
			"ZmbM_SkaterYoung_Grey","ZmbF_SkaterYoung_Brown","ZmbF_SkaterYoung_Striped","ZmbF_SkaterYoung_Violet",
			"ZmbF_DoctorSkinny","ZmbF_BlueCollarFat_Blue","ZmbF_BlueCollarFat_Green","ZmbF_BlueCollarFat_Red",
			"ZmbF_BlueCollarFat_White","ZmbF_MechanicNormal_Beige","ZmbF_MechanicNormal_Green",
			"ZmbF_MechanicNormal_Grey","ZmbF_MechanicNormal_Orange","ZmbM_MechanicSkinny_Blue","ZmbM_MechanicSkinny_Grey",
			"ZmbM_MechanicSkinny_Green","ZmbM_MechanicSkinny_Red","ZmbM_ConstrWorkerNormal_Beige","ZmbM_ConstrWorkerNormal_Black",
			"ZmbM_ConstrWorkerNormal_Green","ZmbM_ConstrWorkerNormal_Grey","ZmbM_HeavyIndustryWorker","ZmbM_OffshoreWorker_Green",
			"ZmbM_OffshoreWorker_Orange","ZmbM_OffshoreWorker_Red",	"ZmbM_OffshoreWorker_Yellow","ZmbF_NurseFat","ZmbM_HandymanNormal_Beige",
			"ZmbM_HandymanNormal_Blue","ZmbM_HandymanNormal_Green","ZmbM_HandymanNormal_Grey","ZmbM_HandymanNormal_White",
			"ZmbM_DoctorFat","ZmbM_Jacket_beige","ZmbM_Jacket_black","ZmbM_Jacket_blue","ZmbM_Jacket_bluechecks",
			"ZmbM_Jacket_brown","ZmbM_Jacket_greenchecks","ZmbM_Jacket_grey","ZmbM_Jacket_khaki","ZmbM_Jacket_magenta",
			"ZmbM_Jacket_stripes","ZmbF_PatientOld","ZmbM_PatientSkinny","ZmbF_ShortSkirt_beige",
			"ZmbF_ShortSkirt_black","ZmbF_ShortSkirt_brown","ZmbF_ShortSkirt_green","ZmbF_ShortSkirt_grey",
			"ZmbF_ShortSkirt_checks","ZmbF_ShortSkirt_red","ZmbF_ShortSkirt_stripes","ZmbF_ShortSkirt_white",
			"ZmbF_ShortSkirt_yellow","ZmbF_VillagerOld_Blue","ZmbF_VillagerOld_Green","ZmbF_VillagerOld_Red",
			"ZmbF_VillagerOld_White","ZmbM_Soldier","ZmbM_SoldierAlice","ZmbM_SoldierHelmet","ZmbM_SoldierVest",
			"ZmbM_SoldierAliceHelmet","ZmbM_SoldierVestHelmet","ZmbF_MilkMaidOld_Beige","ZmbF_MilkMaidOld_Black",
			"ZmbF_MilkMaidOld_Green","ZmbF_MilkMaidOld_Grey","ZmbM_priestPopSkinny","ZmbM_ClerkFat_Brown",
			"ZmbM_ClerkFat_Grey","ZmbM_ClerkFat_Khaki","ZmbM_ClerkFat_White","ZmbF_Clerk_Normal_Blue",
			"ZmbF_Clerk_Normal_White","ZmbF_Clerk_Normal_Green","ZmbF_Clerk_Normal_Red",
		};
		
	}

	//Class setup end
	//============================================================================================================================================

	//============================================================================================================================================
	//Class functions begin
	
	//Server Start/Watchdog script request
	static void ServerWatchdogScriptRequest(string ScriptCommand, string ScriptData)
	{
		if (ScriptCommand && AdminPlayer)
		{
			string adm_msg;
			switch(ScriptCommand)
			{
				case "restart":
				{
					SaveFile("$profile:restart.", ScriptData, true);
					adm_msg = "Restart request sended.";
				break;
				}
				
				case "shutdown":
				{
					SaveFile("$profile:shutdown.", ScriptData, true);
					adm_msg = "Shutdown request sended.";
				break;
				}
				
				case "machinerestart":
				{
					SaveFile("$profile:machinerestart.", ScriptData, true);
					adm_msg = "Restart host server request sended.";
				break;
				}

				case "cancel":
				{
					SaveFile("$profile:cancel.", "0", true);
					adm_msg = "Cancel request sended.";
				break;
				}

				default:
				{
					adm_msg = "Unknown request!";
				break;
				}

			}
			Param1<string> Msgparam = new Param1<string>( adm_msg );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	//Server Start/Watchdog script request
	
	//Save File
	static void SaveFile(string FileName, string FileData, bool ReWrite)
	{
		FileHandle File;
		Print("::: [AdminMod_Class] ::: SaveFile: " + FileName);
		if (FileExist(FileName))
		{
			if (ReWrite)
			{
				File = OpenFile(FileName,FileMode.WRITE);
			}
			else
			{
				File = OpenFile(FileName,FileMode.APPEND);
			}
		}
		else
		{
			File = OpenFile(FileName, FileMode.WRITE);
		}
		if ( File == 0 )
		{
			Print("::: [AdminMod_Class] ::: SaveFile: Can not write FileName: " + FileName);
			Print("::: [AdminMod_Class] ::: SaveFile: May be disk error, file write protected, file busy or FileMode.WRITE / FileMode.APPEND disabled (need to specify option -scrAllowFileWrite in server run parameters for enable FileMode.WRITE / FileMode.APPEND.");
			return;
		}
		FPrintln(File, FileData);
		CloseFile(File);
	}
	//Save File

	//Load File in to string array //Read file string by string to string array
	static ref array<string> LoadFile(string FileName)
	{
		ref array<string> filestrings = new array<string>;
		FileHandle File;
		Print("::: [AdminMod_Class] ::: LoadFile: " + FileName);
		if (FileExist(FileName))
		{
			File = OpenFile(FileName,FileMode.READ);
		} else {
			Print("::: [AdminMod_Class] ::: LoadFile: Can not read FileName: " + FileName + ", file not found");
			return NULL;
		}
		if ( File == 0 )
		{
			Print("::: [AdminMod_Class] ::: LoadFile: Can't read FileName: " + FileName);
			return NULL;
		}
		if (File != 0)
		{ 
			string line_content = "";
			while ( FGets(File, line_content) >= 0)    
			{
				filestrings.Insert(line_content);
			}
		}
		return filestrings;
	}
	//Load File in to string array

	//Admin Tool Command Parser
	static ref array<string> ParseCommand(string CommandLine)
	{
		ref array<string> tempstr = new array<string>;
		ref array<string> cmdline = new array<string>;
		string cmdparams;
		CommandLine.Split(" ", tempstr);
		cmdline.Insert(tempstr.Get(0));
		if (tempstr.Count() > 1)
		{
			for (int i = 1; i < tempstr.Count(); i++)
			{
				cmdparams = cmdparams + tempstr.Get(i) + " ";
			}
			cmdparams = cmdparams.Trim();
			cmdline.Insert(cmdparams);
		}
		return cmdline;
	}
	//Teleport
	static int TeleportAllPlayersTo(PlayerBase Player)
	{
		array<Man> players = new array<Man>;
	    GetGame().GetPlayers( players );
		int m_i = 0;
	    for ( int i = 0; i < players.Count(); ++i )
		{
			PlayerBase Target = PlayerBase.Cast(players.Get(i));
			if (Target && Target != Player)
			{
				SavePosToProfile(VectorToVectorString(Target.GetPosition()), Target.GetIdentity().GetPlainId());
				Target.SetPosition(Player.GetPosition());
				m_i++;
			}
		}
		return m_i;
	}

	static int TeleportAllPlayersBack()
	{
		array<Man> players = new array<Man>;
	    GetGame().GetPlayers( players );
		string backstrPos;
		
	    for ( int i = 0; i < players.Count(); ++i )
		{
			PlayerBase Target = PlayerBase.Cast(players.Get(i));
			if (Target && Target != AdminPlayer)
			{
				backstrPos = LoadPosFromProfile(Target.GetIdentity().GetPlainId(),true);
				if (backstrPos.Length() > 4)
				{				
					Target.SetPosition(backstrPos.ToVector());
				}
			}
		}
		return i;
	}
	
	//Spawn
	static EntityAI SpawnObject(bool ground, PlayerBase player, string ClassName)
	{
		EntityAI itemEnt;
		ItemBase itemBs
		vector NewPosition, OldPosition;

		if (ground)
		{
			OldPosition = player.GetPosition();

			NewPosition[0] = OldPosition[0] + 1.5;
			NewPosition[2] = OldPosition[2] + 1.5;
			NewPosition[1] = GetGame().SurfaceY( NewPosition[0], NewPosition[2] ) + 0.001;

			Object object = GetGame().CreateObject(ClassName, NewPosition);
			if (object)
			{
				itemEnt = EntityAI.Cast(object);
				object.PlaceOnSurface();
				object.SetPosition(object.GetPosition());
				object.SetOrientation(player.GetOrientation());
				ResetCollision(object);
			}
		}
		else
		{
			itemEnt = player.GetInventory().CreateInInventory( ClassName );
			if (itemEnt)
			{
				itemBs = ItemBase.Cast(itemEnt);	
				itemBs.SetQuantity(1);
			}
		}
		
		if (itemEnt)
		{
			return itemEnt;
		}
		return NULL;
	}

	static void ResetCollision(Object object)
	{
		if (object)
		{
			vector roll = object.GetOrientation();
			object.SetOrientation(roll);
			roll[2] = roll[2] - 1;
			object.SetOrientation(roll);
			roll[2] = roll[2] + 1;
			object.SetOrientation(roll);
		}
	}
	//Spawn

	//Buildings doors
	static void BuildingDoors(EntityAI buildEnt, bool doorsClose, bool doorsLock)
	{
		if (buildEnt.IsBuilding())
		{
			Building building = Building.Cast(buildEnt);
			
			int compIndex = 256; //Componetnt index - max 256 for buildings
			for ( int i = 0; i < compIndex; i++ )
			{
				int doorIndex = building.GetDoorIndex(i);
				if (doorIndex!=-1) 
				{
					Print("::: [AdminMod_Class] ::: BuildingDoors ::: Building component: " + i + ": doors index: " + doorIndex);
					
					for ( int a = 0; a < doorIndex; a++ )
					{
						if (doorsClose && building.IsDoorOpen(a))
						{
							building.CloseDoor(a);
							Print("::: [AdminMod_Class] ::: BuildingDoors ::: building.CloseDoor(a): " + a);
						}
						else if (!doorsClose && !building.IsDoorOpen(a))
						{
							building.OpenDoor(a);
							Print("::: [AdminMod_Class] ::: BuildingDoors ::: building.OpenDoor(a): " + a);
						}
						
						if (doorsLock && !building.IsDoorLocked(a))
						{
							building.LockDoor(a);
							Print("::: [AdminMod_Class] ::: BuildingDoors ::: building.LockDoor(a): " + a);
						}
						else if (!doorsLock && building.IsDoorLocked(a))
						{
							building.UnlockDoor(a);
							Print("::: [AdminMod_Class] ::: BuildingDoors ::: building.UnLockDoor(a): " + a);
						}
					}
				}
			}

		}
	}
	//Buildings doors
	
	//Coverters
	static vector SnapToGround(vector pos)
    {
        float pos_x = pos[0];
		float pos_y = pos[2];
        float pos_z = GetGame().SurfaceY( pos_x, pos_y );
        vector tmp_pos = Vector( pos_x, pos_z, pos_y );
        tmp_pos[1] = tmp_pos[1] + pos[1];
        return tmp_pos;
    }

	//Convert vector to vector-string
	static string VectorToVectorString(vector dVector)
	{
		string strVector = dVector.ToString();
		strVector.Replace("<","");
		strVector.Replace(">","");
		strVector.Replace(",","");
		return strVector;
	}
	//Convert vector to vector-string

	//Save current position to server profile
	static void SavePosToProfile(string strVector, string strGUID)
	{
		g_Game.SetProfileString("SavedPos"+strGUID,strVector);
		g_Game.GetProfileString("SavedPos"+strGUID,strVector);
		g_Game.SaveProfile();
		Print("::: [AdminMod_Class] ::: SavePosToProfile ::: Saved current pos: " + strVector);
	}
	//Save current position to server profile
	
	//Load current position from server profile
	static string LoadPosFromProfile(string strGUID, bool doPosClear)
	{
		string strVector;
		g_Game.GetProfileString("SavedPos"+strGUID,strVector);
		if (strVector.Length() > 4)
		{
			Print("::: [AdminMod_Class] ::: LoadPosFromProfile ::: Load saved pos: " + strVector);
			if (doPosClear)
			{
				g_Game.SetProfileString("SavedPos"+strGUID,""); //Clear pos in profile
				Print("::: [AdminMod_Class] ::: LoadPosFromProfile ::: Clear saved pos [ SavedPos" + strGUID + " ] in profile.");
				g_Game.SaveProfile();
			}
			else
			{
				Print("::: [AdminMod_Class] ::: LoadPosFromProfile ::: Keep saved pos [ SavedPos" + strGUID + " ] in profile.");
			}
			return strVector;
		}
		else
		{
			return "";
		}
	}
	//Load current position from server profile

	//Date/Time Ajust 
	static string AjustDateTime(int new_Year, int new_Month, int new_Day, int new_Hour, int new_Minute, string adj_Mode) //Ajust date and time and return date or time with format: date: dd.mm.yyyy, time: hh:mm
	{
		int m_Year, m_Month, m_Day, m_Hour, m_Minute;
		string strDate, strTime, s_Year, s_Month, s_Day, s_Hour, s_Minute;
		
		GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute); //Get current date and time
		
		if (adj_Mode == "DATE")
		{
			GetGame().GetWorld().SetDate(new_Year, new_Month, new_Day, m_Hour, m_Minute); //ajust date
		}
		else if (adj_Mode == "TIME")
		{
			GetGame().GetWorld().SetDate(m_Year, m_Month, m_Day, new_Hour, new_Minute); //ajust time
		}
		else if (adj_Mode == "ALL")
		{
			GetGame().GetWorld().SetDate(new_Year, new_Month, new_Day, new_Hour, new_Minute); //ajust date and time
		}

		GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);  //Get new current date and time
		
		if (m_Minute >= 60)
		{
			m_Minute = 0;
			m_Hour = m_Hour + 1;
			if (m_Hour > 23)
			{
				m_Hour == 0;
			}
		}

		s_Year = m_Year.ToStringLen(4);
		s_Month = m_Month.ToStringLen(2);
		s_Day = m_Day.ToStringLen(2);
		s_Hour = m_Hour.ToStringLen(2);
		s_Minute = m_Minute.ToStringLen(2);
		
		/*
		if (m_Month < 10)
		{
			s_Month = "0" + m_Month.ToString();
		}
		if (m_Day < 10)
		{
			s_Day = "0" + m_Day.ToString();
		}
		if (m_Hour < 10)
		{
			s_Hour = "0" + m_Hour.ToString();
		}
		if (m_Minute < 10)
		{
			s_Minute = "0" + m_Minute.ToString();
		}
		*/
		
		strDate = s_Day + "." + s_Month + "." + s_Year;
		strTime = s_Hour + ":" + s_Minute;
		
		if (adj_Mode == "DATE")
		{
			return strDate;
		}
		else if (adj_Mode == "TIME")
		{
			return strTime;
		}
	
		return strDate + ", " + strTime;
	}
	//Date/Time Ajust 

	//Date/time
	static string GetDateTime()
	{
		string date = GetCurrentDate();
		string time = GetCurrentTime();

		return date + ", " + time;
	}

	static string GetCurrentDate()
	{
		int year, month, day;	
		GetYearMonthDay(year, month, day);
		string date = day.ToStringLen(2) + "." + month.ToStringLen(2) + "." + year.ToStringLen(4);
		return date;
	}

	static string GetCurrentTime()
	{
		int hour, minute, second;
		GetHourMinuteSecond(hour, minute, second);
		string time = hour.ToStringLen(2) + ":" + minute.ToStringLen(2) + ":" + second.ToStringLen(2);
		return time;
	}

	//Clear global chat
	static void GlobalChatClear()
	{
		array<Man> players = new array<Man>;
		GetGame().GetPlayers(players);
			
		Param1<string> c_MessageParam = new Param1<string>(" ");
		PlayerBase player;
			
		for ( int i = 0; i < players.Count(); ++i )
		{
			player = PlayerBase.Cast(players.Get(i));
			if ( player && player.IsAlive() && player.GetIdentity() && player != AdminPlayer )
			{
				for ( int j = 0; j < 12; ++j )
				{
					GetGame().RPCSingleParam(player, ERPCs.RPC_USER_ACTION_MESSAGE, c_MessageParam, true, player.GetIdentity());
				}
				//DEBUG
				//Print("::: [AdminMod_Class] ::: GLOBAL CHAT CLEAR ::: DEBUG: Player: " + player.ToString() + ", Name: " + player.GetIdentity().GetName() + " || Admin: " + AdminPlayer.ToString() + ", Name: " + AdminPlayer.GetIdentity().GetName());
				c_MessageParam = new Param1<string>(" ");
				GetGame().RPCSingleParam(player, ERPCs.RPC_USER_ACTION_MESSAGE, c_MessageParam, true, player.GetIdentity());
				//DEBUG
			}
		}
	}
	//Clear global chat
	
	//Clear global chat include admin
	static void AdmGlobalChatClear()
	{
		array<Man> players = new array<Man>;
		GetGame().GetPlayers(players);
			
		Param1<string> c_MessageParam = new Param1<string>(" ");
		PlayerBase player;
			
		for ( int i = 0; i < players.Count(); ++i )
		{
			player = PlayerBase.Cast(players.Get(i));
			if ( player && player.IsAlive() && player.GetIdentity() )
			{
				for ( int j = 0; j < 12; ++j )
				{
					GetGame().RPCSingleParam(player, ERPCs.RPC_USER_ACTION_MESSAGE, c_MessageParam, true, player.GetIdentity());
				}
				//DEBUG
				//Print("::: [AdminMod_Class] ::: GLOBAL CHAT CLEAR ::: DEBUG: Player: " + player.ToString() + ", Name: " + player.GetIdentity().GetName());
				c_MessageParam = new Param1<string>(" ");
				GetGame().RPCSingleParam(player, ERPCs.RPC_USER_ACTION_MESSAGE, c_MessageParam, true, player.GetIdentity());
				//DEBUG
			}
		}
	}
	//Clear global chat include admin

	//Delayed messaging
	static void AT_Send_Delayed_Message(PlayerBase Player, string Message, float time, int Channel)
	{
		//ServerDebugFps(); //debug
		
		Param1<string> Msgparam;
		if ((Message != "") && (time >= 0))
		{
			Print("::: [AdminMod_Class] ::: AT_Send_Delayed_Message ::: Message: '" + Message + ", delay time: " + time + " sec.");
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(at_Send_Chat_Message, (time * 1000), false, Player, Message, Channel);
		}
		else
		{
			if (AdminPlayer && AdminPlayer.IsAlive() && AdminIdentity)
			{
				Msgparam = new Param1<string>("Admin Mod Error!"); //For current ADMIN!
				GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
				Msgparam = new Param1<string>("AT_Send_Delayed_Message: empty message!"); //For current ADMIN!
				GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
				Print("::: [AdminMod_Class] ::: AT_Send_Delayed_Message ::: error: empty message!");
			}
		}
	}
	//Delayed messaging

	//Messaging
	static void at_Send_Chat_Message(PlayerBase Player, string Message, int Channel) //1st parameter - player (define to NULL and message sends to all players), 2nd parameter - message text, 3rd parameter - chat channel (ignored if you send message to specified player)
	{
		Param1<string> Msgparam;
		if (Message != "")
		{
			if (Player && Player.IsAlive() && Player.GetIdentity())
			{
				Print("::: [AdminMod_Class] ::: at_Send_Chat_Message ::: Message single player: " + Player.GetIdentity().GetName() + ", Message: "+ Message + " : [Timestamp: " + GetDateTime() + "]");
				Msgparam = new Param1<string>(Message); //For single player!
				GetGame().RPCSingleParam(Player, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, Player.GetIdentity());
			}
			else if (Channel == 0)
			{
				Print("::: [AdminMod_Class] ::: at_Send_Chat_Message ::: Message global chat: Cannel: " + Channel + ", Message: " + Message + " : [Timestamp: " + GetDateTime() + "]");
				GetGame().ChatPlayer(Message); //For global chat channel
			}
			else
			{
				GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(at_Send_Chat_Message);
			}
		}
		else if (AdminPlayer && AdminPlayer.IsAlive() && AdminIdentity)
		{
			Msgparam = new Param1<string>("Admin Mod Error!"); //For current ADMIN!
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
			Msgparam = new Param1<string>("at_Send_Chat_Message: empty message!"); //For current ADMIN!
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
			Print("::: [AdminMod_Class] ::: at_Send_Chat_Message ::: error: empty message!");
		}
		else
		{
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(at_Send_Chat_Message);
		}
	}
	
	void SendGlobalMessage(string Message)
	{
		array<Man> players = new array<Man>;
		GetGame().GetPlayers( players );
		for ( int i = 0; i < players.Count(); ++i )
		{
			PlayerBase Player = PlayerBase.Cast(players.Get(i));
			if (Player && Player.IsAlive() && Player.GetIdentity())
			{
				Param1<string> Msgparam = new Param1<string>( Message );
				GetGame().RPCSingleParam(Player, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, Player.GetIdentity());
			}
		}
	}

	//Messaging

	//Mover Caller
	static void MoveTo(PlayerBase Player, vector finishPos)
	{
		EntityAI PlayerEntity = EntityAI.Cast(Player);
		if (m_MovePlayer || !Player || !PlayerEntity)
		{
			m_MovePlayer = false;
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(PlayerMover);
			dBodyEnableGravity(PlayerEntity,true);
			Player.SetSynchDirty();
			Print("::: [AdminMod_Class] ::: MoveTo: Player = " + Player.ToString() + " movement forced stop.");
			return;
		}
		
		m_MovePlayer = true;		
		
		string UID = Player.GetIdentity().GetPlainId();
		vector PlayerPos = Player.GetPosition();
		SavePosToProfile(VectorToVectorString(PlayerPos),"InitMov:" + UID);
		
		finishPos[1] = GetGame().SurfaceY( finishPos[0], finishPos[2] );

		Player.SetOrientation(finishPos);
		vector newPos = PlayerPos;
		
		float max_alt = 700.000;
		float mov_alt = 0;

		Print("::: [AdminMod_Class] ::: MoveTo: Player = " + Player.ToString() + ", PlayerPos = " + PlayerPos.ToString() + ", finishPos = " + finishPos.ToString() + ", m_MovePlayer = " + m_MovePlayer.ToString());		
		Print("::: [AdminMod_Class] ::: MoveTo: Generate moving Begin: While( newPos[1] = " + newPos[1].ToString() + " < max_alt = " + max_alt.ToString() + " )");
		
		//13.03.2019
		float time_scale = 0;
		while (newPos[1] < max_alt)
		{
			mov_alt = mov_alt + 0.25; // 0.125m/40ms = 3.125m/s = 11.249991 km/h
			newPos[1] = PlayerPos[1] + mov_alt;
			time_scale = time_scale + 40; //Ms = 25 calls/seconds
			if (m_MovePlayer && Player)
			{
				GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(PlayerMover, time_scale, false, Player, newPos[0], newPos[1], newPos[2], finishPos[0], finishPos[1], finishPos[2], max_alt);
			}
		}
		Print("::: [AdminMod_Class] ::: MoveTo: Generate moving End: While( newPos[1] = " + newPos[1].ToString() + " < max_alt = " + max_alt.ToString() + " )");
		//
	}
	//Mover Caller
	
	//Mover
	static void PlayerMover(PlayerBase Player, float newPos0, float newPos1, float newPos2, float finishPos0, float finishPos1, float finishPos2, float max_alt)
	{
		
		bool m_moveEnable = true;
		EntityAI PlayerEntity = EntityAI.Cast(Player);

		if (m_MovePlayer && Player && PlayerEntity)
		{
			dBodyEnableGravity(PlayerEntity, false);
			Player.SetSynchDirty();

			vector newPos;
			newPos[0] = newPos0;
			newPos[1] = newPos1;
			newPos[2] = newPos2;
			
			vector finishPos;
			finishPos[0] = finishPos0;
			finishPos[1] = finishPos1;
			finishPos[2] = finishPos2;

			if (newPos[1] < max_alt)
			{
				Player.SetPosition(newPos);
			}
			else
			{
				m_moveEnable = false;
				Print("::: [AdminMod_Class] ::: PlayerMover: Player = " + Player.ToString() + " max alt reached.");
			}
		}

		if (!m_MovePlayer || !m_moveEnable)
		{
			dBodyEnableGravity(PlayerEntity, true);
			Player.SetSynchDirty();
			m_MovePlayer = false;
			Print("::: [AdminMod_Class] ::: PlayerMover: Stop.");
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(PlayerMover);
			return;
		}
	}
	//Mover
	
	//AdminPlayer object static saver for freecam/spectator 
	static void AdminPlayerHide(bool hideStatus, string strHeldPos, PlayerBase Target)
	{
		if (!AdminIdentity && AdminPlayer) if (AdminPlayer.GetIdentity()) AdminIdentity = AdminPlayer.GetIdentity();
		
		Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: AdminPlayer = " + AdminPlayer.ToString() + " => AdminObject = " + AdminObject.ToString() + " AdminIdentity = " + AdminIdentity.ToString());
		string GodMode = "";
		g_Game.GetProfileString("GodMode"+AdminUID,GodMode);
		
		if (AdminPlayer)
		{
			Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: hideStatus = " + hideStatus.ToString());
			if (hideStatus)
			{
				//Select mode and positions
				if (m_FreeCamera)
				{
					m_AdminHeldPos = m_AdminInitPos;
				}
				if (m_Spectator)
				{
					if (Target && Target.GetIdentity())
					{
						m_AdminHeldPos = Target.GetPosition();
					}
					else
					{
						if (strHeldPos)
						{
							m_AdminHeldPos = strHeldPos.ToVector();
						}
						else
						{
							m_AdminHeldPos = m_AdminInitPos;
						}
					}
				}
				if (!m_AdminHeldPos && strHeldPos)
				{
					m_AdminHeldPos = strHeldPos.ToVector();
				}
				if (!m_AdminHeldPos)
				{
					if (m_FreeCamera) m_FreeCamera = false;
					if (m_Spectator) m_Spectator = false;
					AdminPlayer.SetPosition(m_AdminInitPos);
					GetGame().SelectPlayer(AdminIdentity, AdminPlayer);
					if (AdminEntity)
					{
						dBodyEnableGravity(AdminEntity,true);
						dBodySetMass(AdminEntity, m_AdminBodyMass);
					}
					AdminPlayer.SetSynchDirty();
					m_AdminHeldPos = "0 0 0";
					Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: ENTER HIDDEN: CANCELLED!");
					return;
				}
				//Select mode and positions
					
				Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: ENTER HIDDEN: m_AdminInitPos = " + m_AdminInitPos.ToString());
				
				m_AdminHeldPos[1] = GetGame().SurfaceY( m_AdminHeldPos[0], m_AdminHeldPos[2] ) + m_hidderAlt;
				
				/*
				if (m_hidderSpawn) m_hidderSpawn.Delete();
				m_hidderSpawn = EntityAI.Cast(GetGame().CreateObject(m_hidderObj, m_AdminHeldPos));
				if (m_hidderSpawn)
				{
				*/
					AdminPlayer.SetAllowDamage(false); //Temporary GodMode
					SavePosToProfile(VectorToVectorString(m_AdminInitPos),"Hide:" + AdminUID);
					m_AdminHidden = true;
					//Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: m_hidderSpawn = " + m_hidderSpawn.ToString() + ", m_AdminHeldPos = " + m_AdminHeldPos.ToString());

					//m_hidderSpawn.SetOrientation(AdminPlayer.GetOrientation());
					//m_hidderSpawn.SetDirection(AdminPlayer.GetDirection());
					//if (m_hidderSpawn.IsBuilding()) BuildingDoors(m_hidderSpawn, true, true);
					//Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: m_hidderSpawn = " + m_hidderSpawn.ToString() + ", m_hidderSpawn.GetPosition() = " + m_hidderSpawn.GetPosition().ToString());
					//AdminPlayer.SetPosition(m_hidderSpawn.GetPosition()); //Vertical offset
					
					dBodySetMass(AdminEntity, 0.1);
					dBodyEnableGravity(AdminEntity,false);

					AdminPlayer.SetPosition(m_AdminHeldPos);
					if (Target)
					{
						AdminPlayer.SetOrientation(Target.GetOrientation());
						AdminPlayer.SetDirection(Target.GetDirection());
					}
					AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
					AdminPlayer.SetDirection(AdminPlayer.GetDirection());
					AdminPlayer.SetPosition(AdminPlayer.GetPosition());
					AdminPlayer.SetSynchDirty();

					//m_AdminHeldPos = AdminPlayer.GetPosition();
					
					//Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: BEGIN ::: m_AdminHeldPos = " + m_AdminHeldPos.ToString() + " : AdminPlayer.GetPosition() = " + AdminPlayer.GetPosition().ToString() + " : m_hidderSpawn.GetPosition() = " + m_hidderSpawn.GetPosition().ToString()); 
					Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: BEGIN ::: m_AdminHeldPos = " + m_AdminHeldPos.ToString() + " : AdminPlayer.GetPosition() = " + AdminPlayer.GetPosition().ToString()); 
					//if (m_Spectator)
					//{
						m_AdminHoldPosition = true;
						GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(AdminHoldPosition, m_hidderMoveDelay, true, Target);
					//}
					return;
				/*
				}
				else
				{
					m_AdminHoldPosition = false;
					GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(AdminHoldPosition);
					m_AdminHidden = false;
					m_AdminHeldPos = "0 0 0";
					
					AdminPlayer.SetPosition(Vector(m_AdminInitPos[0], GetGame().SurfaceY( m_AdminInitPos[0], m_AdminInitPos[2] ) - 2, m_AdminInitPos[2]));
					AdminPlayer.SetPosition(m_AdminInitPos);
					AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
					AdminPlayer.SetDirection(AdminPlayer.GetDirection());
					AdminPlayer.SetPosition(m_AdminInitPos);

					if (AdminEntity)
					{
						dBodyEnableGravity(AdminEntity,true);
						dBodySetMass(AdminEntity, m_AdminBodyMass);
					}
					AdminPlayer.SetSynchDirty();

					GetGame().SelectPlayer(AdminIdentity, AdminPlayer);

					if (m_FreeCamera) m_FreeCamera = false;
					if (m_Spectator) m_Spectator = false;

					Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: BREAK ::: Return to pos: " + AdminPlayer.GetPosition().ToString());

					if (GodMode != "true") GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(AdminPlayer.SetAllowDamage, m_hidderRemoveDelay, false, true); //AdminPlayer.SetAllowDamage(true);
					return;
				}
				*/
			}
			else if (!hideStatus)
			{
				if (AdminIdentity)
				{
					bool doPosClear = true;
				}
				else
				{
					doPosClear = false;
				}
				string backstrPos = LoadPosFromProfile("Hide:" + AdminUID,doPosClear);
				if (backstrPos.Length() > 4)
				{	
					vector backPos = backstrPos.ToVector();
				}
				else
				{
					backPos = m_AdminInitPos;
				}

				m_AdminHoldPosition = false;
				GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(AdminHoldPosition);
				m_AdminHidden = false;
				m_AdminHeldPos = "0 0 0";

				Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: EXIT HIDDEN: m_AdminHidden = " + m_AdminHidden.ToString());
				AdminPlayer.SetPosition(Vector(backPos[0],GetGame().SurfaceY( backPos[0], backPos[2] ) - 2, backPos[2]));
				AdminPlayer.SetPosition(backPos);
				AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
				AdminPlayer.SetDirection(AdminPlayer.GetDirection());
				AdminPlayer.SetPosition(backPos);
				
				dBodyEnableGravity(AdminEntity,true);
				dBodySetMass(AdminEntity, m_AdminBodyMass);

				AdminPlayer.SetSynchDirty();

				GetGame().SelectPlayer(AdminIdentity, AdminPlayer);
				
				if (m_FreeCamera) m_FreeCamera = false;
				if (m_Spectator) m_Spectator = false;

				Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: END ::: Return to pos: " + AdminPlayer.GetPosition().ToString());
				
				//if (m_hidderSpawn) GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(DelayedRemoveEntity, m_hidderRemoveDelay, false, m_hidderSpawn);
				if (GodMode != "true") GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(AdminPlayer.SetAllowDamage, m_hidderRemoveDelay, false, true); //AdminPlayer.SetAllowDamage(true);
				if (!AdminIdentity) AdminPlayer.Delete(); //01.03.2019 !!!
				return;
			}
		}
		else
		{
			m_AdminHoldPosition = false;
			GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(AdminHoldPosition);
			m_AdminHidden = false;
			m_AdminHeldPos = "0 0 0";

			if (m_FreeCamera) m_FreeCamera = false;
			if (m_Spectator) m_Spectator = false;

			Print("::: [AdminMod_Class] ::: AdminPlayerHide ::: AdminPlayer = NULL: EXIT HIDDEN: m_AdminHidden = " + m_AdminHidden.ToString());

			//if (m_hidderSpawn) GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(DelayedRemoveEntity, m_hidderRemoveDelay, false, m_hidderSpawn);
		}
	}

	static void AdminHoldPosition(PlayerBase Target)
	{
		vector m_AdminTargetPos = m_AdminHeldPos; //m_AdminHeldPos is class variable
		vector CurrPos, m_hidderSpawnPos;

		if (m_AdminHoldPosition)
		{
			if (AdminPlayer)
			{
				if (AdminEntity)
				{
					dBodySetMass(AdminEntity, 0.1);
					dBodyEnableGravity(AdminEntity,false);
				}
				if (m_Spectator)
				{
					if (Target && Target.GetIdentity() && Target != AdminPlayer && Target != NULL)
					{
						m_AdminTargetPos = Target.GetPosition();
						m_AdminTargetPos[1] = GetGame().SurfaceY( m_AdminTargetPos[0], m_AdminTargetPos[2] ) + m_hidderAlt; //Altitude
						Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: Target: " + Target.ToString() + " Read Pos: "+ Target.GetPosition().ToString());

						/*
						m_hidderSpawnPos = m_hidderSpawn.GetPosition();
						if ( Target && (m_hidderSpawnPos[0] < (m_AdminTargetPos[0] - 2) || m_hidderSpawnPos[0] > (m_AdminTargetPos[0] + 2) || m_hidderSpawnPos[2] < (m_AdminTargetPos[2] - 2) || m_hidderSpawnPos[2] > (m_AdminTargetPos[2] + 2)) )
						{
							EntityAI m_oldhidderSpawn = m_hidderSpawn;
							m_hidderSpawn = EntityAI.Cast(GetGame().CreateObject(m_hidderObj, m_AdminTargetPos));
							m_hidderSpawn.SetPosition(m_AdminTargetPos);
							if (m_hidderSpawn.IsBuilding()) BuildingDoors(m_hidderSpawn, true, true);
							AdminPlayer.SetPosition(m_hidderSpawn.GetPosition());
							m_AdminHeldPos = m_hidderSpawn.GetPosition(); //?
							m_oldhidderSpawn.Delete();
							Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: Target: " + Target.ToString() + " Correct spectator pos: " + m_AdminHeldPos.ToString());
						}
						*/
						CurrPos = AdminPlayer.GetPosition();
						if ( Target && (CurrPos[0] < (m_AdminTargetPos[0] - 2) || CurrPos[0] > (m_AdminTargetPos[0] + 2) || CurrPos[2] < (m_AdminTargetPos[2] - 2) || CurrPos[2] > (m_AdminTargetPos[2] + 2)) )
						{
							AdminPlayer.SetPosition(m_AdminTargetPos);
							m_AdminHeldPos = AdminPlayer.GetPosition();
							Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: Target: " + Target.ToString() + " Correct spectator pos: " + m_AdminHeldPos.ToString());
						}
					}
					else
					{
						m_AdminTargetPos = m_AdminHeldPos;
						m_AdminTargetPos[1] = GetGame().SurfaceY( m_AdminTargetPos[0], m_AdminTargetPos[2] ) + m_hidderAlt; //Altitude
						Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: NoTarget: AdminPlayer = " + AdminPlayer.ToString() + " spectator pos: " + m_AdminTargetPos.ToString());
					}
				}
				/*
				else
				{
					m_AdminTargetPos = m_AdminHeldPos;
				}
				*/
				
				CurrPos = AdminPlayer.GetPosition();
				//if ( (CurrPos[1] < (m_AdminTargetPos[1] - 3.453) || !m_hidderSpawn) && m_AdminHoldPosition) // - 1.453
				if ( CurrPos[1] < (m_AdminTargetPos[1] - 3.453) && m_AdminHoldPosition) // - 1.453
				{
					/*
					if (!m_hidderSpawn)
					{
						m_hidderSpawn = EntityAI.Cast(GetGame().CreateObject(m_hidderObj, m_AdminTargetPos));
						if (m_hidderSpawn.IsBuilding()) BuildingDoors(m_hidderSpawn, true, true);
					}
					*/
					Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: current altitude: " + CurrPos.ToString());
					AdminPlayer.SetPosition(m_AdminTargetPos);
					Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: Correct current altitude: " + m_AdminTargetPos.ToString());
				}
			}

			if (!AdminPlayer)
			{
				m_AdminHoldPosition = false;
				Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: AdminPlayer = NULL : m_AdminHoldPosition = false");
			}
			
			if (!AdminIdentity && AdminPlayer) if (AdminPlayer.GetIdentity()) AdminIdentity = AdminPlayer.GetIdentity();
			if (!AdminIdentity)
			{
				m_AdminHoldPosition = false;
				Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: AdminIdentity = NULL : m_AdminHoldPosition = false");
			}
		}
		if (!m_AdminHoldPosition)
		{
			AdminPlayerHide(false,"",NULL);
			GetGame().SelectPlayer(AdminIdentity, AdminPlayer); //?
			Print("::: [AdminMod_Class] ::: AdminHoldPosition ::: STOP :::");
		}
	}

	static void AdminLoginResetPosition(PlayerBase Player)
	{
		if (Player)
		{
			vector m_AdminResetPos;
			string UID = Player.GetIdentity().GetPlainId();
			vector m_AdminCurrentPos = Player.GetPosition();
			float m_AdminCurrentAlt =  m_AdminCurrentPos[1];
			float m_AdminCurrentSurface = GetGame().SurfaceY( m_AdminCurrentPos[0], m_AdminCurrentPos[2] );
			Print("::: [AdminMod_Class] ::: AdminLoginResetPosition ::: Admin Player: " + UID + " current pos: " + m_AdminCurrentPos.ToString());
			
			if (UID == AdminUID)
			{
				if (m_AdminHidden) 
				{
					AdminPlayerHide(false,"",NULL);
				}
				m_AdminHidden = false;
				adm_ChatRequestExec = false;
				if (m_FreeCamera) m_FreeCamera = false;
				if (m_Spectator) m_Spectator = false;
				m_AdminHeldPos = "0 0 0";
			}
			
			string backstrPos = LoadPosFromProfile("Hide:" + UID,true);
			if (backstrPos.Length() > 4)
			{
				m_AdminResetPos = backstrPos.ToVector();
				Print("::: [AdminMod_Class] ::: AdminLoginResetPosition ::: Admin Player: " + UID + " load saved [Hide:] init pos: " + m_AdminResetPos.ToString());
			}

			/*
			if ( !m_AdminResetPos )
			{
				if ( m_AdminCurrentAlt > (m_AdminCurrentSurface + 1) || m_AdminCurrentAlt < (m_AdminCurrentSurface - 1) )
				{
					Print("::: [AdminMod_Class] ::: AdminLoginResetPosition ::: Admin Player: " + UID + " current alt: " + m_AdminCurrentPos[1] + " higher/lower then ground: " + m_AdminCurrentSurface);
					m_AdminCurrentPos[1] = m_AdminCurrentSurface + 0.001;
					m_AdminResetPos = m_AdminCurrentPos;
				}
			}
			*/
			
			if (m_AdminResetPos)
			{
				Player.SetPosition(m_AdminResetPos);
				Player.SetPosition(Player.GetPosition());
				Player.SetOrientation(Player.GetOrientation());
				ResetCollision(Object.Cast(Player));
				Player.SetSynchDirty();
				Print("::: [AdminMod_Class] ::: AdminLoginResetPosition ::: Admin Player: " + UID + " reset position: " + m_AdminResetPos.ToString());
			}
			else
			{
				Print("::: [AdminMod_Class] ::: AdminLoginResetPosition ::: Admin Player: " + UID + " current spawn position: " + Player.GetPosition().ToString());
			}
		}
	}

	static void DelayedRemoveEntity(EntityAI entity)
	{
		if (entity)
		{
			Print("::: [AdminMod_Class] ::: DelayedRemoveEntity ::: Remove entity: " + entity.ToString());
			entity.Delete();
			entity = NULL;
		}
	}
	//Player object static saver for freecam/spectator
	
	//AdminMod OnTick //Call from server mission OnTick !!!
	static void OnTick(PlayerBase currentPlayer)
	{
		if (currentPlayer && currentPlayer.GetIdentity())
		{
			string UID = currentPlayer.GetIdentity().GetPlainId();
			string FullStamina, FullState, FullHealth, FullHealthLoot, FullHealthWeapon, FullAmmo, FullStateWeapon;
			
			g_Game.GetProfileString("FullStamina"+UID,FullStamina);
			g_Game.GetProfileString("FullState"+UID,FullState);
			g_Game.GetProfileString("FullHealth"+UID,FullHealth);
			
			g_Game.GetProfileString("FullHealthLoot"+UID,FullHealthLoot);
			g_Game.GetProfileString("FullHealthWeapon"+UID,FullHealthWeapon);
			g_Game.GetProfileString("FullAmmo"+UID,FullAmmo);
			g_Game.GetProfileString("FullStateWeapon"+UID,FullStateWeapon);
			
			//Player stamina
			if ( m_ServerFullStamina || FullStamina == "true" || m_FullStaminaList.Find(UID) >= 0 )
			{
				SetFullStamina(currentPlayer);
			}
			//Player state
			if ( m_ServerFullState || FullState == "true" || m_FullStateList.Find(UID) >= 0 )
			{
				SetFullState(currentPlayer);
			}
			//Player health
			if ( m_ServerFullHealth || FullHealth == "true" || m_FullHealthList.Find(UID) >= 0 )
			{
				SetFullHealth(currentPlayer);
			}
			//Player Loot
			if ( m_ServerFullHealthLoot || FullHealthLoot == "true" || m_FullHealthLootList.Find(UID) >= 0 )
			{
				SetFullHealthLoot(currentPlayer);
			}
			//Player Weapon
			if ( m_ServerFullHealthWeapon || FullHealthWeapon == "true" || m_FullHealthWeaponList.Find(UID) >= 0 )
			{
				SetFullHealthWeapon(currentPlayer);
			}
			//Player Ammo
			if ( m_ServerFullAmmo || FullAmmo == "true" || m_FullAmmoList.Find(UID) >= 0 )
			{
				SetFullAmmo(currentPlayer);
			}
			//Player full state wepon
			if ( m_ServerFullStateWeapon || FullStateWeapon == "true" || m_FullStateWeaponList.Find(UID) >= 0 )
			{
				SetFullStateWeapon(currentPlayer);
			}
		}
	}
	
	//Player Set States
	static void SetFullStamina(PlayerBase player)
	{
		player.GetStatStamina().Set(1000);
	}

	static void SetFullState(PlayerBase player)
	{
		player.GetStatHeatComfort().Set(0);
		player.GetStatEnergy().Set(1000);
		player.GetStatWater().Set(1000);
		player.GetStatWet().Add( -1 );
	}
	
	static void SetFullHealth(PlayerBase player)
	{
		player.RemoveAllAgents();
		player.SetHealth( "","Blood", player.GetMaxHealth( "", "Blood" ) );
		player.SetHealth("","Shock", player.GetMaxHealth("","Shock") );
		player.SetHealth( player.GetMaxHealth( "", "" ) );
		player.SetBleedingBits(0);
		player.m_DiseaseCount = 0;
	}
	//Player states

	//Player clothes states
	static void SetFullHealthLoot(PlayerBase player)
	{
		EntityAI attachment;
		int AttCount = player.GetInventory().AttachmentCount();
		for (int i	=	0; i < AttCount; i++)
		{
			attachment = player.GetInventory().GetAttachmentFromIndex(i);
			if ( attachment.IsItemBase() )
			{
				attachment.SetHealth("","",100);
			}
		}
	}
	//Player clothes states

	//Player weapon in hands states
	static void SetFullHealthWeapon(PlayerBase player)
	{
		EntityAI CurrentWeapon = player.GetHumanInventory().GetEntityInHands();
		if ( CurrentWeapon )
		{
			CurrentWeapon.SetHealth( CurrentWeapon.GetMaxHealth( "", "" ) );
			Object Suppressor = Object.Cast(CurrentWeapon.GetAttachmentByConfigTypeName( "SuppressorBase" ));
			if( Suppressor )
			{
				Suppressor.SetHealth( Suppressor.GetMaxHealth( "", "" ) );
			}
		} 
	}
	
	static void SetFullAmmo(PlayerBase player)
	{
		EntityAI CurrentWeapon = player.GetHumanInventory().GetEntityInHands();
		if ( CurrentWeapon )
		{
			Magazine foundMag = Magazine.Cast(CurrentWeapon.GetAttachmentByConfigTypeName( "DefaultMagazine" ));
			if ( foundMag && foundMag.IsMagazine())
			{
				foundMag.ServerSetAmmoMax();
			}
		} 
	}
	
	static void SetFullStateWeapon(PlayerBase player)
	{
		EntityAI CurrentWeapon = player.GetHumanInventory().GetEntityInHands();
		if ( CurrentWeapon )
		{
			CurrentWeapon.RemoveAllAgents();
			CurrentWeapon.SetHealth( CurrentWeapon.GetMaxHealth( "", "" ) );
			Object Suppressor = Object.Cast(CurrentWeapon.GetAttachmentByConfigTypeName( "SuppressorBase" ));
			if( Suppressor )
			{
				Suppressor.SetHealth( Suppressor.GetMaxHealth( "", "" ) );
			}
			Magazine foundMag = Magazine.Cast(CurrentWeapon.GetAttachmentByConfigTypeName( "DefaultMagazine" ));
			if ( foundMag && foundMag.IsMagazine())
			{
				foundMag.ServerSetAmmoMax();
			}
		} 
		
	}
	//Player weapon in hands states

	//Player Healing
	static void HealPlayer(PlayerBase player)
	{
		Print("::: [AdminMod_Class] ::: HealPlayer ::: Player: " + player.GetIdentity().GetName() + ",  UID: " +player.GetIdentity().GetPlainId() + ", m_DiseaseCount = " + player.m_DiseaseCount);
		//player.PrintAgents();
		player.SetHealth(player.GetMaxHealth("", ""));
		player.m_DiseaseCount = 0;
		player.RemoveAllAgents();
		player.SetHealth("","Blood", player.GetMaxHealth("", "Blood"));
		player.GetStatHeatComfort().Set(0);
		player.GetStatTremor().Set(0);
		player.GetStatWet().Set(-1);
		player.GetStatEnergy().Set(1000);
		player.GetStatWater().Set(1000);
		player.GetStatStomachEnergy().Set(5000);
		player.GetStatStomachWater().Set(5000);
		player.GetStatStomachVolume().Set(0);
		player.GetStatDiet().Set(2500);
		player.GetStatSpecialty().Set(1);
		player.SetHealth(1000);
		player.SetBleedingBits(0);
		player.SetSynchDirty();
	}
	//Player Healing

	//Player Full Repair
	static void RepairPlayer(PlayerBase player)
	{
		SetFullStamina(player);
		SetFullState(player);
		SetFullHealth(player);
		HealPlayer(player); //HEALING
		
		SetFullHealthLoot(player);
		SetFullHealthWeapon(player);
		SetFullAmmo(player);
		Print("::: [AdminMod_Class] ::: RepairPlayer ::: Player: " + player.GetIdentity().GetName() + ",  UID: " +player.GetIdentity().GetPlainId() + ", m_DiseaseCount = " + player.m_DiseaseCount);
	}
	//Player Full Repair
	
	//AdminMod OnUpdate //Call from server mission OnUpdate
	static void OnUpdate()
	{
		
	}
	
	static void EOnFrame()
	{
		
	}
	
	static void ServerDebugFps()
	{
		Print("::: [AdminMod_Class] ::: AdmDebugFps() ::: Diag server: Fps: " + GetGame().GetFps().ToString() + " : TickTime: " + GetGame().GetTickTime().ToString());
	}

	//(FreeCamera)
	static void CreateFreeCam(PlayerIdentity Identity, string cameratype, string pos)
	{
		vector position = pos.ToVector();
		GetGame().SelectSpectator(Identity, cameratype, position);
		GetGame().UpdateSpectatorPosition(position);
	}
	
	static void CreateSpectator(PlayerIdentity Identity, PlayerBase Player, PlayerBase Target) //in progress
	{

	}

	static void DeleteFreeCam(PlayerIdentity Identity, PlayerBase Player)
	{
		GetGame().SelectPlayer(Identity, Player);
		string GodMode;
		g_Game.GetProfileString("GodMode"+Identity.GetPlainId(),GodMode);
		if (GodMode != "true") Player.SetAllowDamage(true);
		Player.SetSynchDirty();
	}
	//(FreeCamera)

	//Player control
	static void SetPlayerFreeze(bool freeze, PlayerBase player)
	{
	    player.GetInputController().OverrideMovementSpeed(freeze, 0);
		player.GetInputController().OverrideAimChangeX(freeze, 0);
		player.GetInputController().OverrideAimChangeY(freeze, 0);
		m_Freezed = freeze;
	}
	//Player control
	
	//SpawnCars
	static void SpawnHatchback(vector position, vector orientation)
	{
		Param1<string> Msgparam;
		string adm_msg;
		
		if (position[1] == 0) position = SnapToGround(position);
		position[0] = position[0] + 1.7;
		position[1] = position[1] + 0.001;
		position[2] = position[2] + 1.7;
		
		m_SpawnedObject = GetGame().CreateObject("OffroadHatchback", position);
		//m_SpawnedObject.SetPosition(position);
		//m_SpawnedObject.SetOrientation(orientation);
		//m_SpawnedObject.SetDirection(m_SpawnedObject.GetDirection());
		ResetCollision(m_SpawnedObject);
		EntityAI MyCar = EntityAI.Cast(m_SpawnedObject);
		if (MyCar)
		{
			MyCar.GetInventory().CreateAttachment("HatchbackWheel");
			MyCar.GetInventory().CreateAttachment("HatchbackWheel");
			MyCar.GetInventory().CreateAttachment("HatchbackWheel");
			MyCar.GetInventory().CreateAttachment("HatchbackWheel");
			MyCar.GetInventory().CreateAttachment("HatchbackDoors_Driver");
			MyCar.GetInventory().CreateAttachment("HatchbackDoors_CoDriver");
			MyCar.GetInventory().CreateAttachment("HatchbackHood");
			MyCar.GetInventory().CreateAttachment("HatchbackTrunk");
			MyCar.GetInventory().CreateAttachment("SparkPlug");
			MyCar.GetInventory().CreateAttachment("SparkPlug");
			MyCar.GetInventory().CreateAttachment("EngineBelt");
			MyCar.GetInventory().CreateAttachment("CarBattery");
			MyCar.GetInventory().CreateAttachment("CarRadiator");
			MyCar.GetInventory().CreateAttachment("HeadlightH7");
			MyCar.GetInventory().CreateAttachment("HeadlightH7");
			Car f_car = Car.Cast(MyCar); 
			f_car.Fill(CarFluid.FUEL, 1000);
			f_car.Fill(CarFluid.COOLANT, 1000);
			f_car.Fill(CarFluid.OIL, 1000);
			f_car.Fill(CarFluid.BRAKE, 1000);
			MyCar.SetHealth(1000);
			MyCar.SetAllowDamage(true); //default //use /objdamage on | off for enable/disable damage
			adm_msg = "OffroadHatchback Spawned!";
		}
		else
		{
			adm_msg = "OffroadHatchback Error!";
		}
		Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
	}
	
	static void SpawnSedan(vector position, vector orientation)
	{
		Param1<string> Msgparam;
		string adm_msg;
		
		if (position[1] == 0) position = SnapToGround(position);
		position[0] = position[0] + 1.7;
		position[1] = position[1] + 0.1;
		position[2] = position[2] + 1.7;
		
		m_SpawnedObject = GetGame().CreateObject("CivilianSedan", position);
		//m_SpawnedObject.SetPosition(position);
		//m_SpawnedObject.SetOrientation(orientation);
		//m_SpawnedObject.SetDirection(m_SpawnedObject.GetDirection());
		ResetCollision(m_SpawnedObject);
		EntityAI MyCar = EntityAI.Cast(m_SpawnedObject);
		if (MyCar)
		{
			MyCar.GetInventory().CreateAttachment("CivSedanWheel");
			MyCar.GetInventory().CreateAttachment("CivSedanWheel");
			MyCar.GetInventory().CreateAttachment("CivSedanWheel");
			MyCar.GetInventory().CreateAttachment("CivSedanWheel");
			MyCar.GetInventory().CreateAttachment("CivSedanDoors_Driver");
			MyCar.GetInventory().CreateAttachment("CivSedanDoors_CoDriver");
			MyCar.GetInventory().CreateAttachment("CivSedanDoors_BackLeft");
			MyCar.GetInventory().CreateAttachment("CivSedanDoors_BackRight");
			MyCar.GetInventory().CreateAttachment("CivSedanHood");
			MyCar.GetInventory().CreateAttachment("CivSedanTrunk");
			MyCar.GetInventory().CreateAttachment("SparkPlug");
			MyCar.GetInventory().CreateAttachment("SparkPlug");
			MyCar.GetInventory().CreateAttachment("EngineBelt");
			MyCar.GetInventory().CreateAttachment("CarBattery");
			MyCar.GetInventory().CreateAttachment("CarRadiator");
			MyCar.GetInventory().CreateAttachment("HeadlightH7");
			MyCar.GetInventory().CreateAttachment("HeadlightH7");
			MyCar.GetInventory().CreateAttachment("TireRepairKit");
			MyCar.GetInventory().CreateAttachment("TireRepairKit");
			Car f_car = Car.Cast(MyCar); 
			f_car.Fill(CarFluid.FUEL, 1000);
			f_car.Fill(CarFluid.COOLANT, 1000);
			f_car.Fill(CarFluid.OIL, 1000);
			f_car.Fill(CarFluid.BRAKE, 1000);
			MyCar.SetHealth(1000);
			MyCar.SetAllowDamage(true); //default //use /objdamage on | off for enable/disable damage
			adm_msg = "CivilianSedan Spawned!";
		}
		else
		{
			adm_msg = "CivilianSedan Error!";
		}
		Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
	}

	static void SpawnV3S(vector position, vector orientation)
	{
		Param1<string> Msgparam;
		string adm_msg;
		
		if (position[1] == 0) position = SnapToGround(position);
		position[0] = position[0] + 1.7;
		position[1] = position[1] + 0.1;
		position[2] = position[2] + 1.7;
		
		m_SpawnedObject = GetGame().CreateObject("V3S_Cargo", position);
		//m_SpawnedObject.SetPosition(position);
		//m_SpawnedObject.SetOrientation(orientation);
		//m_SpawnedObject.SetDirection(m_SpawnedObject.GetDirection());
		ResetCollision(m_SpawnedObject);
		EntityAI MyCar = EntityAI.Cast(m_SpawnedObject);
		if (MyCar)
		{
			MyCar.GetInventory().CreateAttachment("V3SWheel");
			MyCar.GetInventory().CreateAttachment("V3SWheel");
			MyCar.GetInventory().CreateAttachment("V3SWheelDouble");
			MyCar.GetInventory().CreateAttachment("V3SWheelDouble");
			MyCar.GetInventory().CreateAttachment("V3SWheelDouble");
			MyCar.GetInventory().CreateAttachment("V3SWheelDouble");
			MyCar.GetInventory().CreateAttachment("V3SWheel");
			MyCar.GetInventory().CreateAttachment("V3SWheel");
			MyCar.GetInventory().CreateAttachment("V3SDoors_Driver");
			MyCar.GetInventory().CreateAttachment("V3SDoors_CoDriver");
			MyCar.GetInventory().CreateAttachment("V3SHood");
			MyCar.GetInventory().CreateAttachment("GlowPlug");
			MyCar.GetInventory().CreateAttachment("GlowPlug");
			MyCar.GetInventory().CreateAttachment("EngineBelt");
			MyCar.GetInventory().CreateAttachment("TruckRadiator");
			MyCar.GetInventory().CreateAttachment("TruckBattery");
			MyCar.GetInventory().CreateAttachment("TruckBattery");
			MyCar.GetInventory().CreateAttachment("HeadlightH7");
			MyCar.GetInventory().CreateAttachment("HeadlightH7");
			MyCar.GetInventory().CreateAttachment("TruckExhaust");
			MyCar.GetInventory().CreateAttachment("TireRepairKit");
			MyCar.GetInventory().CreateAttachment("TireRepairKit");
			Car f_car = Car.Cast(MyCar); 
			f_car.Fill(CarFluid.FUEL, 1000);
			f_car.Fill(CarFluid.COOLANT, 1000);
			f_car.Fill(CarFluid.OIL, 1000);
			f_car.Fill(CarFluid.BRAKE, 1000);
			MyCar.SetHealth(1000);
			MyCar.SetAllowDamage(true); //default //use /objdamage on | off for enable/disable damage
			adm_msg = "CivilianSedan Spawned!";
		}
		else
		{
			adm_msg = "CivilianSedan Error!";
		}
		Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
	}
	
	static void refuelCar(string cData)
	{
		ref array<Object> nearest_objects = new array<Object>;
		ref array<CargoBase> proxy_cargos = new array<CargoBase>;
		Car toBeFilled;
		GetGame().GetObjectsAtPosition ( AdminPlayer.GetPosition(), 15, nearest_objects, proxy_cargos );
			
		for (int i = 0; i < nearest_objects.Count(); i++) 
		{
			if (nearest_objects[i].IsKindOf("CarScript") || nearest_objects[i].IsKindOf("Car")) 
			{
				toBeFilled = Car.Cast(nearest_objects[i]);
				float fuelReq = toBeFilled.GetFluidCapacity( CarFluid.FUEL ) - (toBeFilled.GetFluidCapacity( CarFluid.FUEL ) * toBeFilled.GetFluidFraction( CarFluid.FUEL ));
				float oilReq = toBeFilled.GetFluidCapacity( CarFluid.OIL ) - (toBeFilled.GetFluidCapacity( CarFluid.OIL ) * toBeFilled.GetFluidFraction( CarFluid.OIL ));
				float coolantReq = toBeFilled.GetFluidCapacity( CarFluid.COOLANT ) - (toBeFilled.GetFluidCapacity( CarFluid.COOLANT ) * toBeFilled.GetFluidFraction( CarFluid.COOLANT ));
				float brakeReq = toBeFilled.GetFluidCapacity( CarFluid.BRAKE ) - (toBeFilled.GetFluidCapacity( CarFluid.BRAKE ) * toBeFilled.GetFluidFraction( CarFluid.BRAKE ));
				toBeFilled.Fill( CarFluid.FUEL, fuelReq );
				toBeFilled.Fill( CarFluid.OIL, oilReq );
				toBeFilled.Fill( CarFluid.COOLANT, coolantReq );
				toBeFilled.Fill( CarFluid.BRAKE, brakeReq );
				Param1<string> Msgparam = new Param1<string>( nearest_objects.Get(i).GetType() + " refueled: " +fuelReq+ "L added, all fluids maxed" );
				GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
			}
		}
	}
	//SpawnCars
	
	//Inventory
	static void inventoryCheck(string cData)
	{
		if (cData.Length() == 0 && AdminUID) cData = AdminUID; //defined in class
		if (cData.Length() > 0)
		{
			string Msg;
			int i_msgDelay = msgDelay; //defined in class
			EntityAI attachment, subattachment = NULL;
			EntityAI itemTop, itemBottom, itemShoes, itemBag, itemHat, itemMask, itemInHands = NULL;
			ItemBase itemBs, subItem = NULL;
			string className, subClassName, subSubClassName = "";
			array<EntityAI> itemsArray;
			int AttCount, SubAttCount, SubItemCount;
			
			array<Man> players = new array<Man>;
			GetGame().GetPlayers( players );
			for ( int i = 0; i < players.Count(); ++i )
			{
				PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
				PlayerIdentity selectedIdentity = selectedPlayer.GetIdentity();
				if ( selectedIdentity.GetName() == cData || selectedIdentity.GetPlainId() == cData || selectedIdentity.GetPlayerId() == cData.ToInt() )
				{
					Print("::: [AdminMod_Class] ::: inventoryCheck: " + selectedIdentity.GetName());
					Msg = "Inventory: " + selectedIdentity.GetName();
					AT_Send_Delayed_Message(AdminPlayer, Msg, i_msgDelay, 1);
					
					AttCount = selectedPlayer.GetInventory().AttachmentCount();
					Print("::: [AdminMod_Class] ::: inventoryCheck: Player AttCount = " + AttCount);
					for ( int a	=	0; a < AttCount; a++ )
					{
						//Player attachments
						attachment = selectedPlayer.GetInventory().GetAttachmentFromIndex(a);
						Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment = " + attachment.ToString());
						
						if ( attachment.IsItemBase() )
						{
							Print("::: [AdminMod_Class] ::: inventoryCheck ::: ATTACHMENT ::: ");
							itemBs =	ItemBase.Cast(attachment);
							className =	itemBs.GetType();
							Msg = "Att name: " + className;
							Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment className = " + className);
							i_msgDelay = i_msgDelay + 1;
							AT_Send_Delayed_Message(AdminPlayer, Msg, i_msgDelay, 1);
							//SubAttachemnts
							SubAttCount = attachment.GetInventory().AttachmentCount(); //How many subattachments in player attachment - count for cycle
							if (SubAttCount > 0)
							{
								Print("::: [AdminMod_Class] ::: inventoryCheck :::  ATTACHMENT ::: SUBATTACHMENTS ::: ");
								Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment '" + className + "' SubAttCount = " + SubAttCount);
								Print("::: [AdminMod_Class] ::: inventoryCheck :::  ATTACHMENT ::: SUBATTACHMENTS PARSING ::: ");
								for ( int b	= 0; b < SubAttCount; b++ )
								{
									subattachment = attachment.GetInventory().GetAttachmentFromIndex(b); // Get subattachment from attachment

									if ( subattachment == attachment )
									{
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment " + attachment.ToString() + " the same as subattachment = " + subattachment.ToString());
									}
									else
									{
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment '" + className + "' subattachment = " + subattachment.ToString());
										subItem = ItemBase.Cast(subattachment); //Cast subattachment to item
										subClassName =	subItem.GetType(); //Get class name of subattachment
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment '" + className + "' subattachment subClassName = " + subClassName);
										Msg = "Att SubAtt: " + subClassName;
										i_msgDelay = i_msgDelay + 1;
										AT_Send_Delayed_Message(AdminPlayer, Msg, i_msgDelay, 1);
										//SubAttachments of SubAttachments
										
										//SubItems of SubAttachments
									}
								}
								i_msgDelay = i_msgDelay + 1;
							}

							//SubItems
							itemsArray = new array<EntityAI>;
							attachment.GetInventory().EnumerateInventory(InventoryTraversalType.PREORDER, itemsArray);
							SubItemCount = itemsArray.Count();
							if ( SubItemCount > 0 )
							{
								Print("::: [AdminMod_Class] ::: inventoryCheck :::  ATTACHMENT ::: SUBITEMS ::: ");
								Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment '" + className+ "' SubItemCount = " + SubItemCount);
								Print("::: [AdminMod_Class] ::: inventoryCheck :::  ATTACHMENT ::: SUBITEMS PARSING ::: ");
								for ( b = 0; b < SubItemCount; b++ )
								{
									subItem = ItemBase.Cast(itemsArray.Get(b)); //Cast subattachment to item
									if ( subItem == attachment )
									{
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment " + attachment.ToString() + " the same as subItem = " + subItem.ToString());
									}
									else
									{
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment '" + className + "' subItem = " + subItem.ToString());
										subClassName =	subItem.GetType(); //Get class name of subitem
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player attachment '" + className + "' subitem subClassName = " + subClassName);
										Msg = "Att SubItem: " + subClassName;
										i_msgDelay = i_msgDelay + 1;
										AT_Send_Delayed_Message(AdminPlayer, Msg, i_msgDelay, 1);
									}
									//SubItems of SubItems
									
									//Subattachemts of SubItems
								}
								i_msgDelay = i_msgDelay + 1;
							} 
						} 
					}
					//Item in Hands
					itemInHands = selectedPlayer.GetHumanInventory().GetEntityInHands();
					if (itemInHands)
					{
						Print("::: [AdminMod_Class] ::: inventoryCheck ::: ITEM IN HANDS ::: ");
						if ( itemInHands.IsItemBase() )
						{
							itemBs =	ItemBase.Cast(itemInHands);
							className =	itemBs.GetType();
							Print("::: [AdminMod_Class] ::: inventoryCheck: Player itemInHands className = " + className);
							Msg = "Hands: " + className;
							i_msgDelay = i_msgDelay + 1;
							AT_Send_Delayed_Message(AdminPlayer, Msg, i_msgDelay, 1);
							
							//Item in Hands SubAttachments
							SubAttCount = itemInHands.GetInventory().AttachmentCount(); //How many subattachments in player itemInHands - count for cycle
							if ( SubAttCount > 0 )
							{
								Print("::: [AdminMod_Class] ::: inventoryCheck ::: ITEM IN HANDS ::: SUBATTACHMENTS ::: ");
								Print("::: [AdminMod_Class] ::: inventoryCheck: Player ITEM IN HANDS '" + className + "' SubAttCount = " + SubAttCount);
								Print("::: [AdminMod_Class] ::: inventoryCheck ::: ITEM IN HANDS ::: SUBATTACHMENTS PARSING ::: ");
								for ( b = 0; b < SubAttCount; b++ )
								{
									subattachment = itemInHands.GetInventory().GetAttachmentFromIndex(b); // Get subattachment from itemInHands
									if ( subattachment == itemInHands )
									{
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player itemInHands " + itemInHands.ToString() + " the same as subattachment = " + subattachment.ToString());
									} 
									else
									{
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player itemInHands '" + className + "' subattachment = " + subattachment.ToString());
										subItem = ItemBase.Cast(subattachment); //Cast subattachment to item
										subClassName =	subItem.GetType(); //Get class name of subattachment
										Print("::: [AdminMod_Class] ::: inventoryCheck: Player itemInHands '" + className + "' subattachment subClassName = " + subClassName);
										Msg = "Hands SubAtt: " + subClassName;
										i_msgDelay = i_msgDelay + 1;
										AT_Send_Delayed_Message(AdminPlayer, Msg, i_msgDelay, 1);
										//Item in Hands SubAttachments SubItems
									}
								}
							}
						}
					}
					break;
				}
				//next player
			}
		}
	}
	
	static void checkItem(string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (cData.Length() > 3 && !cData.Contains("  ") && cData.Contains(" "))
		{
			array<string> cCmdParams = new array<string>;
			cData.Split(" ",cCmdParams);
			cData = cCmdParams.Get(0);
			if (cCmdParams.Count() == 2)
			{
				array<Man> players = new array<Man>;
				GetGame().GetPlayers( players );
				for ( int i = 0; i < players.Count(); ++i )
				{
					PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
					PlayerIdentity selectedIdentity = selectedPlayer.GetIdentity();
					if ( selectedIdentity.GetName() == cData || selectedIdentity.GetPlainId() == cData || selectedIdentity.GetPlayerId() == cData.ToInt() )
					{
						adm_msg = "Player: " + selectedIdentity.GetName();
						private bool itemFound = checkInInvenroty(selectedPlayer, cCmdParams.Get(1));
						if (itemFound)
						{
							adm_msg = "Item: " + cCmdParams.Get(1) + " found";
						}
						else
						{
							adm_msg = "Item: " + cCmdParams.Get(1) + " not found";
						}
					break;
					}
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Parameter error!";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	//Function for find item in player inventory v2!
	static bool checkInInvenroty(PlayerBase player, string itemClass)
	{
		EntityAI attachment, subattachment; //attachments variables
		int AttCount, SubAttCount; //attachments count variables
		ItemBase subItem; //Item variable
		string className; //Item class name variable
		private bool itemFound = false; // Result / default is false
		
		AttCount = player.GetInventory().AttachmentCount(); //Player Attachments (items on player, like clothes, backpack etc.) count for cycle
		for ( int i	= 0; i < AttCount; i++ ) //Check Attachments cycle
		{
			//1st level attachments
			attachment = player.GetInventory().GetAttachmentFromIndex(i); // Get player attachment
			if ( attachment.IsItemBase() || attachment.IsClothing() || attachment.IsContainer() )
			{
				//1st level attachment
				subItem = ItemBase.Cast(attachment);
				className =	subItem.GetType();
				if ( className == itemClass )
				{
					itemFound = true;
					break;
				}
				
				//2nd level attachments
				SubAttCount = attachment.GetInventory().AttachmentCount(); //How many subattachments in player attachment - count for cycle
				for ( int j	= 0; j < SubAttCount; j++ )
				{
					//2st level attachment
					subattachment = attachment.GetInventory().GetAttachmentFromIndex(j); // Get subattachment in attachment
					subItem = ItemBase.Cast(subattachment); //Cast subattachment to item
					className =	subItem.GetType(); //Get class name of subattachment
					if ( className == itemClass ) //Check class of item (subattachment)
					{
						itemFound = true; //Item found!
						break; //break 2nd cycle
					}
				}
				//
			}
			//
			if (itemFound) break; //break 1st cycle
		}
		return itemFound; //return result
	}

	//Chech item and item state
	static ItemBase checkItemAndState(PlayerBase player, string itemClass, bool subAttCheck, out float itemHealthLevel)
	{
		EntityAI attachment, subattachment; //attachments variables
		int AttCount, SubAttCount; //attachments count variables
		ItemBase subItem; //Item variable
		string className; //Item class name variable
		private bool itemFound = false;
		
		AttCount = player.GetInventory().AttachmentCount(); //Player Attachments (items on player, like clothes, backpack etc.) count for cycle
		for ( int i	= 0; i < AttCount; i++ ) //Check Attachments cycle
		{
			//1st level attachments
			attachment = player.GetInventory().GetAttachmentFromIndex(i); // Get player attachment
			if ( attachment.IsItemBase() || attachment.IsClothing() || attachment.IsContainer() )
			{
				//1st level attachment
				subItem = ItemBase.Cast(attachment);
				className =	subItem.GetType();
				if ( className == itemClass )
				{
					itemFound = true; //Item found!
					break; //break 2nd cycle
				}
				if (subAttCheck)
				{
					//2nd level attachments
					SubAttCount = attachment.GetInventory().AttachmentCount(); //How many subattachments in player attachment - count for cycle
					for ( int j	= 0; j < SubAttCount; j++ )
					{
						//2st level attachment
						subattachment = attachment.GetInventory().GetAttachmentFromIndex(j); // Get subattachment in attachment
						subItem = ItemBase.Cast(subattachment); //Cast subattachment to item
						className =	subItem.GetType(); //Get class name of subattachment
						if ( className == itemClass ) //Check class of item (subattachment)
						{
							itemFound = true; //Item found!
							break; //break 2nd cycle
						}
					}
				}
	
			}
			if (itemFound) break; //break 1st cycle
		}
		if (itemFound)
		{
			itemHealthLevel = subItem.GetHealthLevel();	
			return subItem; //return founded item
		}
		else
		{
			itemHealthLevel = 0;
			return NULL;
		}
	}
	//Inventory
	
	//Players
	static void listPlayers()
	{
		int i_msgDelay = msgDelay; //defined in class
		array<Man> players = new array<Man>;
		GetGame().GetPlayers( players );
		string Msg = "Players on server: " + players.Count();
		AT_Send_Delayed_Message(AdminPlayer, Msg, 0, 1);
		string Msg0;
		for ( int i = 0; i < players.Count(); ++i )
		{
			PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
			if (selectedPlayer.GetIdentity())
			{
				if (admFuncDebug) AdminFunctionsDebug("listPlayers()", "Debug: i_msgDelay = " + i_msgDelay + ", i = " + i + " => timedelay = " + (((i_msgDelay * i) + i + 0.5) * 1000).ToString());

				PlayerIdentity selectedIdentity = selectedPlayer.GetIdentity();
				Msg = i.ToString() + ":Name: " + selectedIdentity.GetName();
				AT_Send_Delayed_Message(AdminPlayer, Msg, ((i_msgDelay * i) + i + 0.5), 1);
				Msg = i.ToString() + ":ID  : " + selectedIdentity.GetPlayerId() + ", UID: " + selectedIdentity.GetPlainId();
				AT_Send_Delayed_Message(AdminPlayer, Msg, ((i_msgDelay * i) + i + 1), 1);
				Msg = i.ToString() + ":POS : " + VectorToVectorString(selectedPlayer.GetPosition());
				AT_Send_Delayed_Message(AdminPlayer, Msg, ((i_msgDelay * i) + i + 1.5), 1);
				i_msgDelay = i_msgDelay++;
			}
		}
	}
	
	static void listPlayersIDs()
	{
		array<Man> players = new array<Man>;
		GetGame().GetPlayers( players );
		string adm_msg = "Players on server: " + players.Count();
		at_Send_Chat_Message(AdminPlayer, adm_msg, 1);
		string ids_List = "";
		int a = 0;
		for ( int i = 0; i < players.Count(); ++i )
		{
			PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
			if (selectedPlayer.GetIdentity())
			{
				ids_List = ids_List + selectedPlayer.GetIdentity().GetPlayerId().ToString() + "; ";
				a = a + 1;
				if (a > 11 || i >= players.Count());
				{
					Print("::: [AdminMod_Class] ::: listPlayersIDs() ::: a = " + a.ToString() + ", ids_List = " + ids_List);
					adm_msg = a.ToString() + ":IDs: " + ids_List;
					at_Send_Chat_Message(AdminPlayer, adm_msg, 1);
					ids_List = "";
					a = 0;
				}
			}
		}
	}
	
	static void playerInfo(string cData)
	{
		PlayerBase selectedPlayer;
		
	}
	//Players
	
	//Objects
	static void checkObjects(string cData, vector position)
	{
		int radius;
		int i_msgDelay = msgDelay; //msgDelay defined in class
		Object object = NULL;
		string className = "";
		string adm_msg, Msg0, Msg1, Msg2, Msg3;
		if ( cData.Length() > 0 && !cData.Contains("  ") )
		{
			if (cData.Contains("players"))
			{
				array<string> cCmdParams = new array<string>;
				cData.Split(" ",cCmdParams);
				cData = cCmdParams.Get(0);
				if (cCmdParams.Count() == 2)
				{
					string cData2 = cCmdParams.Get(1);
				}
				Print("::: [AdminMod_Class] ::: checkObjects::: cData = " + cData + ", cData2 = " + cData2);
				cCmdParams.Clear();
			}
			radius = cData.ToInt();
			m_NearestObjectsList = new array<Object>; //m_NearestObjectsLis Defined in class
			array<CargoBase> proxy_cargos = new array<CargoBase>;
			if ((radius > 0 && radius <= maxCheckRadius)) // maxCheckRadius defined in class
			{
				GetGame().GetObjectsAtPosition(position, radius, m_NearestObjectsList, proxy_cargos); //ВНИМАНИЕ! БОЛЬШОЙ РАДИУС ГРУЗИТ СЕРВЕР!!!
				for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
				{
					object = m_NearestObjectsList.Get(i);
					className = object.GetType();
					Msg1 = "";
					Msg2 = "";
					Msg3 = "";
					if (object)
					{
						if (className != "")
						{
							if (cData2 == "players" && object.IsKindOf("SurvivorBase"))
							{
								Msg1 = "Player:" + i + ": " + PlayerBase.Cast(object).GetIdentity().GetName();
								Msg2 = "Object:" + i + ": " + object.ToString();
							}
							else
							{
								Msg1 = "Class :" + i + ": " + className;
								Msg2 = "Object:" + i + ": " + object.ToString();
							}
						}
						else
						{
							Msg1 = "Object:" + i + ": " + object.ToString();
						}
						Msg3 = "Pos:" + i + ": " +  VectorToVectorString(object.GetPosition());
					}
					else
					{
						Msg1 = "Object:" + i + ": disappeared!";
					}
					
					if (admFuncDebug) AdminFunctionsDebug("checkObjects()", "Debug: i_msgDelay = " + i_msgDelay + ", i = " + i + " => timedelay = " + (((i_msgDelay * i) + i + 0.5) * 1000).ToString());
					
					if (Msg1) AT_Send_Delayed_Message(AdminPlayer, Msg1, ((i_msgDelay * i) + i + 0.5), 1);
					if (Msg2) AT_Send_Delayed_Message(AdminPlayer, Msg2, ((i_msgDelay * i) + i + 1.0), 1);
					if (Msg3) AT_Send_Delayed_Message(AdminPlayer, Msg3, ((i_msgDelay * i) + i + 1.5), 1);
					i_msgDelay = i_msgDelay++;
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Command error!";
		}
		if (adm_msg)
		{
			Param1<string> Msgparam = new Param1<string>( adm_msg );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	
	static void listObjects(string cData)
	{
		int i_msgDelay = msgDelay;
		Object object = NULL;
		string adm_msg, adm_msg1, Msg1, Msg2 = "";
		
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains(" "))
			{
				if ( cData.ToInt() >= 0 && cData.ToInt() <= m_NearestObjectsList.Count()) //object by number in array
				{
					object = m_NearestObjectsList.Get(cData.ToInt());
					if (object)
					{
						adm_msg   = "Class :" + object.GetType();
						adm_msg1  = "Object:" + object.ToString();
					}
					else
					{
						adm_msg = "Object disappeared!";
					}
				}
				else
				{
					adm_msg = "Parameter error!";
				}
			}
			else //all objects
			{
				for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
				{
					adm_msg = "Objects count: " + m_NearestObjectsList.Count().ToString();
					object = m_NearestObjectsList.Get(i);
					if (object)
					{
						Msg1 = "Class :" + i + ": " + object.GetType();
						Msg2 = "Object:" + i + ": " + object.ToString();
					}
					else
					{
						Msg1 = "Object:" + i + ": disappeared!";
					}
					if (Msg1) AT_Send_Delayed_Message(AdminPlayer, Msg1, ((i_msgDelay * i) + i + 0.5), 1);
					if (Msg2) AT_Send_Delayed_Message(AdminPlayer, Msg2, ((i_msgDelay * i) + i + 1.0), 1);
					i_msgDelay = i_msgDelay++; //i_msgDelay = i_msgDelay++;
				}
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	
	static void deleteObject(string cData)
	{
		Object object;
		string adm_msg, adm_msg1 = "";
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains(" "))
			{
				if ( cData.ToInt() >= 0 && cData.ToInt() <= m_NearestObjectsList.Count()) //object by number in array
				{
					object = m_NearestObjectsList.Get(cData.ToInt());
					if (object)
					{
						adm_msg = "Object found: " + object.ToString();
						GetGame().ObjectDelete(object);
						adm_msg1 = "Object must be deleted!";
					}
					else
					{
						adm_msg = "Object not found: " + cData;
					}
				}
				else //object by name
				{
					for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
					{
						if (m_NearestObjectsList.Get(i).ToString() == cData)
						{
							object = m_NearestObjectsList.Get(i);
							if (object)
							{
								adm_msg = "Object found:" + i + ": "+ object.ToString();
								GetGame().ObjectDelete(object);
								adm_msg1 = "Object must be deleted!";
								break;
							}
						}
					}
					if (!adm_msg)
					{
						adm_msg = "Object not found: " + cData;
					}
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void objectInfo(string cData) //!!!
	{
		Object object;
		string adm_msg, adm_msg0, adm_msg1, adm_msg2, adm_msg3, adm_msg4 = "";
		int netidlow, netidhigh;
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains(" "))
			{
				if ( cData.ToInt() >= 0 && cData.ToInt() <= m_NearestObjectsList.Count()) //object by number in array
				{
					object = m_NearestObjectsList.Get(cData.ToInt());
					if (object)
					{
						adm_msg  = "Object: " + object.ToString();
						adm_msg0 = "Object posit: " + VectorToVectorString(object.GetPosition());
						adm_msg1 = "Object orien: " + VectorToVectorString(object.GetOrientation());
						adm_msg2 = "Object direc: " + VectorToVectorString(object.GetDirection());
						adm_msg3 = "Object healh: " + object.GetHealth().ToString();
						object.GetNetworkID(netidlow,netidhigh);
						adm_msg4 = "Object NetId: [" + netidlow.ToString() + ":" + netidhigh.ToString() + "]";
					}
					else
					{
						adm_msg = "Object not found: " + cData;
					}
				}
				else //object by name
				{
					for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
					{
						if (m_NearestObjectsList.Get(i).ToString() == cData)
						{
							object = m_NearestObjectsList.Get(i);
							if (object)
							{
								adm_msg = "Object:" + i + ": "+ object.ToString();
								adm_msg0 = "Object pos: " + VectorToVectorString(object.GetPosition());
								adm_msg1 = "Object ori: " + VectorToVectorString(object.GetOrientation());
								adm_msg2 = "Object dir: " + VectorToVectorString(object.GetDirection());
								adm_msg3 = "Object hel: " + object.GetHealth().ToString();
								object.GetNetworkID(netidlow,netidhigh);
								adm_msg4 = "Object Nid: [ " + netidlow.ToString() + " : " +  netidhigh.ToString() + " ]";
								break;
							}
						}
					}
					if (!adm_msg)
					{
						adm_msg = "Object not found: " + cData;
					}
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg0)
		{
			Msgparam = new Param1<string>( adm_msg0 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg2)
		{
			Msgparam = new Param1<string>( adm_msg2 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg3)
		{
			Msgparam = new Param1<string>( adm_msg3 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg4)
		{
			Msgparam = new Param1<string>( adm_msg4 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void objectPosition(string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains("  "))
			{
				array<string> cCmdParams = new array<string>;
				Object object;
				vector pos;
				bool positioning = true;
				cData.Split(" ",cCmdParams);
				string strObject = cCmdParams[0];
				Print("::: [AdminMod_Class] ::: objectPosition(): cData = " + cData + ", strObject = " + strObject + ", cCmdParams.Count() = " + cCmdParams.Count());
				if (cCmdParams.Count() == 1 || cCmdParams.Count() == 2)
				{
					pos = AdminPlayer.GetPosition();
					pos[0] = pos[0] + 1;
					pos[2] = pos[2] + 1;
				}
				else if (cCmdParams.Count() == 4)
				{
					pos = (cCmdParams.Get(1) + " " + cCmdParams.Get(2) + " " + cCmdParams.Get(3)).ToVector();
					//if (pos[1] == 0) pos = SnapToGround(pos);
					pos = SnapToGround(pos);
				}
				else
				{
					positioning = false;
				}
				if (pos[0] > 0 && pos[1] > 0 && pos[2] > 0 && positioning)
				{
					if ( strObject.ToInt() >= 0 && strObject.ToInt() <= (m_NearestObjectsList.Count())) //object by number in array
					{
						object = m_NearestObjectsList.Get(strObject.ToInt());
						if (object)
						{
							if (cCmdParams.Count() == 2)
							{
								pos = object.GetPosition();
								pos[1] = cCmdParams.Get(1).ToFloat();
								pos = SnapToGround(pos);
							}
							object.SetPosition(pos);
							object.SetOrientation(object.GetOrientation());
							ResetCollision(object);
							adm_msg = "Object: " + object.ToString();
							adm_msg1 = "Object new pos: " + VectorToVectorString(object.GetPosition());
						}
					}
					else //object by name
					{
						for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
						{
							if (m_NearestObjectsList.Get(i).ToString() == strObject)
							{
								object = m_NearestObjectsList.Get(i);
								if (object)
								{
									if (cCmdParams.Count() == 2)
									{
										pos = object.GetPosition();
										pos[1] = cCmdParams.Get(1).ToFloat();
										pos = SnapToGround(pos);
									}
									object.SetPosition(pos);
									object.SetOrientation(object.GetOrientation());
									ResetCollision(object);
									adm_msg = "Object:" + i + ": " + object.ToString();
									adm_msg1 = "Object new pos: " + VectorToVectorString(object.GetPosition());
									break;
								}
							}
						}
					}
					if (!adm_msg)
					{
						adm_msg = "Object not found: " + strObject;
					}
					else
					{
						AdminPlayer.SetSynchDirty();
					}
				}
				else
				{
					adm_msg = "Parameter error!";
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void objectOrientation(string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains("  "))
			{
				array<string> cCmdParams = new array<string>;
				Object object;
				vector orient;
				bool positioning = true;
				cData.Split(" ",cCmdParams);
				string strObject = cCmdParams[0];
				Print("::: [AdminMod_Class] ::: objectOrientation(): cData = " + cData + ", strObject = " + strObject + ", cCmdParams.Count() = " + cCmdParams.Count());
				if (cCmdParams.Count() == 1)
				{
					orient = AdminPlayer.GetOrientation();
				}
				else if (cCmdParams.Count() == 4)
				{
					orient = (cCmdParams.Get(1) + " " + cCmdParams.Get(2) + " " + cCmdParams.Get(3)).ToVector();
				}
				else
				{
					positioning = false;
				}
				if (positioning)
				{
					if ( strObject.ToInt() >= 0 && strObject.ToInt() <= (m_NearestObjectsList.Count())) //object by number in array
					{
						object = m_NearestObjectsList.Get(strObject.ToInt());
						if (object)
						{
							object.SetOrientation(orient);
							ResetCollision(object);
							adm_msg = "Object: " + object.ToString();
							adm_msg1 = "Object new orient: " + VectorToVectorString(object.GetOrientation());
						}
					}
					else //object by name
					{
						for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
						{
							if (m_NearestObjectsList.Get(i).ToString() == strObject)
							{
								object = m_NearestObjectsList.Get(i);
								if (object)
								{
									object.SetOrientation(orient);
									ResetCollision(object);
									adm_msg = "Object:" + i + ": " + object.ToString();
									adm_msg1 = "Object new orient: " + VectorToVectorString(object.GetOrientation());
									break;
								}
							}
						}
					}
					if (!adm_msg)
					{
						adm_msg = "Object not found: " + strObject;
					}
					else
					{
						AdminPlayer.SetSynchDirty();
					}
				}
				else
				{
					adm_msg = "Parameter error!";
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void objectDirection(string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains("  "))
			{
				array<string> cCmdParams = new array<string>;
				Object object;
				vector direct;
				bool positioning = true;
				cData.Split(" ",cCmdParams);
				string strObject = cCmdParams[0];
				
				Print("::: [AdminMod_Class] ::: objectOrientation(): cData = " + cData + ", strObject = " + strObject + ", cCmdParams.Count() = " + cCmdParams.Count());
				
				if (cCmdParams.Count() == 1)
				{
					direct = AdminPlayer.GetDirection();
				}
				else if (cCmdParams.Count() == 4)
				{
					direct = (cCmdParams.Get(1) + " " + cCmdParams.Get(2) + " " + cCmdParams.Get(3)).ToVector();
				}
				else
				{
					positioning = false;
				}
				if (positioning)
				{
					if ( strObject.ToInt() >= 0 && strObject.ToInt() <= (m_NearestObjectsList.Count())) //object by number in array
					{
						object = m_NearestObjectsList.Get(strObject.ToInt());
						if (object)
						{
							object.SetDirection(direct);
							adm_msg = "Object: " + object.ToString();
							adm_msg1 = "Object new direct: " + VectorToVectorString(object.GetDirection());
						}
					}
					else //object by name
					{
						for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
						{
							if (m_NearestObjectsList.Get(i).ToString() == strObject)
							{
								object = m_NearestObjectsList.Get(i);
								if (object)
								{
									object.SetDirection(direct);
									adm_msg = "Object:" + i + ": " + object.ToString();
									adm_msg1 = "Object new direct: " + VectorToVectorString(object.GetDirection());
									break;
								}
							}
						}
					}
					if (!adm_msg)
					{
						adm_msg = "Object not found: " + strObject;
					}
					else
					{
						AdminPlayer.SetSynchDirty();
					}
				}
				else
				{
					adm_msg = "Parameter error!";
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void objectSetAllowDamage(string cData)
	{
		string dmg, adm_msg = "";
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains("  "))
			{
				array<string> cCmdParams = new array<string>;
				Object object;
				cData.Split(" ",cCmdParams);
				string strObject = cCmdParams[0];
				if (cCmdParams.Count() > 1)	dmg = cCmdParams[1];
				
				if ( strObject.ToInt() >= 0 && strObject.ToInt() <= (m_NearestObjectsList.Count())) //object by number in array
				{
					object = m_NearestObjectsList.Get(strObject.ToInt());
					if (object)
					{
						adm_msg = "Object: " + object.ToString();
						spawnedObjectSetAllowDamage(object, dmg);
					}
					else
					{
						adm_msg = "Object not found: " + strObject;
					}
				}
				else //object by name
				{
					for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
					{
						if (m_NearestObjectsList.Get(i).ToString() == strObject)
						{
							object = m_NearestObjectsList.Get(i);
							if (object)
							{
								adm_msg = "Object:" + i + ": " + object.ToString();
								spawnedObjectSetAllowDamage(object, dmg);
								break;
							}
						}
					}
					if (!adm_msg)
					{
					adm_msg = "Object not found: " + strObject;
					}
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
	}

	static void objectHealth(string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (m_NearestObjectsList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains("  "))
			{
				array<string> cCmdParams = new array<string>;
				Object object;
				float heal;
				bool healing = true;
				cData.Split(" ",cCmdParams);
				string strObject = cCmdParams[0];
				
				Print("::: [AdminMod_Class] ::: objectHealth(): cData = " + cData + ", strObject = " + strObject + ", cCmdParams.Count() = " + cCmdParams.Count());
				
				if (cCmdParams.Count() == 2)
				{
					heal = cCmdParams[1].ToFloat();
				}
				else
				{
					healing = false;
				}
				if (heal >= 0 && healing)
				{
					if ( strObject.ToInt() >= 0 && strObject.ToInt() <= (m_NearestObjectsList.Count())) //object by number in array
					{
						object = m_NearestObjectsList.Get(strObject.ToInt());
						if (object)
						{
							object.SetHealth(heal);
							adm_msg = "Object: " + object.ToString();
							adm_msg1 = "Object health: " + object.GetHealth();
						}
						else
						{
							adm_msg = "Object not found: " + strObject;
						}
					}
					else //object by name
					{
						for ( int i = 0; i < m_NearestObjectsList.Count(); i++ )
						{
							if (m_NearestObjectsList.Get(i).ToString() == strObject)
							{
								object = m_NearestObjectsList.Get(i);
								if (object)
								{
									object.SetHealth(heal);
									adm_msg = "Object: " + object.ToString();
									adm_msg1 = "Object health: " + object.GetHealth();
									break;
								}
							}
						}
						if (!adm_msg)
						{
						adm_msg = "Object not found: " + strObject;
						}
					}
				}
				else
				{
					adm_msg = "Parameter error!";
				}
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Objects array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void objectGravity(string cData)
	{
		
	}
	
	//Cars on map
	static void GetAllHathchbacksOnMap()
	{
		at_Send_Chat_Message(AdminPlayer, "Please wait while server calculating.", 1);
		m_HatchbacksList = new array<Object>; //All hatchbacks on map
		m_HatchbacksList = GetAllObjectsOnMap("OffroadHatchback");
		string adm_msg = "Hatchbacks count: " + m_HatchbacksList.Count();
		Print("::: [AdminMod_Class] ::: GetAllHathchbacksOnMap() ::: " + adm_msg);
		at_Send_Chat_Message(AdminPlayer, adm_msg, 1);
	}

	static void listHathchbacks(string cData)
	{
		int i_msgDelay = msgDelay;
		Object object = NULL;
		string adm_msg, adm_msg1, adm_msg2, Msg1, Msg2, Msg3 = "";
		
		if (m_HatchbacksList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains(" "))
			{
				if ( cData.ToInt() >= 0 && cData.ToInt() <= m_HatchbacksList.Count()) //object by number in array
				{
					object = m_HatchbacksList.Get(cData.ToInt());
					if (object)
					{
						adm_msg   = "Class :" + object.GetType();
						adm_msg1  = "Object:" + object.ToString();
						adm_msg2  = "Position: " + VectorToVectorString(object.GetPosition());
					}
					else
					{
						adm_msg = "Hatchback disappeared!";
					}
				}
				else
				{
					adm_msg = "Parameter error!";
					adm_msg1 = "Hatchbacks count: " + m_HatchbacksList.Count().ToString();
				}
			}
			else //all Hatchbacks
			{
				for ( int i = 0; i < m_HatchbacksList.Count(); i++ )
				{
					adm_msg = "Hatchbacks count: " + m_HatchbacksList.Count().ToString();
					object = m_HatchbacksList.Get(i);
					if (object)
					{
						Msg1 = "Class :" + i + ": " + object.GetType();
						Msg2 = "Object:" + i + ": " + object.ToString();
						Msg3 = "Position: " + i + ": " + VectorToVectorString(object.GetPosition());
					}
					else
					{
						Msg1 = "Hatchback:" + i + ": disappeared!";
					}
					if (Msg1) AT_Send_Delayed_Message(AdminPlayer, Msg1, ((i_msgDelay * i) + i + 0.5), 1);
					if (Msg2) AT_Send_Delayed_Message(AdminPlayer, Msg2, ((i_msgDelay * i) + i + 0.7), 1);
					if (Msg3) AT_Send_Delayed_Message(AdminPlayer, Msg3, ((i_msgDelay * i) + i + 0.9), 1);
					i_msgDelay = i_msgDelay++; //i_msgDelay = i_msgDelay++;
				}
			}
		}
		else
		{
			adm_msg = "Hatchbacks array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg2)
		{
			Msgparam = new Param1<string>( adm_msg2 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
								
	static void GetAllSedansOnMap()
	{
		at_Send_Chat_Message(AdminPlayer, "Please wait while server calculating.", 1);
		m_SedansList = new array<Object>; //All sedans on map
		m_SedansList = GetAllObjectsOnMap("CivilianSedan");
		string adm_msg = "Sedans count: " + m_SedansList.Count();
		Print("::: [AdminMod_Class] ::: GetAllSedansOnMap() ::: " + adm_msg);
		at_Send_Chat_Message(AdminPlayer, adm_msg, 1);
	}

	static void listSedans(string cData)
	{
		int i_msgDelay = msgDelay;
		Object object = NULL;
		string adm_msg, adm_msg1, adm_msg2, Msg1, Msg2, Msg3 = "";
		
		if (m_SedansList.Count() > 0)
		{
			if ( cData.Length() > 0 && !cData.Contains(" "))
			{
				if ( cData.ToInt() >= 0 && cData.ToInt() <= m_SedansList.Count()) //object by number in array
				{
					object = m_SedansList.Get(cData.ToInt());
					if (object)
					{
						adm_msg   = "Class :" + object.GetType();
						adm_msg1  = "Object:" + object.ToString();
						adm_msg2  = "Position: " + VectorToVectorString(object.GetPosition());
					}
					else
					{
						adm_msg = "Sedan disappeared!";
					}
				}
				else
				{
					adm_msg = "Parameter error!";
					adm_msg1 = "Sedans count: " + m_SedansList.Count().ToString();
				}
			}
			else //all Hatchbacks
			{
				for ( int i = 0; i < m_SedansList.Count(); i++ )
				{
					adm_msg = "Sedans count: " + m_SedansList.Count().ToString();
					object = m_SedansList.Get(i);
					if (object)
					{
						Msg1 = "Class :" + i + ": " + object.GetType();
						Msg2 = "Object:" + i + ": " + object.ToString();
						Msg3 = "Position: " + i + ": " + VectorToVectorString(object.GetPosition());
					}
					else
					{
						Msg1 = "Sedan:" + i + ": disappeared";
					}
					if (Msg1) AT_Send_Delayed_Message(AdminPlayer, Msg1, ((i_msgDelay * i) + i + 0.5), 1);
					if (Msg2) AT_Send_Delayed_Message(AdminPlayer, Msg2, ((i_msgDelay * i) + i + 0.7), 1);
					if (Msg3) AT_Send_Delayed_Message(AdminPlayer, Msg3, ((i_msgDelay * i) + i + 0.9), 1);
					i_msgDelay = i_msgDelay++; //i_msgDelay = i_msgDelay++;
				}
			}
		}
		else
		{
			adm_msg = "Sedans array empty.";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg2)
		{
			Msgparam = new Param1<string>( adm_msg2 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	//Cars on map
	//Objects
	
	//Objects on map
	static array<Object> GetAllObjectsOnMap(string className)
	{
		vector mapcenter = "6250 0 9000";
		mapcenter[1] = GetGame().SurfaceY( mapcenter[0], mapcenter[2] );
		int radius = 16000;
		array<Object> foundObjects = new array<Object>;
		array<Object> objects = new array<Object>;
		array<CargoBase> proxy_cargos = new array<CargoBase>;
		GetGame().GetObjectsAtPosition(mapcenter, radius, objects, proxy_cargos);
		for ( int i = 0; i < objects.Count(); i++ )
		{
			if ( objects[i].GetType() == className )
			{
				if (objects[i]) foundObjects.Insert(objects[i]);
			}
		}
		return foundObjects;
	}
	//Objects on map
	
	//Spawned objects
	static void spawnedObjectDelete(Object object)
	{
		string adm_msg, adm_msg1 = "";
		if (object)
		{
			adm_msg = "Object: " + object.ToString();
			GetGame().ObjectDelete(object);
			adm_msg1 = "Object must be deleted!";
		}
		else
		{
			adm_msg = "Object not found."; 
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}	

	static void spawnedObjectSetPosition(Object object, string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (object)
		{
			array<string> cCmdParams = new array<string>;
			vector pos;
			bool positioning = true;
			cData.Split(" ",cCmdParams);
			if (cCmdParams.Count() == 0)
			{
				pos = AdminPlayer.GetPosition();
				pos[0] = pos[0] + 1;
				pos[2] = pos[2] + 1;
			}
			else if (cCmdParams.Count() == 1)
			{
				pos = object.GetPosition();
				pos[1] = cCmdParams.Get(0).ToFloat();
				pos = SnapToGround(pos);
			}
			else if (cCmdParams.Count() == 3)
			{
				pos = (cCmdParams.Get(0) + " " + cCmdParams.Get(1) + " " + cCmdParams.Get(2)).ToVector();
				//if (pos[1] == 0) pos = SnapToGround(pos);
				pos = SnapToGround(pos);
			}
			else
			{
				positioning = false;
			}
			if (pos[0] > 0 && pos[1] > 0 && pos[2] > 0 && positioning)
			{
				object.SetPosition(pos);
				object.SetOrientation(object.GetOrientation());
				ResetCollision(object);
				adm_msg = "Object: " + object.ToString();
				adm_msg1 = "Object new pos: " + VectorToVectorString(object.GetPosition());
				AdminPlayer.SetSynchDirty();
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Object not found";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void spawnedObjectSetOrientation(Object object, string cData)
	{
		string adm_msg, adm_msg1 = "";
		array<string> cCmdParams = new array<string>;
		vector orient;
		bool positioning = true;
		cData.Split(" ",cCmdParams);
		if (cCmdParams.Count() == 0)
		{
			orient = AdminPlayer.GetOrientation();
		}
		else if (cCmdParams.Count() == 3)
		{
			orient = (cCmdParams.Get(0) + " " + cCmdParams.Get(1) + " " + cCmdParams.Get(2)).ToVector();
		}
		else
		{
			positioning = false;
		}
		
		if (positioning)
		{
			if (object)
			{
				object.SetOrientation(orient);
				ResetCollision(object);
				adm_msg = "Object: " + object.ToString();
				adm_msg1 = "Object new orient: " + VectorToVectorString(object.GetOrientation());
				AdminPlayer.SetSynchDirty();
			}
			else
			{
				adm_msg = "Object not found."; 
			}
		}
		else
		{
			adm_msg = "Parameter error!";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	
	static void spawnedObjectSetDirection(Object object, string cData)
	{
		string adm_msg, adm_msg1 = "";
		array<string> cCmdParams = new array<string>;
		vector direct;
		bool positioning = true;
		cData.Split(" ",cCmdParams);
		if (cCmdParams.Count() == 0)
		{
			direct = AdminPlayer.GetDirection();
		}
		else if (cCmdParams.Count() == 3)
		{
			direct = (cCmdParams.Get(0) + " " + cCmdParams.Get(1) + " " + cCmdParams.Get(2)).ToVector();
		}
		else
		{
			positioning = false;
		}
		
		if (positioning)
		{
			if (object)
			{
				object.SetDirection(direct);
				adm_msg = "Object: " + object.ToString();
				adm_msg1 = "Object new direct: " + VectorToVectorString(object.GetDirection());
				AdminPlayer.SetSynchDirty();
			}
			else
			{
				adm_msg = "Object not found."; 
			}
		}
		else
		{
			adm_msg = "Parameter error!";
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}

	static void spawnedObjectSetHealth(Object object, string cData)
	{
		string adm_msg, adm_msg1 = "";
		if (object)
		{
			float heal = cData.ToFloat();
			if ( heal >= 0 )
			{
				
				object.SetHealth(heal);
				adm_msg = "Object: " + object.ToString();
				adm_msg1 = "Object health: " + object.GetHealth();
			}
			else
			{
				adm_msg = "Parameter error!";
			}
		}
		else
		{
			adm_msg = "Object not found."; 
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	
	static void spawnedObjectGetInfo(Object object)
	{
		string adm_msg, adm_msg0, adm_msg1, adm_msg2, adm_msg3, adm_msg4 = "";
		int netidlow, netidhigh;
		if (object)
		{
			adm_msg  = "Object: " + object.ToString();
			adm_msg0 = "Object posit: " + VectorToVectorString(object.GetPosition());
			adm_msg1 = "Object orien: " + VectorToVectorString(object.GetOrientation());
			adm_msg2 = "Object direc: " + VectorToVectorString(object.GetDirection());
			adm_msg3 = "Object healh: " + object.GetHealth().ToString();
			object.GetNetworkID(netidlow,netidhigh);
			adm_msg4 = "Object NetId: [" + netidlow.ToString() + ":" + netidhigh.ToString() + "]";
		}
		else
		{
			adm_msg = "Object not found."; 
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg0)
		{
			Msgparam = new Param1<string>( adm_msg0 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg2)
		{
			Msgparam = new Param1<string>( adm_msg2 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg3)
		{
			Msgparam = new Param1<string>( adm_msg3 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
		if (adm_msg4)
		{
			Msgparam = new Param1<string>( adm_msg4 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	
	static void spawnedObjectGravity(Object object, string cData) // optimized ?
	{
		string adm_msg, adm_msg1 = "";
		bool gravity = true;
		if (cData == "off" || cData == "disable" || cData == "false")
		{
			gravity = false;
		}
		if (object)
		{
			dBodyEnableGravity(EntityAI.Cast(object), gravity);
			adm_msg = "Object: " + object.ToString();
			adm_msg1 = "Object gravity: " + gravity.ToString();
		}
		else
		{
			adm_msg = "Object not found."; 
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		if (adm_msg1)
		{
			Msgparam = new Param1<string>( adm_msg1 );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	
	}

	static void spawnedObjectSetAllowDamage(Object object, string cData) //used also in objectSetAllowDamage
	{
		string adm_msg = "";
		if (cData == "") cData = "true"; //default
		if (object)
		{
			if ( cData == "false" || cData == "off")
			{
				object.SetAllowDamage(false);
				adm_msg = "Object: " + object.ToString() + " disable damaging.";				
			}
			else if ( cData == "true" || cData == "on")
			{
				object.SetAllowDamage(true);
				adm_msg = "Object: " + object.ToString() + " enable damaging.";
			}
			else
			{
				adm_msg = "Parameter error!"; 
			}
		}
		else
		{
			adm_msg = "Object not found."; 
		}
		Param1<string> Msgparam = new Param1<string>( adm_msg );
		GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
	}

	//Object teleports
	static void spawnedObjectTPTO(Object object, string cData)
	{
		
	}

	static void spawnedObjectTPP(Object object, string cData)
	{
		
	}
	//Spawned objects
	
	//Debug
	static void AdminFunctionsDebug(string debugFunc, string debugText)
	{
		if (debugText && admFuncDebug)
		{
			Print("::: [AdminMod_Class] ::: Debug ::: " + debugFunc + ": " + debugText);
			Param1<string> Msgparam = new Param1<string>( debugText );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	//Debug
	
	//Calls
	static void at_CallQueueClear(bool clmsg)
	{
		GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(at_Send_Chat_Message);
		GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(PlayerMover);
		if (clmsg)
		{
			Param1<string> Msgparam = new Param1<string>( "AdminTool: Clear Background Scripts." );
			GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
		}
	}
	//Calls
	
	//Find player
	static PlayerBase GetTargetPlayer(string cData)
	{
		if (cData.Length() > 0)
		{
			array<Man> players = new array<Man>;
			GetGame().GetPlayers( players );
			for ( int i = 0; i < players.Count(); ++i )
			{
				PlayerIdentity selectedIdentity = PlayerBase.Cast(players.Get(i)).GetIdentity();
				if ( selectedIdentity.GetName() == cData || selectedIdentity.GetPlainId() == cData || selectedIdentity.GetPlayerId() == cData.ToInt() )
				{
					return PlayerBase.Cast(players.Get(i));
				}
			}
		}
		return NULL;
	}
	//Find player
	
	//Set Players Synchronization
	static void SetSynchDirtyAllPlayers(vector center, float radius)
	{
		array<Man> players = new array<Man>;
		GetGame().GetPlayers( players );
		for ( int i = 0; i < players.Count(); ++i )
		{
			PlayerBase selectedPlayer = PlayerBase.Cast(players.Get(i));
			if (selectedPlayer && selectedPlayer.GetIdentity() && selectedPlayer.IsAlive())
			{
				if ( (vector.Distance(selectedPlayer.GetPosition(), center)) <= radius ) selectedPlayer.SetSynchDirty();
			}
		}
	}
	//Set Players Synchronization

	//Class functions end
	//============================================================================================================================================

	//============================================================================================================================================
	//Admin chat processing begin

	//Call from server mission OnEvent
	static void OnAdminChatRequest(Param request_params)
	{
		ChatMessageEventParams chat_params = ChatMessageEventParams.Cast( request_params );
		switch(chat_params.param1)
		{
			case 0:
			{
				if ( chat_params.param2 == "Server" || chat_params.param2 == "System" )
				{
					break;
				}
				
				array<Man> players = new array<Man>; //Players array
				int a, b, c, d, e, f, g, h, i, j, k;
				Param1<string> Msgparam;
				Param1<string> Msgparam1;
				Weather weather = GetGame().GetWeather();
				
				//DEBUG CHAT INPUT START
				Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: chat_params.param1: " + chat_params.param1.ToString());
				if (chat_params.param2)
				{
					Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: chat_params.param2: " + chat_params.param2);
				}
				if (chat_params.param3)
				{
					Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: chat_params.param3: " + chat_params.param3);
				}
				if (chat_params.param4)
				{
					Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: chat_params.param4: " + chat_params.param4);
				}
				//DEBUG CHAT INPUT END
				if (chat_params.param1 == 0 && chat_params.param2 != "" && chat_params.param3 != "") //trigger only when channel is Global == 0,  Player Name does not equal to null and command 
				{ 
					bool AdminConnected = false;
					if (AdminPlayer && AdminPlayer.IsAlive() && AdminIdentity && AdminEntity)
					{
						if (AdminIdentity.GetName() == chat_params.param2 && AdminIdentity.GetName() == AdminNAME && m_AdminsList.Contains(AdminIdentity.GetPlainId()) && AdminIdentity.GetPlainId() == AdminUID)
						{
							AdminConnected = true;
						}
					}
					
					if (!AdminConnected)
					{
						GetGame().GetPlayers( players );
						for ( i = 0; i < players.Count(); ++i )
						{
							if (players.Get(i).GetIdentity().GetName() == chat_params.param2 && m_AdminsList.Contains(players.Get(i).GetIdentity().GetPlainId()))
							{
								at_CallQueueClear(false); //new
								AdminPlayer = PlayerBase.Cast(players.Get(i));
								AdminObject = Object.Cast(AdminPlayer);
								AdminIdentity = AdminPlayer.GetIdentity();
								AdminEntity = EntityAI.Cast(AdminPlayer);
								AdminMan = Man.Cast(AdminPlayer);
								AdminUID = AdminIdentity.GetPlainId();
								AdminNAME = AdminIdentity.GetName();
								Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: AdminPlayer new connection to admintool, Name: " + AdminNAME + ", UID: " + AdminUID);
								i = players.Count();
							break;
							}
						}
					}
					else if (AdminConnected)
					{
						Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: AdminPlayer already connected to admintool, Name: " + AdminNAME + ", UID: " + AdminUID);
					}
					//--//
						if (AdminPlayer && AdminIdentity && AdminUID != "")
						{
							Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: Admin Request from player " + AdminNAME + " in m_AdminsList, UID: " + AdminUID);
							if (chat_params.param3.Length() > 2 && chat_params.param3.Contains("/") && chat_params.param3.IndexOfFrom(0,"/") == 0 && !chat_params.param3.Contains("  "))
							{
								Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: sended command: " + chat_params.param3);
							}
							else
							{
								break;
							}
							
							if (adm_ChatRequestExec)
							{
								Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: admin command is already processing! adm_ChatRequestExec = " + adm_ChatRequestExec.ToString());
								break;
							}
							adm_ChatRequestExec = true; // proceed!
							
							if (m_AdminBodyMass == 1.1 || AdminUID != NewAdminUID)
							{
								m_AdminBodyMass = dBodyGetMass(AdminEntity);
								Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: Store new Admin m_AdminBodyMass = " + m_AdminBodyMass);
								NewAdminUID = AdminUID;
							}
							
							ref array<string> chatCommand = ParseCommand(chat_params.param3);

							//VARS
							string cCommand, cData, cData2, tpcOldPos;
							array<string> s_Date, s_Time, cCmdParams;
							float w_Param1, w_Param2, w_Param3, m_Rain, m_Fog, m_Overcast, m_Wind, m_WindSpeed, m_WindVector, m_Storm, m_Clouds;
							int m_Year, m_Month, m_Day, m_Hour, m_Minute;
							string s_DateTime;
							string adm_msg, adm_msg0, adm_msg1, adm_msg2, adm_msg3, Msg, Msg0, Msg1, Msg2, Msg3, Msg4;
							string player_msg, player_msg0, player_msg1;

							EntityAI itemEnt = NULL;
							Object object = NULL;
							array<CargoBase> proxy_cargos = new array<CargoBase>;
							
							int i_msgDelay = msgDelay;
							int radius;
							
							vector position, tpPlayerPos, tpPlayerBackPos, camPosition;
							vector AdminPosition = AdminPlayer.GetPosition();
							PlayerBase player, selectedPlayer, Target;
							PlayerIdentity selectedIdentity, TargetIdentity;
							//VARS

							cCommand = chatCommand.Get(0);
							cCommand.ToLower();
							string cFullCommand = cCommand;
							if (chatCommand.Count() > 1)
							{
								cData = chatCommand.Get(1);
								cFullCommand = cCommand + " " + cData;
							} else {
									cData = "";
							}
							Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: processing command: " + cFullCommand + " ::: adm_ChatRequestExec = " + adm_ChatRequestExec.ToString());
							
							//----------------------//ADMIN COMMANDs CODE START --//
							ServerDebugFps(); //debug
							
							switch(cCommand)
							{
								case "/stop":
								{
									at_CallQueueClear(true);
								break;
								}
								case "/help":
								{
									//Send messages with help about admin commands
								break;
								}
								case "/savepoint":
								{
									if (m_FreeCamera || m_Spectator) 
									{
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										break;
									}
									if (cData == "" || !cData.Contains(" ")) //Save point to json // DaOne code
									{
										adm_msg = "Error Adding Point, Please Provide A Name for the Spawn Point.";
									}
									else
									{
										ref map<string, map<string,float>> m_SpawnPoints;
										ref map<string,float> InfoChached;
										JsonFileLoader<ref map<string, map<string,float>>>.JsonLoadFile("$profile:SpawnPoints.json", m_SpawnPoints);
										ref map<string,float> PointsInfo = new map<string,float>;
										vector savePos = AdminPlayer.GetPosition();
										string strsavePos = VectorToVectorString(savePos);
										PointsInfo.Insert(strsavePos,900);
										m_SpawnPoints.Insert(cData,PointsInfo);
										JsonFileLoader<ref map<string, map<string,float>>>.JsonSaveFile("$profile:SpawnPoints.json", m_SpawnPoints);
										adm_msg = "Added Spawn " + cData + " To the Json!, Point will be useable after restart";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/strip":
								{
									if (cData.Length() > 0)
									{
										selectedPlayer = GetTargetPlayer(cData); //NEW VARIANT
										if (selectedPlayer)
										{
												selectedPlayer.RemoveAllItems();
												adm_msg = "Player "+ cData + " Stripped!";
												player_msg = "You are stripped by admin!";
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										adm_msg = "/strip: Parameter error.";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/drop":
								{
									if (cData.Length() > 0)
									{
										selectedPlayer = GetTargetPlayer(cData); //NEW VARIANT
										if (selectedPlayer)
										{
												selectedPlayer.DropAllItems();
												adm_msg = "Player "+ cData + " Stripped!";
												player_msg = "You are stripped by admin!";
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										adm_msg = "/strip: Parameter error.";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}

								//---- TELEPORT ----//
								case "/tpalltome":
								{
									if (m_TpAllToMe)
									{
										int tpCount = TeleportAllPlayersBack();
										m_TpAllToMe = false;
										adm_msg = tpCount.ToString() + "Players teleported back to original positions.";
										player_msg = "All players teleported back to original positions.";
									}
									else
									{
										tpCount = TeleportAllPlayersTo(AdminPlayer);
										m_TpAllToMe = true;
										adm_msg = tpCount.ToString() + " players teleported to me!";
										player_msg = "All players teleported to admin!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/tpap": //teleport admin to player
								{
									if (m_FreeCamera || m_Spectator) 
									{
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										break;
									}
									if (cData.Length() > 0)
									{
										selectedPlayer = GetTargetPlayer(cData); //NEW VARIANT
										if (selectedPlayer)
										{
											SavePosToProfile(VectorToVectorString(AdminPlayer.GetPosition()), AdminUID);
											AdminPlayer.SetPosition(selectedPlayer.GetPosition() - m_tpCorrect);
											AdminPlayer.SetOrientation(selectedPlayer.GetOrientation());
											AdminPlayer.SetDirection(selectedPlayer.GetDirection());
											ResetCollision(Object.Cast(AdminPlayer));
											AdminPlayer.SetSynchDirty();
											adm_msg =  "You were teleported to player " + selectedPlayer.GetIdentity().GetName();
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										adm_msg = "/tpap: Parameter error.";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/tppa": //teleport player to admin
								{
									if (m_FreeCamera || m_Spectator) 
									{
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										break;
									}
									if (cData.Length() > 0)
									{
										selectedPlayer = GetTargetPlayer(cData); //NEW VARIANT
										if (selectedPlayer)
										{
											SavePosToProfile(VectorToVectorString(selectedPlayer.GetPosition()), selectedPlayer.GetIdentity().GetPlainId());
											selectedPlayer.SetPosition(AdminPosition - m_tpCorrect);
											selectedPlayer.SetOrientation(selectedPlayer.GetOrientation());
											selectedPlayer.SetDirection(selectedPlayer.GetDirection());
											ResetCollision(Object.Cast(selectedPlayer));
											AdminPlayer.SetSynchDirty(); selectedPlayer.SetSynchDirty();
											adm_msg = "Player " + selectedPlayer.GetIdentity().GetName() + " was teleported to you!";
											player_msg = "You were teleported to admin!";
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										adm_msg = "/tppa: Parameter error.";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/tpb":
								case "/tpback": //teleport player back to saved pos
								{
									if (cData.Length() > 0)
									{
										selectedPlayer = GetTargetPlayer(cData); //NEW VARIANT
										if (selectedPlayer)
										{
											tpcOldPos = LoadPosFromProfile(selectedPlayer.GetIdentity().GetPlainId(),true);
											if ( tpcOldPos.Length() > 4 )
											{
												selectedPlayer.SetPosition(tpcOldPos.ToVector());
												selectedPlayer.SetOrientation(selectedPlayer.GetOrientation());
												selectedPlayer.SetDirection(selectedPlayer.GetDirection());
												ResetCollision(Object.Cast(selectedPlayer));
												selectedPlayer.SetSynchDirty();
												adm_msg = "Player " + selectedPlayer.GetIdentity().GetName() + " were teleported back!";
												player_msg = "You were teleported back!";
											}
											else
											{
												adm_msg = "Player " + selectedPlayer.GetIdentity().GetName() + " teleport failed!!!";
											}
										}	
										else
										{
												adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										adm_msg = "/tpback: Parameter error.";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break; 
								}
								case "/tpto":
								{
									if (m_FreeCamera || m_Spectator) 
									{
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										break;
									}
									
									position = AdminPosition;
									string tmpTpto = cData;
									tmpTpto.ToLower();
									if (m_TPLocations.Contains(tmpTpto))
									{
										m_TPLocations.Find( tmpTpto, position );
										SavePosToProfile(VectorToVectorString(AdminPosition), AdminUID);
										if (position)
										{
											tpPlayerPos[0] = position[0];
											tpPlayerPos[2] = position[2];
											tpPlayerPos = SnapToGround( tpPlayerPos );
											AdminPlayer.SetPosition(tpPlayerPos);
											AdminPlayer.SetPosition(AdminPlayer.GetPosition());
											AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
											AdminPlayer.SetDirection(AdminPlayer.GetDirection());
											ResetCollision(Object.Cast(AdminPlayer));
											AdminPlayer.SetSynchDirty();
											adm_msg = "Teleported To Location: " + cData;
										}
										else
										{
											adm_msg = "Error: " + position.ToString();
										}
									}
									else
									{
										adm_msg = "Teleport Failed! Location is not on the list!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/listtp":
								{
									listTPLocations();
								}
								case "/tpc":
								{
									if (m_FreeCamera || m_Spectator) 
									{
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										break;
									}
									if ( cData.Length() > 4 && cData.Contains(" ") && !cData.Contains("  "))
									{
										adm_msg = "/tpc: Parameter error!";
										cCmdParams = new array<string>;
										cData.Split(" ", cCmdParams);
										if (cCmdParams.Count() == 3)
										{
											if (cCmdParams.Get(0).ToFloat() > 0 && cCmdParams.Get(1).ToFloat() >= 0 && cCmdParams.Get(2).ToFloat() > 0)
											{
												tpPlayerPos[0] = cCmdParams.Get(0).ToFloat();
												tpPlayerPos[1] = cCmdParams.Get(1).ToFloat(); 
												tpPlayerPos[2] = cCmdParams.Get(2).ToFloat(); 
												tpPlayerPos = SnapToGround( tpPlayerPos );
												string m_tpSurface;
												GetGame().SurfaceGetType(tpPlayerPos[0], tpPlayerPos[2], m_tpSurface);
												Print("::: [AdminMod_Class] ::: /tpc ::: Surface at tp point: " + m_tpSurface);
												SavePosToProfile(VectorToVectorString(AdminPosition), AdminUID);
												AdminPlayer.SetPosition(tpPlayerPos);
												AdminPlayer.SetPosition(AdminPlayer.GetPosition());
												AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
												AdminPlayer.SetDirection(AdminPlayer.GetDirection());
												ResetCollision(Object.Cast(AdminPlayer));
												AdminPlayer.SetSynchDirty();
												Print("::: [AdminMod_Class] ::: /tpc ::: tpPlayerPos = " + tpPlayerPos.ToString());
												adm_msg = "Teleported to: " + VectorToVectorString(tpPlayerPos);
											}
										}
									}
									else if (cData.Length() > 0 && !cData.Contains(" "))
									{
										if (cData.ToFloat())
										{
											tpPlayerPos[0] = AdminPlayer.GetPosition()[0];
											tpPlayerPos[1] = cData.ToFloat(); 
											tpPlayerPos[2] = AdminPlayer.GetPosition()[2];
											tpPlayerPos = SnapToGround( tpPlayerPos );
											AdminPlayer.SetPosition(tpPlayerPos);
											AdminPlayer.SetPosition(AdminPlayer.GetPosition());
											AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
											AdminPlayer.SetDirection(AdminPlayer.GetDirection());
											ResetCollision(Object.Cast(AdminPlayer));
											AdminPlayer.SetSynchDirty();
											adm_msg = "Jumping to: " + VectorToVectorString(tpPlayerPos);
										}
										else
										{
											adm_msg = "Teleport parameter error!";
										}
									}
									else
									{
										tpcOldPos = LoadPosFromProfile(AdminUID,true);
										if ( cData.Length() == 0 && tpcOldPos.Length() > 4 )
										{
											AdminPlayer.SetPosition(tpcOldPos.ToVector());
											AdminPlayer.SetPosition(AdminPlayer.GetPosition());
											AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
											AdminPlayer.SetDirection(AdminPlayer.GetDirection());
											ResetCollision(Object.Cast(AdminPlayer));
											AdminPlayer.SetSynchDirty();
											adm_msg = "Teleported back to: " + VectorToVectorString(AdminPosition);
										}
										else
										{
											adm_msg = "Teleport Failed!";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/tppc":
								{
									if ( cData.Length() >= 0 && !cData.Contains("  "))
									{
										cCmdParams = new array<string>;
										cData.Split(" ", cCmdParams); // First parameters nick, uid oe id. Last 3 params = position = vector data
										if (cCmdParams.Count() >= 4) //If parameters >= 4 (example: nick 3000 0 3000)
										{
											cData2 = "";
											for ( i = 0; i < cCmdParams.Count() - 3; ++i )
											{
												cData2 = cData2 + cCmdParams.Get(i) + " ";
											}
											cData2 = cData2.Trim(); //Remove trailing whitespace
											
											Print("::: [AdminMod_Class] ::: /tppc ::: cData2 = " + cData2);
											Print("::: [AdminMod_Class] ::: /tppc ::: cCmdParams.Get(cCmdParams.Count() - 3) = " + cCmdParams.Get(cCmdParams.Count() - 3));
											Print("::: [AdminMod_Class] ::: /tppc ::: cCmdParams.Get(cCmdParams.Count() - 2) = " + cCmdParams.Get(cCmdParams.Count() - 2));
											Print("::: [AdminMod_Class] ::: /tppc ::: cCmdParams.Get(cCmdParams.Count() - 1) = " + cCmdParams.Get(cCmdParams.Count() - 1));
											
											if (cData2.Length() >= 1)
											{
												if ( cCmdParams.Get(cCmdParams.Count() - 3).ToFloat() > 0 && cCmdParams.Get(cCmdParams.Count() - 2).ToFloat() >= 0 && cCmdParams.Get(cCmdParams.Count() - 1).ToFloat() > 0)
												{
													selectedPlayer = GetTargetPlayer(cData2); //NEW VARIANT
													if (selectedPlayer)
													{
														tpPlayerPos[0]	= cCmdParams.Get(cCmdParams.Count() - 3).ToFloat();
														tpPlayerPos[1]	= cCmdParams.Get(cCmdParams.Count() - 2).ToFloat();
														tpPlayerPos[2]	= cCmdParams.Get(cCmdParams.Count() - 1).ToFloat();
														//if (tpPlayerPos[1] == 0)
														//{
															tpPlayerPos = SnapToGround( tpPlayerPos );
														//}
														SavePosToProfile(VectorToVectorString(selectedPlayer.GetPosition()), selectedPlayer.GetIdentity().GetPlainId());
														selectedPlayer.SetPosition(tpPlayerPos);
														//selectedPlayer.PlaceOnSurface();
														selectedPlayer.SetOrientation(selectedPlayer.GetOrientation());
														selectedPlayer.SetDirection(selectedPlayer.GetDirection());
														ResetCollision(Object.Cast(selectedPlayer));
														selectedPlayer.SetSynchDirty();
														Print("::: [AdminMod_Class] ::: /tppc ::: Tp player: " + cData2 + " to pos: " + tpPlayerPos);
														adm_msg = cData2 + " Tp to: " + VectorToVectorString(tpPlayerPos);
														player_msg = "You were teleported by admin";
													}
													else
													{
														adm_msg = "Player not found: " + cData2;
													}
												}
												else
												{
													adm_msg = "/tppc: Icorrect pos: " + cCmdParams.Get(cCmdParams.Count() - 3) + " " + cCmdParams.Get(cCmdParams.Count() - 2) + " " + cCmdParams.Get(cCmdParams.Count() - 1);
												}
											}
											else
											{
												adm_msg = "/tppc: Specify player!";
											}
										}
										else
										{
											adm_msg = "/tppc: Parameters error!";
										}
									}
									else
									{
										adm_msg = "/tppc: Specify correct player and pos!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/tppto":
								{
									if ( cData.Length() >= 3 && !cData.Contains("  "))
									{
										adm_msg = "/tppto: Parameter error!";										
										cCmdParams = new array<string>;
										cData.Split(" ", cCmdParams); // 1st parameter name, 2nd city
										
										if (cCmdParams.Count() == 2)
										{
											tmpTpto = cCmdParams.Get(1);
											tmpTpto.ToLower();

											Print("::: [AdminMod_Class] ::: /tppto ::: Player: cCmdParams.Get(0) = " + cCmdParams.Get(0));
											Print("::: [AdminMod_Class] ::: /tppto ::: Location: tmpTpto.ToLower() = cCmdParams.Get(1) = " + tmpTpto);
											
											if (cCmdParams.Get(0).Length() > 0 && m_TPLocations.Contains(tmpTpto))
											{
												selectedPlayer = GetTargetPlayer(cCmdParams.Get(0)); //NEW VARIANT
												if (selectedPlayer)
												{
													position = selectedPlayer.GetPosition();
													m_TPLocations.Find( tmpTpto, position );
													tpPlayerPos[0] = position[0];
													tpPlayerPos[2] = position[2];
													tpPlayerPos = SnapToGround( tpPlayerPos );
													SavePosToProfile(VectorToVectorString(selectedPlayer.GetPosition()), selectedPlayer.GetIdentity().GetPlainId());
													selectedPlayer.SetPosition(tpPlayerPos);
													//selectedPlayer.PlaceOnSurface();
													selectedPlayer.SetOrientation(selectedPlayer.GetOrientation());
													selectedPlayer.SetDirection(selectedPlayer.GetDirection());
													ResetCollision(Object.Cast(selectedPlayer));
													selectedPlayer.SetSynchDirty();
													Print("::: [AdminMod_Class] ::: /tppto ::: Tp player: " + cCmdParams.Get(0) + " to location: " + tmpTpto + ", pos: "+ tpPlayerPos);
													adm_msg = cCmdParams.Get(0) + " Tp to: " + cCmdParams.Get(1);
													player_msg = "You were teleported by admin";
												}
												else
												{
													adm_msg = "Player not found: " + cCmdParams.Get(0);
												}
											}
										}
									}
									else
									{
										adm_msg = "Specify correct player and location!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- TELEPORT ----//
								
								//---- JUMP:MOVES ----//
								case "/jump":
								{
									if ( cData == "stop" )
									{
										m_MovePlayer = false;
										//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(PlayerMover);
										adm_msg = "Jump stop!";
									}
									else if (m_MovePlayer) 
									{
										adm_msg = "Already jumped.";
										break;
									}
									else if ( cData.Length() > 4 && cData.IndexOfFrom(1," ") >= 1 && cData.IndexOfFrom(3," ") >=3 && cData.IndexOfFrom(1," ") < cData.IndexOfFrom(cData.IndexOfFrom(1," ") + 2," ") && !cData.Contains("  "))
									{
										vector targetPos = cData.ToVector();
										MoveTo(AdminPlayer, targetPos);
										adm_msg = "Jumped to: " + targetPos.ToString();
									}
									else
									{
										adm_msg = "Parameter error!" + targetPos.ToString();
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- JUMP:MOVES ----//

								//---- PHYSICS:GRAVITY ----//
								case "/gravity":
								{
									if (!m_Gravity || cData == "on")
									{
										if (AdminPlayer && AdminEntity)
										{
											dBodySetMass(AdminEntity, m_AdminBodyMass);
											dBodyEnableGravity(AdminEntity,true);
											AdminPlayer.SetPosition(AdminPlayer.GetPosition());
											AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
											AdminPlayer.SetDirection(AdminPlayer.GetDirection());
											AdminPlayer.SetSynchDirty();
										}
										m_Gravity = true;
										adm_msg = "Gravity enabled";
									}
									else if (m_Gravity || cData == "off")
									{
										if (AdminPlayer && AdminEntity)
										{
											dBodySetMass(AdminEntity, 0.1);
											dBodyEnableGravity(AdminEntity,false);
											AdminPlayer.SetPosition(AdminPlayer.GetPosition());
											AdminPlayer.SetOrientation(AdminPlayer.GetOrientation());
											AdminPlayer.SetDirection(AdminPlayer.GetDirection());
											AdminPlayer.SetSynchDirty();
										}
										m_Gravity = false;
										adm_msg = "Gravity disabled";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- PHYSICS:GRAVITY ----//

								//---- WEATHER ----//
								case "/rain":
								{
									if ( cData.Length() > 0)
									{
										if ( cData == "?")
										{
											m_Rain = weather.GetRain().GetActual();
											adm_msg = "Rain current: " + m_Rain.ToString();
											Print("::: [AdminMod_Class] ::: /rain ? ::: GetRain().GetActual() : " + m_Rain.ToString());
										}
										else
										{
											w_Param1 = cData.ToFloat() / 100;
											m_Rain = weather.GetRain().GetActual();
											Print("::: [AdminMod_Class] ::: /rain ::: Current: " + m_Rain.ToString() + ", called change: " + w_Param1.ToString());
											weather.GetRain().Set(w_Param1, 2, 600); //Change
											m_Rain = weather.GetRain().GetActual();
											Print("::: [AdminMod_Class] ::: /rain ::: Changed : " + m_Rain.ToString());
											adm_msg = "Rain: " + m_Rain.ToString();
										}
									}
									else
									{
										weather.GetRain().Set(0, 2, 600);
										m_Rain = weather.GetRain().GetActual();
										adm_msg = "Rain: " + m_Rain.ToString();
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/fog":
								{
									if ( cData.Length() > 0)
									{
										if ( cData == "?")
										{
											m_Fog = weather.GetFog().GetActual();
											adm_msg = "Fog current: " + m_Fog.ToString();
											Print("::: [AdminMod_Class] ::: /fog ? ::: GetFog().GetActual() : " + m_Fog.ToString());
										}
										else
										{
											w_Param1 = cData.ToFloat() / 100;
											m_Fog = weather.GetFog().GetActual();
											Print("::: [AdminMod_Class] ::: /fog ::: Current: " + m_Fog.ToString() + ", called change: " + w_Param1.ToString());
											weather.GetFog().Set(w_Param1, 2, 1800); //Change
											m_Fog = weather.GetFog().GetActual();
											Print("::: [AdminMod_Class] ::: /Fog ::: Changed : " + m_Fog.ToString());
											adm_msg = "Fog: " + m_Fog.ToString();
										}
									}
									else
									{
										weather.GetFog().Set(0, 2, 1800);
										m_Fog = weather.GetFog().GetActual();
										adm_msg = "Fog: " + m_Fog.ToString();
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/overcast":
								{
									//default parameters
									w_Param1 = 0; //default
									w_Param2 = 2; //default
									w_Param3 = 1800; //default
									if ( cData.Length() > 0)
									{
										if ( cData == "?")
										{
											m_Overcast = weather.GetOvercast().GetActual();
											adm_msg = "Overcast current: " + m_Overcast.ToString();
											Print("::: [AdminMod_Class] ::: /overcast ? ::: GetOvercast().GetActual() : " + m_Overcast.ToString());
										}
										else
										{
										
											w_Param1 = cData.ToFloat() / 100;
											m_Overcast = weather.GetOvercast().GetActual();
											Print("::: [AdminMod_Class] ::: /Overcast ::: Current: " + m_Overcast.ToString() + ", called change: " + w_Param1.ToString());
											weather.GetOvercast().Set(w_Param1, w_Param2, w_Param3); //Change
											m_Overcast = weather.GetOvercast().GetActual();
											Print("::: [AdminMod_Class] ::: /Overcast ::: Changed : " + m_Overcast.ToString());
											adm_msg = "Overcast: " + m_Overcast.ToString();
										}
									}
									else
									{
										weather.GetOvercast().Set(w_Param1, w_Param2, w_Param3);
										m_Overcast = weather.GetOvercast().GetActual();
										adm_msg = "Overcast: " + m_Overcast.ToString();
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/windspeed":
								{
									if ( cData.Length() > 0)
									{
										if ( cData == "?")
										{
											m_WindSpeed = weather.GetWindSpeed();
											adm_msg = "Windspeed current: " + m_WindSpeed.ToString();
											Print("::: [AdminMod_Class] ::: /windspeed ? ::: GetWindSpeed() : " + m_WindSpeed.ToString());
										}
										else
										{
											w_Param1 = cData.ToFloat();
											m_WindSpeed = weather.GetWindSpeed();
											Print("::: [AdminMod_Class] ::: /windspeed ::: Current: " + m_WindSpeed.ToString() + ", called change: " + w_Param1.ToString());
											weather.SetWindSpeed(m_WindSpeed); //Change
											m_WindSpeed = weather.GetWindSpeed();
											Print("::: [AdminMod_Class] ::: /windspeed ::: Changed : " + m_WindSpeed.ToString());
											adm_msg = "Windspeed: " + m_WindSpeed.ToString();
										}
									}
									else
									{
										weather.SetWindSpeed(0.1);
										m_WindSpeed = weather.GetWindSpeed();
										adm_msg = "Windspeed: " + m_WindSpeed.ToString();
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/storm":
								{
									if ( cData.Length() > 0)
									{
										w_Param1 = cData.ToFloat() / 100;
										Print("::: [AdminMod_Class] ::: /Storm ::: Current: " + m_Storm.ToString() + ", called change: " + w_Param1.ToString());
										m_Storm = weather.GetOvercast().GetActual();
										weather.SetStorm(w_Param1, 0.5, 120); //Change 
										weather.GetOvercast().Set(w_Param1, 2, 1800); //Change 
										m_Storm = weather.GetOvercast().GetActual();
										Print("::: [AdminMod_Class] ::: /Storm ::: Changed : " + m_Storm.ToString());
										adm_msg = "Storm: " + m_Storm.ToString();
									}
									else
									{
										weather.SetStorm(0, 0.5, 120);
										adm_msg = "Storm: 0";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/wreset": //Reset weather!
								{
									weather.GetOvercast().Set(0, 2, 1800);
									weather.GetOvercast().Set(0, 2, 1800);
									weather.GetRain().Set( 0, 2, 600);
									weather.GetFog().Set(0, 2, 1800);
									weather.SetWindSpeed(0.1);
									weather.SetStorm(0, 0.5, 1600); //Change 
									adm_msg = "Weather reset!";
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/daytemp": //Get day temperature!
								{
									adm_msg = "Day temp: " + g_Game.GetMission().GetWorldData().GetDayTemperature();
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/nighttemp": //Get night temperature!
								{
									adm_msg = "Night temp: " + g_Game.GetMission().GetWorldData().GetNightTemperature();
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- WEATHER ----//
								
								//---- DATE:TIME ----//
								case "/date":
								{
									if (cData.Length() >=8 && cData.Length() <= 10 && !cData.Contains(" "))
									{
										s_Date = new array<string>;
										cData.Split(".",s_Date);
										GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);
										if (s_Date.Count() == 3)
										{
											//SET DATE VARS
											if (s_Date.Get(0).ToInt() > 0 && s_Date.Get(0).ToInt() <= 31)
											{
												m_Day = s_Date.Get(0).ToInt();
											}
											if (s_Date.Get(1).ToInt() > 0 && s_Date.Get(1).ToInt() <= 12)
											{
												m_Month = s_Date.Get(1).ToInt();
											}
											if (s_Date.Get(2).ToInt() > 0)
											{
												m_Year = s_Date.Get(2).ToInt();
											}
											s_DateTime = AjustDateTime(m_Year, m_Month, m_Day, m_Hour, m_Minute, "ALL");
											adm_msg = "CURRENT NEW: " + s_DateTime;
										}
										else
										{
											adm_msg = "Paremeter error!";
										}
									}
									else
									{
										s_DateTime = AjustDateTime(m_Year, m_Month, m_Day, m_Hour, m_Minute, "READ");
										adm_msg = "CURRENT: " + s_DateTime;
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/time":
								{
									if (cData.Length() >= 3 && cData.Length() <= 5 && !cData.Contains(" "))
									{
										GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);
										s_Time = new array<string>;
										cData.Split(":",s_Time);
										if (s_Time.Count() == 2)
										{
											//SET TIME VARS
											if (s_Time.Get(0).ToInt() >= 0 && s_Time.Get(0).ToInt() <= 24)
											{
												m_Hour = s_Time.Get(0).ToInt();
											}
											if (s_Time.Get(1).ToInt() >= 0 && s_Time.Get(1).ToInt() <= 59)
											{
												m_Minute = s_Time.Get(1).ToInt();
											}
											if (m_Minute >= 60)
											{
												m_Minute = 0;
												m_Hour = m_Hour + 1;
												if (m_Hour > 23)
												{
													m_Hour = m_Hour - 24;
												}
											}
											s_DateTime = AjustDateTime(m_Year, m_Month, m_Day, m_Hour, m_Minute, "ALL");
											adm_msg = "CURRENT NEW: " + s_DateTime;
										}
										else
										{
											adm_msg = "Paremeter error!";
										}
									}
									else
									{
										s_DateTime = AjustDateTime(m_Year, m_Month, m_Day, m_Hour, m_Minute, "READ");
										adm_msg = "CURRENT: " + s_DateTime;
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/night":
								{
									GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);
									GetGame().GetWorld().SetDate( m_Year, m_Month, m_Day, 23, 59 );
									Msgparam = new Param1<string>( "TIME: 23:59" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/everning":
								{
									GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);
									GetGame().GetWorld().SetDate( m_Year, m_Month, m_Day, 20, 00 );
									Msgparam = new Param1<string>( "TIME: 20:00" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/day":
								{
									GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);
									GetGame().GetWorld().SetDate( m_Year, m_Month, m_Day, 13, 00 );
									Msgparam = new Param1<string>( "TIME: 13:00" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/morning":
								{
									GetGame().GetWorld().GetDate(m_Year, m_Month, m_Day, m_Hour, m_Minute);
									GetGame().GetWorld().SetDate( m_Year, m_Month, m_Day, 8, 00 );
									Msgparam = new Param1<string>( "TIME: 07:00" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- DATE:TIME ----//
								
								//---- SERVER:OBJECTS ----//
								case "/check": //Check objects in radius at current position print and save in array
								{
									checkObjects(cData, AdminPosition);
								break;
								}
								case "/list": //List obects in array
								{
									listObjects(cData);
								break;
								}
								case "/del": //Delete object
								{
									deleteObject(cData);
								break;
								}
								case "/oinfo": // Get object information (Position, Orientation, Direction, Health)
								{
									objectInfo(cData);
								break;	
								}
								case "/osp": // Set object position
								{
									objectPosition(cData);
								break;	
								}
								case "/oso": // Set object orientation
								{
									objectOrientation(cData);
								break;	
								}
								case "/osd": // Set object direction
								{
									objectDirection(cData);
								break;	
								}
								case "/odamag": // Set object allow damage
								case "/odamage": // Set object allow damage
								{
									objectSetAllowDamage(cData);
								break;	
								}
								case "/oheal": // Set object health
								case "/ohealth": // Set object health
								{
									objectHealth(cData);
								break;
								}
								case "/ograv": // Set object gravity
								case "/ogravity": // Set object gravity
								{
									objectGravity(cData);
								break;
								}
								
								//----    All cars    ----//
								case "/gethatchbacks":
								{
									GetAllHathchbacksOnMap();
								break;
								}

								case "/listhatchbacks":
								{
									listHathchbacks(cData);
								break;
								}
								
								case "/getsedans":
								{
									GetAllSedansOnMap();
								break;
								}

								case "/listsedans":
								{
									listSedans(cData);
								break;
								}
								//----    All cars    ----//
								//---- SERVER:OBJECTS ----//
								
								//---- SERVER:PLAYERS ----//
								case "/listplayers":
								{
									listPlayers();
								break;
								}
								case "/inventory":
								{
									inventoryCheck(cData);
								break;
								}
								case "/checkitem":
								{
									checkItem(cData);
								break;
								}
								case "/listids":
								{
									listPlayersIDs();
								break;
								}
								case "/idinfo":
								{
									playerInfo(cData);
								break;
								}
								//---- SERVER:PLAYERS ----//

								//---- SPAWN:OBJECTS ----//
								case "/spi":
								{
									itemEnt = SpawnObject(false, AdminPlayer, cData); //false => inventory
									if (itemEnt)
									{
										adm_msg = "Item " + cData + " Added in Inventory!";
										m_SpawnedObject = Object.Cast(itemEnt);
									}
									else
									{
										adm_msg = "Item " + cData + " Failed!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/spg":
								{
									if ( cData.Length() > 1 && !cData.Contains("  "))
									{
										int itemCount = 1;
										cCmdParams = new array<string>;
										cData.Split(" ",cCmdParams);
										cData = cCmdParams[0];
										if ( cCmdParams.Count() > 1 && !cCmdParams[1].Contains("offroad") && !cCmdParams[1].Contains("sedan") && !cCmdParams[1].Contains("v3s") && !cCmdParams[1].Contains("bus") && !cCmdParams[1].Contains("survivor") && !cCmdParams[1].Contains("animal") && !cCmdParams[1].Contains("zmb") && !cCmdParams[1].Contains("land") )
										{
											if (cCmdParams[1].ToInt() > 1 && cCmdParams[1].ToInt() <= m_MaxSpgQty ) itemCount = cCmdParams[1].ToInt();
										}
										for ( i = 0; i < itemCount; ++i )
										{
											itemEnt = SpawnObject(true, AdminPlayer, cData); //true => ground
											if (itemEnt) if (itemEnt.IsBuilding()) BuildingDoors(itemEnt, true, false);

										}
										if (itemEnt)
										{
											m_SpawnedObject = Object.Cast(itemEnt);
											adm_msg  = "Item " + cData + " Spawned around you!";
											adm_msg1 = "Item qty: " + itemCount;
										}
										else
										{
											adm_msg = "Item " + cData + " Failed!";
										}
									}
									else
									{
										adm_msg = "Command error!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									if (adm_msg1)
									{
										Msgparam = new Param1<string>( adm_msg1 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
								break;
								}
								case "/maxspgqty":
								{
									if ( cData.ToInt() > 0 && cData.ToInt() <= 100 )
									{
										m_MaxSpgQty = cData.ToInt();
										adm_msg = "Set Max Spg Qty = " + m_MaxSpgQty;
									}
									else if ( cData.Length() == 0)
									{
										adm_msg = "Current Max Spg Qty = " + m_MaxSpgQty;
									}
									else
									{
										adm_msg = "Parameter error, or not be more then 100!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/spawn": //in progress
								{
									if ( cData.Length() > 1 && !cData.Contains("  "))
									{
										cCmdParams = new array<string>;
										string object_Name;
										EntityAI item_Spawn;
										vector item_Pos, spawn_Pos, spawn_Orient;
										cData.Split(" ",cCmdParams);
										Print("::: [AdminMod_Class] ::: /spawn ::: cData = '" + cData + "', cData.Length() = " + cData.Length().ToString());
										Print("::: [AdminMod_Class] ::: /spawn ::: cCmdParams.Count() = " + cCmdParams.Count().ToString());
										object_Name = cCmdParams.Get(0);
										spawn_Orient = AdminPlayer.GetOrientation();
										//Current pos
										if (cCmdParams.Count() == 1)
										{
											spawn_Pos = AdminPlayer.GetPosition();
											spawn_Pos[0] = spawn_Pos[0] + 1.5;
											//spawn_Pos[1] = 0;
											spawn_Pos[2] = spawn_Pos[2] + 1.5;
											item_Pos = spawn_Pos;
										}
										//Only Alt
										else if (cCmdParams.Count() == 2)
										{
											spawn_Pos = AdminPlayer.GetPosition();
											spawn_Pos[0] = spawn_Pos[0] + 1.5;
											spawn_Pos[1] = cCmdParams.Get(1).ToFloat();
											spawn_Pos[2] = spawn_Pos[2] + 1.5;
											item_Pos = SnapToGround(spawn_Pos);
										}
										//Specified pos
										else if (cCmdParams.Count() == 4)
										{
												spawn_Pos = (cCmdParams.Get(1) + " " + cCmdParams.Get(2) + " " + cCmdParams.Get(3)).ToVector();
												item_Pos = spawn_Pos;
										}
										if (item_Pos)
										{
											m_SpawnedObject = GetGame().CreateObject(object_Name, item_Pos);
											item_Spawn = EntityAI.Cast(m_SpawnedObject);
											if (m_SpawnedObject)
											{
												if (spawn_Pos[1] <= 0)
												{
													m_SpawnedObject.PlaceOnSurface();
													Print("::: [AdminMod_Class] ::: /spawn ::: " + m_SpawnedObject.GetType() + ".PlaceOnSurface() :::");
												}
												m_SpawnedObject.SetPosition(item_Pos);
												m_SpawnedObject.SetOrientation(spawn_Orient);
												ResetCollision(m_SpawnedObject);
												if (item_Spawn.IsBuilding())
												{
													BuildingDoors(item_Spawn, true, false);
												}
												adm_msg  = "Object " + object_Name + " Spawned: " + VectorToVectorString(m_SpawnedObject.GetPosition());
												adm_msg1 = "Object ori: " + VectorToVectorString(m_SpawnedObject.GetOrientation());
												adm_msg2 = "Object dir: " + VectorToVectorString(m_SpawnedObject.GetDirection());
												Print("::: [AdminMod_Class] ::: /spawn ::: m_SpawnedObject = " + m_SpawnedObject.GetType() + " => Req Pos: " + VectorToVectorString(item_Pos) + ", Current Pos: " + VectorToVectorString(m_SpawnedObject.GetPosition()));
											}
											else
											{
												adm_msg = "Object " + object_Name + " Failed!";
												Print("::: [AdminMod_Class] ::: /spawn ::: Failed!");
											}
										}
										else
										{
											adm_msg = "Parameter error!";
										}
									cCmdParams.Clear();
									}
									else
									{
										adm_msg = "Command error!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									if (adm_msg1 && adm_msg2)
									{
										Msgparam = new Param1<string>( adm_msg1 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										Msgparam = new Param1<string>( adm_msg2 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
								break;
								}
								//spawn cars commands begin
								case "/spawnhatchback":
								case "/spawncar":
								{
									if (cData.Length() > 4 && cData.ToVector())
									{
										SpawnHatchback(cData.ToVector(), "0.0 0.0 0.0");
									}
									else
									{
										SpawnHatchback(AdminPlayer.GetPosition(), AdminPlayer.GetOrientation());	
									}
									
								break;
								}
								case "/spawnsedan":
								{
									if (cData.Length() > 4 && cData.ToVector())
									{
										SpawnSedan(cData.ToVector(), "0.0 0.0 0.0");
									}
									else
									{
										SpawnSedan(AdminPlayer.GetPosition(), AdminPlayer.GetOrientation());	
									}
									
								break;
								}
								case "/spawnv3s":
								case "/spawntruck":
								{
									if (cData.Length() > 4 && cData.ToVector())
									{
										SpawnV3S(cData.ToVector(), "0.0 0.0 0.0");
									}
									else
									{
										SpawnV3S(AdminPlayer.GetPosition(), AdminPlayer.GetOrientation());	
									}
									
								break;
								}
								case "/refuel": 
								{
									refuelCar(cData);
								break;
								}
								//spawn cars commands end
								
								case "/water":
								{
									if ((cData == "del" || cData == "delete" || cData == "remove" || MyWaterPump) && cData != "new")
									{
										GetGame().ObjectDelete(MyWaterPump);
										adm_msg = "Water pump Deleted!";
									}
									else
									{
										position[0] = AdminPosition[0] + 1.1;
										position[1] = AdminPosition[1] + 0.001;
										position[2] = AdminPosition[2] + 1.1;
										MyWaterPump = GetGame().CreateObject("Land_Misc_Well_Pump_Blue", position);
										MyWaterPump.SetPosition(position);
										ResetCollision(MyWaterPump);
										if (MyWaterPump)
										{
											adm_msg = "Water pump Spawned!";
										}
										else
										{
											adm_msg = "Water pump error!";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- SPAWN:OBJECTS ----//

								//---- SPAWNED:OBJECTS ----//
								case "/objdel":
								{
									spawnedObjectDelete(m_SpawnedObject);
								break;
								}
								case "/objpos":
								{
									spawnedObjectSetPosition(m_SpawnedObject, cData);
								break;
								}
								case "/objori":
								{
									spawnedObjectSetOrientation(m_SpawnedObject, cData);
								break;
								}
								case "/objdir":
								{
									spawnedObjectSetDirection(m_SpawnedObject, cData);
								break;
								}
								case "/objheal":
								case "/objhealth":
								{
									spawnedObjectSetHealth(m_SpawnedObject, cData);
								break;
								}
								case "/objdamag": 
								case "/objdamage": // false | off // no params = true
								{
									spawnedObjectSetAllowDamage(m_SpawnedObject, cData);
								break;
								}
								case "/objinfo":
								{
									spawnedObjectGetInfo(m_SpawnedObject);
								break;
								}
								case "/objgrav":
								case "/objgravity":
								{
									spawnedObjectGravity(m_SpawnedObject, cData);
								break;
								}
								//teleporting
								case "/objtpto":
								{
									spawnedObjectTPTO(m_SpawnedObject, cData);
								break;
								}
								case "/objtpp":
								{
									spawnedObjectTPP(m_SpawnedObject, cData);
								break;
								}
								//---- SPAWNED:OBJECTS ----//

								//---- FREECAM:SPECTATOR ----//
								case "/testcam":
								{
									if (m_FreeCamera || m_Spectator) 
									{
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										break;
									}
									if (m_TestCamera || cData == "exit")
									{
										GetGame().SelectPlayer(AdminPlayer.GetIdentity(), AdminPlayer);
										SetPlayerFreeze(false, AdminPlayer);
										m_TestCamera = false;
										adm_msg = "Exiting TestCam!";
									}
									else
									{
										string o_TestCamera = o_SpectatorCamera;
										if (cData.Length() > 0) o_TestCamera = cData;
										SetPlayerFreeze(true, AdminPlayer);
										camPosition = AdminPlayer.GetPosition();
										camPosition[0] = camPosition[0] - 1;
										camPosition[1] = camPosition[1] + 3;
										camPosition[2] = camPosition[2] - 1;
										GetGame().SelectPlayer(AdminPlayer.GetIdentity(), NULL);
										GetGame().SelectSpectator(AdminPlayer.GetIdentity(), o_TestCamera, camPosition);
										m_TestCamera = true;
										adm_msg = "TestCam Ready!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/freecam":
								{
									if (m_Spectator || m_TestCamera)
									{
										if (m_TestCamera) adm_msg = "Please exit TestCam !!!";
										if (m_Spectator) adm_msg = "Please exit spectator !!!";
									}
									else
									{
										if (m_FreeCamera || cData == "exit")
										{
											AdminPlayerHide(false,"",NULL);
											GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(AdminHoldPosition);
											if (m_AdminInitPos) AdminPlayer.SetPosition(m_AdminInitPos);
											GetGame().SelectPlayer(AdminIdentity, AdminPlayer);
											dBodyEnableGravity(AdminEntity,true);
											dBodySetMass(AdminEntity,m_AdminBodyMass);
											ResetCollision(Object.Cast(selectedPlayer));
											AdminPlayer.SetSynchDirty();
											SetPlayerFreeze(false, AdminPlayer);
											m_FreeCamera = false;
											adm_msg = "Exiting FreeCam!";
										}
										else
										{
											SetPlayerFreeze(true, AdminPlayer);
											m_AdminInitPos = AdminPlayer.GetPosition();
											camPosition = m_AdminInitPos;
											camPosition[0] = camPosition[0] - 1;
											camPosition[1] = camPosition[1] + 3;
											camPosition[2] = camPosition[2] - 1;
											dBodyEnableGravity(AdminEntity,false);
											dBodySetMass(AdminEntity, 0.1);
											GetGame().SelectPlayer(AdminIdentity, NULL);
											GetGame().SelectSpectator(AdminIdentity, o_SpectatorCamera, camPosition);
											m_FreeCamera = true;
											//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(AdminPlayerHide, 1000, false, true, "", NULL);
											AdminPlayerHide(true, "", NULL);
											adm_msg = "FreeCam ready!";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/spectator": //in progress
								{
									if (m_FreeCamera || m_TestCamera)
									{
										if (m_TestCamera) adm_msg = "Please exit TestCam !!!";
										if (m_FreeCamera) adm_msg = "Please exit free camera !!!";
									}
									else
									{
										vector Spec_Position;
										if (m_Spectator || cData == "exit")
										{
											AdminPlayerHide(false,"",NULL);
											GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Remove(AdminHoldPosition);
											if (m_AdminInitPos) AdminPlayer.SetPosition(m_AdminInitPos);
											GetGame().SelectPlayer(AdminIdentity,AdminPlayer);
											dBodyEnableGravity(AdminEntity,true);
											dBodySetMass(AdminEntity, m_AdminBodyMass);
											ResetCollision(Object.Cast(selectedPlayer));
											AdminPlayer.SetSynchDirty();
											SetPlayerFreeze(false, AdminPlayer);
											m_Spectator = false;
											adm_msg = "Exiting Spectator!";
										}
										else
										{
											if (cData.Length() > 0)
											{
												Print("::: [AdminMod_Class] ::: /spectator ::: cData = '" + cData + "'");
												if ( cData.Length() > 4 && cData.IndexOfFrom(1," ") >= 1 && cData.IndexOfFrom(3," ") >=3 && cData.IndexOfFrom(1," ") < cData.IndexOfFrom(cData.IndexOfFrom(1," ") + 2," ") && !cData.Contains("  "))
												{
													//Vector
													Spec_Position = cData.ToVector();
													Target = NULL;
													Print("::: [AdminMod_Class] ::: /spectator ::: Spec_Position = '" + cData.ToVector() + "'");
												}
												else
												{
													//Player
													Target = GetTargetPlayer(cData); //NEW VARIANT
													if (Target)
													{
														Spec_Position = Target.GetPosition();
														Print("::: [AdminMod_Class] ::: /spectator ::: Spec_Position = '" + Spec_Position.ToString() + "' Target = " + Target.ToString());
													}
												}
												if ( Spec_Position[0] > 0 && Spec_Position[2] > 0 )
												{
													m_AdminInitPos = AdminPlayer.GetPosition();
													Print("::: [AdminMod_Class] ::: /spectator ::: cData = '" + cData);
													dBodySetMass(AdminEntity, 0.1);
													dBodyEnableGravity(AdminEntity,false);
													SetPlayerFreeze(true, AdminPlayer);
													m_Spectator = true;
													if (Target)
													{
														//Tp to spectator pos
														AdminPlayer.SetAllowDamage(false);
														vector m_TargetTmpPos = Target.GetPosition();
														m_TargetTmpPos[0] = m_TargetTmpPos[0] - 1.5;
														m_TargetTmpPos[2] = m_TargetTmpPos[2] - 1.5;
														m_TargetTmpPos[1] = GetGame().SurfaceY(m_TargetTmpPos[0],m_TargetTmpPos[2]);
														vector m_AdminTmpPos = m_TargetTmpPos;
														m_TargetTmpPos[1] = m_TargetTmpPos[1] - 6;
														m_AdminTmpPos[1] = m_AdminTmpPos[1] + 2;
														//AdminPlayer.SetPosition(m_TargetTmpPos);
														AdminPlayer.SetOrientation(Target.GetOrientation());
														AdminPlayer.SetDirection(Target.GetDirection());
														//AdminPlayer.SetPosition(m_TargetTmpPos);
														//AdminPlayer.SetSynchDirty();
														
														//Create spectator camera
														//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(CreateFreeCam, 1000, false, AdminIdentity, o_SpectatorCamera, VectorToVectorString(m_AdminTmpPos));
														GetGame().SelectSpectator(AdminIdentity, o_SpectatorCamera, Target.GetPosition());
														
														//Hide spectator player
														//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(AdminPlayerHide, 2000, false, true, VectorToVectorString(Spec_Position), Target);
														AdminPlayerHide(true, "", Target);
													}
													else
													{
														//Create spectator camera
														//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(CreateFreeCam, 2000, false, AdminIdentity, o_SpectatorCamera, VectorToVectorString(Spec_Position));
														CreateFreeCam(AdminIdentity, o_SpectatorCamera, VectorToVectorString(Spec_Position));
														
														//Hide spectator player
														//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(AdminPlayerHide, 2000, false, true, VectorToVectorString(Spec_Position), Target);
														AdminPlayerHide(true, "", Target);
													}
													adm_msg = "Spectator: " + VectorToVectorString(Spec_Position);
													Print("::: [AdminMod_Class] ::: /spectator ::: cData = '" + cData + "', Spec_Position = " + Spec_Position.ToString());
												}
												else
												{
													adm_msg = "Target error!!!";
												}
											}
											else
											{
												adm_msg = "Specify target!!!";
											}
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- FREECAM:SPECTATOR ----//
								
								case "/freeze":
								{
									if (m_Freezed)
									{
										SetPlayerFreeze(false, AdminPlayer);
										adm_msg = "Admin UnFreezed!";
									}
									else if (!m_Freezed)
									{
										SetPlayerFreeze(true, AdminPlayer);
										adm_msg = "Admin Freezed!";
									}
									else
									{
										adm_msg = "Freeze error!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								
								//---- HEAL:STATE:STAMINA ----//
								case "/heal": //heal //heal PlayerName //heal UID
								{
									if (cData.Length() > 0)
									{
										GetGame().GetPlayers( players );
										for ( i = 0; i < players.Count(); ++i )
										{
											Target = PlayerBase.Cast(players.Get(i));
											if ( Target.GetIdentity().GetName() == cData || Target.GetIdentity().GetPlainId() == cData  || Target.GetIdentity().GetPlayerId() == cData.ToInt() )
											{
												HealPlayer(Target);
												adm_msg = "Player " + Target.GetIdentity().GetName() + " healed!";
												i = players.Count();
											break;
											}
											else if ( cData == "*" || cData == "all")
											{
												HealPlayer(Target);
												adm_msg = "All players healed!";
											}
										}
									}
									else
									{
										HealPlayer(AdminPlayer);
										adm_msg = "Admin " + AdminPlayer.GetIdentity().GetName() + " healed!";
									}
									Msgparam = new Param1<string>( "Player Healed!" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/godmode": //godmode //godmode PlayerName //godmode UID
								{
									string GodMode;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("GodMode"+Target.GetIdentity().GetPlainId(),GodMode);
											if (GodMode == "true")
											{
												g_Game.SetProfileString("GodMode"+Target.GetIdentity().GetPlainId(),"false");
												Target.SetAllowDamage(true);
												adm_msg = "Player " + Target.GetIdentity().GetName() + " God Mode DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("GodMode"+Target.GetIdentity().GetPlainId(),"true");
												Target.SetAllowDamage(false);
												adm_msg = "Player " + Target.GetIdentity().GetName() + " God Mode ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("GodMode"+AdminUID,GodMode);
										if (GodMode == "true")
										{
											g_Game.SetProfileString("GodMode"+AdminUID,"false");
											AdminPlayer.SetAllowDamage(true);
											adm_msg = "Admin God Mode DISABLED!";
										}
										else
										{
											g_Game.SetProfileString("GodMode"+AdminUID,"true");
											AdminPlayer.SetAllowDamage(false);
											adm_msg = "Admin God Mode ENABLED!";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullstamina":
								{
									string FullStamina;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullStamina"+Target.GetIdentity().GetPlainId(),FullStamina);
											if (FullStamina == "true")
											{
												g_Game.SetProfileString("FullStamina"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Stamina DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullStamina"+Target.GetIdentity().GetPlainId(),"true");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Stamina ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullStamina"+AdminUID,FullStamina);
										if (FullStamina == "true")
										{
											g_Game.SetProfileString("FullStamina"+AdminUID,"false");
											adm_msg = "Admin Full Stamina: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullStamina"+AdminUID,"true");
											adm_msg = "Admin Full Stamina: Enable";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullstate":
								{
									string FullState;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullState"+Target.GetIdentity().GetPlainId(),FullState);
											if (FullState == "true")
											{
												g_Game.SetProfileString("FullState"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full State DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullState"+Target.GetIdentity().GetPlainId(),"true");
												g_Game.SaveProfile();
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full State ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullState"+AdminUID,FullState);
										if (FullState == "true")
										{
											
											g_Game.SetProfileString("FullState"+AdminUID,"false");
											adm_msg = "Admin Full State: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullState"+AdminUID,"true");
											adm_msg = "Admin Full State: Enable";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullhealth":
								{
									string FullHealth;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),FullHealth);
											if (FullHealth == "true")
											{
												g_Game.SetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Health DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),"true");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Health ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullHealth"+AdminUID,FullHealth);
										if (FullHealth == "true")
										{
											g_Game.SetProfileString("FullHealth"+AdminUID,"false");
											adm_msg = "Admin Full Health: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullHealth"+AdminUID,"true");
											adm_msg = "Admin Full Health: Enable";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullhealthloot":
								{
									string FullHealthLoot;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullHealthLoot"+Target.GetIdentity().GetPlainId(),FullHealthLoot);
											if (FullHealthLoot == "true")
											{
												g_Game.SetProfileString("FullHealthLoot"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Health Loot DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullHealthLoot"+Target.GetIdentity().GetPlainId(),"true");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Health Loot ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullHealthLoot"+AdminUID,FullHealthLoot);
										if (FullHealthLoot == "true")
										{
											g_Game.SetProfileString("FullHealthLoot"+AdminUID,"false");
											adm_msg = "Admin Full Health Loot: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullHealthLoot"+AdminUID,"true");
											adm_msg = "Admin Full Health Loot: Enable";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullhealthtweapon":
								{
									string FullHealthWeapon;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullHealthWeapon"+Target.GetIdentity().GetPlainId(),FullHealthWeapon);
											if (FullHealthWeapon == "true")
											{
												g_Game.SetProfileString("FullHealthWeapon"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Health Weapon DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullHealthWeapon"+Target.GetIdentity().GetPlainId(),"true");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Health Weapon ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullHealthWeapon"+AdminUID,FullHealthWeapon);
										if (FullHealthWeapon == "true")
										{
											g_Game.SetProfileString("FullHealthWeapon"+AdminUID,"false");
											adm_msg = "Admin Full Health Weapon: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullHealthWeapon"+AdminUID,"true");
											adm_msg = "Admin Full Health Weapon: Enable";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullammo":
								{
									string FullAmmo;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullAmmo"+Target.GetIdentity().GetPlainId(),FullAmmo);
											if (FullAmmo == "true")
											{
												g_Game.SetProfileString("FullAmmo"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Ammo DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullAmmo"+Target.GetIdentity().GetPlainId(),"true");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Ammo ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullAmmo"+AdminUID,FullAmmo);
										if (FullAmmo == "true")
										{
											g_Game.SetProfileString("FullAmmo"+AdminUID,"false");
											adm_msg = "Admin Full Ammo: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullAmmo"+AdminUID,"true");
											adm_msg = "Admin Full Ammo: Enable";
											Param1<int> params = new Param1<int>(1);
											GetGame().RPCSingleParam(AdminPlayer, ERPCs.DEV_RPC_UNLIMITED_AMMO, params, true);
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/fullstateweapon":
								{
									string FullStateWeapon;
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											g_Game.GetProfileString("FullStateWeapon"+Target.GetIdentity().GetPlainId(),FullStateWeapon);
											if (FullStateWeapon == "true")
											{
												g_Game.SetProfileString("FullStateWeapon"+Target.GetIdentity().GetPlainId(),"false");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Weapon State DISABLED!";
											}
											else
											{
												g_Game.SetProfileString("FullStateWeapon"+Target.GetIdentity().GetPlainId(),"true");
												adm_msg = "Player " + Target.GetIdentity().GetName() + " Full Weapon State ENABLED!";
											}
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
									else
									{
										g_Game.GetProfileString("FullStateWeapon"+AdminUID,FullStateWeapon);
										if (FullStateWeapon == "true")
										{
											g_Game.SetProfileString("FullStateWeapon"+AdminUID,"false");
											adm_msg = "Admin Full Weapon State: Disable";
										}
										else
										{
											g_Game.SetProfileString("FullStateWeapon"+AdminUID,"true");
											adm_msg = "Admin Full Weapon State: Enable";
										}
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullstamina":
								{
									string ServerFullStamina;
									g_Game.GetProfileString("ServerFullStamina",ServerFullStamina);
									if (ServerFullStamina == "true")
									{
										g_Game.SetProfileString("ServerFullStamina","false");
										m_ServerFullStamina = false;
										adm_msg = "Server Full Stamina: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullStamina","true");
										m_ServerFullStamina = true;
										adm_msg = "Server Full Stamina: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullstate":
								{
									string ServerFullState;
									g_Game.GetProfileString("ServerFullState",ServerFullState);
									if (ServerFullState == "true")
									{
										g_Game.SetProfileString("ServerFullState","false");
										m_ServerFullState = false;
										adm_msg = "Server Full State: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullState","true");
										m_ServerFullState = true;
										adm_msg = "Server Full State: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullhealth":
								{
									string ServerFullHealth;
									g_Game.GetProfileString("ServerFullHealth",ServerFullHealth);
									if (ServerFullHealth == "true")
									{
										g_Game.SetProfileString("ServerFullHealth","false");
										m_ServerFullHealth = false;
										adm_msg = "Server Full State: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullHealth","true");
										m_ServerFullHealth = true;
										adm_msg = "Server Full State: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullhealthloot":
								{
									string ServerFullHealthLoot;
									g_Game.GetProfileString("ServerFullHealthLoot",ServerFullHealthLoot);
									if (ServerFullHealthLoot == "true")
									{
										g_Game.SetProfileString("ServerFullHealthLoot","false");
										m_ServerFullHealthLoot = false;
										adm_msg = "Server Full Health Loot: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullHealthLoot","true");
										m_ServerFullHealthLoot = true;
										adm_msg = "Server Full Health Loot: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullhealthweapon":
								{
									string ServerFullHealthWeapon;
									g_Game.GetProfileString("ServerFullHealthWeapon",ServerFullHealthWeapon);
									if (ServerFullHealthWeapon == "true")
									{
										g_Game.SetProfileString("ServerFullHealthWeapon","false");
										m_ServerFullHealthWeapon = false;
										adm_msg = "Server Full Health Weapon: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullHealthWeapon","true");
										m_ServerFullHealthWeapon = true;
										adm_msg = "Server Full Health Weapon: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullammo":
								{
									string ServerFullAmmo;
									g_Game.GetProfileString("ServerFullAmmo",ServerFullAmmo);
									if (ServerFullAmmo == "true")
									{
										g_Game.SetProfileString("ServerFullAmmo","false");
										m_ServerFullAmmo = false;
										adm_msg = "Server Full Ammo: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullAmmo","true");
										m_ServerFullAmmo = true;
										adm_msg = "Server Full Ammo: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/serverfullstateweapon":
								{
									string ServerFullStateWeapon;
									g_Game.GetProfileString("ServerFullStateWeapon",ServerFullStateWeapon);
									if (ServerFullStateWeapon == "true")
									{
										g_Game.SetProfileString("ServerFullStateWeapon","false");
										m_ServerFullStateWeapon = false;
										adm_msg = "Server Full Weapon State: Disable";
									}
									else
									{
										g_Game.SetProfileString("ServerFullStateWeapon","true");
										m_ServerFullStateWeapon = true;
										adm_msg = "Server Full Weapon State: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									g_Game.SaveProfile();
								break;
								}
								case "/ammo": //Admin ammo!
								{
									EntityAI CurrentWeapon = AdminPlayer.GetHumanInventory().GetEntityInHands();
									if( CurrentWeapon )
									{
										CurrentWeapon.SetHealth( CurrentWeapon.GetMaxHealth( "", "" ) );
										Magazine foundMag = Magazine.Cast(CurrentWeapon.GetAttachmentByConfigTypeName( "DefaultMagazine" ));

										if( foundMag && foundMag.IsMagazine())
										{
											foundMag.ServerSetAmmoMax();
										}
										Object Suppressor = ( Object ) CurrentWeapon.GetAttachmentByConfigTypeName( "SuppressorBase" );
										if( Suppressor )
										{
											Suppressor.SetHealth( Suppressor.GetMaxHealth( "", "" ) );
										}
										string displayName = CurrentWeapon.ConfigGetString("displayName");

										Msgparam = new Param1<string>( "Weapon " + displayName + "Reloaded and Repaired" );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
										}
								break;
								}
								//---- HEAL:STATE:STAMINA ----//

								//---- KILL:SUICIDE ----//
								case "/suicide":
								{
									//string FullState, FullHealth;
									g_Game.GetProfileString("FullState"+AdminUID,FullState);
									g_Game.GetProfileString("FullHealth"+AdminUID,FullHealth);
									if (FullState == "true")
									{
										g_Game.SetProfileString("FullState"+AdminUID,"false");
									}
									if (FullHealth == "true")
									{
										g_Game.SetProfileString("FullHealth"+AdminUID,"false");
									}
									AdminPlayer.SetHealth(0);
								break;
								}
								case "/kill":
								{
									if (cData.Length() > 0)
									{
										Target = GetTargetPlayer(cData); //NEW VARIANT
										if (Target)
										{
											//string FullState, FullHealth;
											g_Game.GetProfileString("FullState"+Target.GetIdentity().GetPlainId(),FullState);
											g_Game.GetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),FullHealth);
											if (FullState == "true")
											{
												g_Game.SetProfileString("FullState"+Target.GetIdentity().GetPlainId(),"false");
											}
											if (FullHealth == "true")
											{
												g_Game.SetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),"false");
											}
											Target.SetAllowDamage(true);
											Target.SetHealth(0);
											adm_msg = "Player " + cData + " killed!";
										}
										else
										{
											adm_msg = "Player not found: " + cData;
										}
									}
								break;
								}
								case "/killall": //Excluding admins from AdminsList //If need to kill admin, use /kill command
								{
									GetGame().GetPlayers( players );
									for ( i = 0; i < players.Count(); ++i )
									{
										Target = PlayerBase.Cast(players.Get(i));
										if ( Target != AdminPlayer && !m_AdminsList.Contains(Target.GetIdentity().GetPlainId()) )
										{
											//string FullState, FullHealth;
											g_Game.GetProfileString("FullState"+Target.GetIdentity().GetPlainId(),FullState);
											g_Game.GetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),FullHealth);
											if (FullState == "true")
											{
												g_Game.SetProfileString("FullState"+Target.GetIdentity().GetPlainId(),"false");
											}
											if (FullHealth == "true")
											{
												g_Game.SetProfileString("FullHealth"+Target.GetIdentity().GetPlainId(),"false");
											}
											Target.SetAllowDamage(true);
											Target.SetHealth(0);
										}
									}
								break;
								}
								case "/killzombies":
								{
									if ( cData.Length() == 0 ) cData = maxKillRadius.ToString();
									if ( cData.Length() > 0 && !cData.Contains("  ") )
									{
										/*int*/ radius = cData.ToInt();
										/*array<Object>*/ m_NearestObjectsList = new array<Object>;
										/*array<CargoBase>*/ proxy_cargos = new array<CargoBase>;
										//Object object;
										if ((radius > 0 && radius <= maxKillRadius))
										{
											GetGame().GetObjectsAtPosition(AdminPosition, radius, m_NearestObjectsList, proxy_cargos); //ВНИМАНИЕ! БОЛЬШОЙ РАДИУС ГРУЗИТ СЕРВЕР!!!
											for ( i = 0; i < m_NearestObjectsList.Count(); i++ )
											{
												object = m_NearestObjectsList.Get(i);
												if (object.IsKindOf("ZombieBase"))
												{
													EntityAI ZombieAI = EntityAI.Cast(object);
													//Msg1 = "Killed zombie " + i + ": " + ZombieAI.ToString();
													ZombieAI.SetHealth(0);
													//GetGame().ObjectDelete(object);
													//AT_Send_Delayed_Message(AdminPlayer, Msg1, ((msgDelay * i) + i), 1);
													//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(GetGame().ObjectDelete, ((i * 2) * 1200) * 2, false, object)
												}
											}
										}
										else
										{
										Msgparam = new Param1<string>("Parameter error!");
										}
									}
									else
									{
										Msgparam = new Param1<string>("Command error!");
									}
									if (Msgparam) GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/killanimals":
								{
									if ( cData.Length() == 0 ) cData = maxKillRadius.ToString();
									if ( cData.Length() > 0 && !cData.Contains("  ") )
									{
										/*int*/ radius = cData.ToInt();
										/*array<Object>*/ m_NearestObjectsList = new array<Object>;
										/*array<CargoBase>*/ proxy_cargos = new array<CargoBase>;
										//Object object;
										if ((radius > 0 && radius <= maxKillRadius))
										{
											GetGame().GetObjectsAtPosition(AdminPosition, radius, m_NearestObjectsList, proxy_cargos); //ВНИМАНИЕ! БОЛЬШОЙ РАДИУС ГРУЗИТ СЕРВЕР!!!
											for ( i = 0; i < m_NearestObjectsList.Count(); i++ )
											{
												object = m_NearestObjectsList.Get(i);
												if (object.IsKindOf("AnimalBase"))
												{
													EntityAI AnimalAI = EntityAI.Cast(object);
													Msg1 = "Killed animal " + i + ": " + AnimalAI.ToString();
													AnimalAI.SetHealth(0);
													//GetGame().ObjectDelete(object);
													//AT_Send_Delayed_Message(AdminPlayer, Msg1, ((msgDelay * i) + i), 1);
													//GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(GetGame().ObjectDelete, ((i * 2) * 1200) * 2, false, object)
												}
											}
										}
										else
										{
										Msgparam = new Param1<string>("Parameter error!");
										}
									}
									else
									{
										Msgparam = new Param1<string>("Command error!");
									}
									if (Msgparam) GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- KILL:SUICIDE ----//

								//---- DEBUG ----//
								case "/adminfuncdebug": //by default admFuncDebug = false;
								{
									if (admFuncDebug)
									{
										admFuncDebug = false;
										adm_msg = "Admin functions debug Disabled!" ;
									}
									else
									{
										admFuncDebug = true;
										adm_msg = "Admin functions debug Enabled!" ;
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/debug":
								{
									if (m_IsDebugRunning)
									{
										m_IsDebugRunning = false;
										GetGame().SetDebugMonitorEnabled(0);
										adm_msg = "Debug\Status Monitor Disabled!" ;
									}
									else
									{
										m_IsDebugRunning = true;
										GetGame().SetDebugMonitorEnabled(1);
										adm_msg = "Debug\Status Monitor Enabled!" ;
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- DEBUG ----//

								/*
								//---- AIRDROP:AIRMOVE ----//
								case "/airmove": //Test //Use only if user AirMove
								{
									cCmdParams = new array<string>;

									if ( cData.Length() < 1 )
									{
										if (AirMoveClass.m_AirPlane && AirMoveClass.AirPlaneFly)
										{
											adm_msg = "AirMove: Flying AirPlane exist";
										}
										else
										{
											adm_msg = "AirMove: Flying AirPlane not exist";
										}

										if (m_AirMove_Enable)
										{
											adm_msg0 = "AirMove: Started";
										}
										else if (!m_AirMove_Enable)
										{
											adm_msg0 = "AirMove: Stopped";
										}
									}
									else
									{
										adm_msg = "Parameter error!"; //Default
										if ( cData.Length() > 1 && !cData.Contains("  ") )
										{
											cData.Split(" ", cCmdParams);
										
											if (cCmdParams.Count() == 1)
											{
												switch (cData)
												{
													case "stop":
													{
														m_AirMove_Enable = false;
														AirMoveClass.EnableAirMoves = false;
														adm_msg = "AirMove: Stop";
													break;
													}
													case "start":
													{
														m_AirMove_Enable = true;
														AirMoveClass.EnableAirMoves = true;
														adm_msg = "AirMove: Start";
													break;
													}
													case "speed":
													{
														adm_msg = "AirMove: AirPlane speed: " + AirMoveClass.AirPlaneSpeed;
													break;
													}
													case "tpc":
													{
														if (AirMoveClass.m_AirPlane)
														{
															SavePosToProfile(VectorToVectorString(AdminPosition), AdminUID);
															vector AirPlaneTpc = AirMoveClass.m_AirPlane.GetPosition();
															AirPlaneTpc[1] = AirPlaneTpc[1] + 1;
															AdminPlayer.SetPosition(AirPlaneTpc);
															adm_msg = "AirMove: Teleport to AirPlane!";
															adm_msg0 = "Pos: " + AirPlaneTpc.ToString();
														}
														else
														{
															adm_msg = "AirMove: Teleport to AirPlane failed!";
														}
													break;
													}
													default:
													{
													break;
													}
												}
											}
											else if (cCmdParams.Count() == 2)
											{
												switch (cCmdParams.Get(0))
												{
													case "speed":
													{
														adm_msg = "AirMove: AirPlane speed: " + AirMoveClass.AirPlaneSpeed;
														AirMoveClass.AirPlaneSpeed = cCmdParams.Get(1).ToFloat();
														adm_msg0 = "AirMove: New AirPlane speed: " + AirMoveClass.AirPlaneSpeed;
													break;
													}
													case "speedup":
													{
														adm_msg = "AirMove: AirPlane speed: " + AirMoveClass.AirPlaneSpeed;
														AirMoveClass.AirPlaneSpeed = AirMoveClass.AirPlaneSpeed + cCmdParams.Get(1).ToFloat();
														adm_msg0 = "AirMove: New AirPlane speed: " + AirMoveClass.AirPlaneSpeed;
													break;
													}
													default:
													{
													break;
													}
												}
											}
											else if (cCmdParams.Count() == 3)
											{
												adm_msg2 = "Command have 3 parameters";
											}
											else if (cCmdParams.Count() == 4)
											{
												adm_msg2 = "Command have 4 parameters";
											}
											else if (cCmdParams.Count() == 5)
											{
												adm_msg2 = "Command have 5 parameters";
											}
											adm_msg3 = "Command have " + cCmdParams.Count() + " params";
										}
									}

									if (adm_msg)
									{
										Msgparam = new Param1<string>( adm_msg );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
									if (adm_msg0)
									{
										Msgparam = new Param1<string>( adm_msg0 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
									if (adm_msg1)
									{
										Msgparam = new Param1<string>( adm_msg1 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
									if (adm_msg2)
									{
										Msgparam = new Param1<string>( adm_msg2 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
									if (adm_msg3)
									{
										Msgparam = new Param1<string>( adm_msg3 );
										GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									}
									cCmdParams.Clear();
								break;
								}
								//#endif //End check defined class
								//---- AIRDROP:AIRMOVE ----//
								*/
								
								//---- SERVER:PARTICLES ----//
								case "/grenade": //in progress
								{
									//
										cCmdParams = new array<string>;
										string particle_Name;
										EntityAI particle_Effect;
										vector particle_Pos;
										cData.Split(" ",cCmdParams);
										//Current pos
										if (cCmdParams.Count() == 0)
										{
											particle_Pos = AdminPlayer.GetPosition();
											particle_Pos[0] = particle_Pos[0] + 1.5;
											particle_Pos[1] = 35; //35 meters !!!
											particle_Pos[2] = particle_Pos[2] + 1.5;
										}
										//Current pos with alt
										else if (cCmdParams.Count() == 1)
										{
											particle_Pos = AdminPlayer.GetPosition();
											particle_Pos[0] = particle_Pos[0] + 1.5;
											particle_Pos[1] = cCmdParams.Get(0).ToFloat();
											particle_Pos[2] = particle_Pos[2] + 1.5;
										}
										//Specified pos
										else if (cCmdParams.Count() == 3)
										{
											particle_Pos = (cCmdParams.Get(0) + " " + cCmdParams.Get(1) + " " + cCmdParams.Get(2)).ToVector();
										}
										
										if (particle_Pos)
										{
											particle_Pos = SnapToGround( particle_Pos );
											if ( (vector.Distance(particle_Pos, AdminPlayer.GetPosition())) <= 30 )
											{
												particle_Pos[1] = AdminPlayer.GetPosition()[1] + 30;
											}
											particle_Effect = EntityAI.Cast(GetGame().CreateObject( "RDG2SmokeGrenade_Black", particle_Pos )); 
											particle_Effect.SetOrientation("0 0 0");
											particle_Effect.SetPosition(particle_Pos);
											if (particle_Effect)
											{
												adm_msg = "Grenade effect Spawned: " + VectorToVectorString(particle_Effect.GetPosition());
												Print("::: [AdminMod_Class] ::: /grenade ::: particle_Effect = " + particle_Effect.GetType() + " Req Pos: " + VectorToVectorString(particle_Pos) + ", Current Pos: " + VectorToVectorString(particle_Effect.GetPosition()));
												particle_Effect.GetCompEM().SwitchOn(); 
												particle_Effect.Delete();
											}
											else
											{
												adm_msg = "Grenade effect Failed!";
											}
										}
									//
									cCmdParams.Clear();
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- SERVER:PARTICLES ----//

								//---- SERVER:CONNECTS:WHITELIST:BLACKLIST ----//
								case "/connectnew": //test enable/disable connect new players.
								{
									if (m_connect_new_Enable)
									{
										m_connect_new_Enable = false;
										adm_msg = "Connect new: Disable";
									}
									else
									{
										m_connect_new_Enable = true;
										adm_msg = "Connect new: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/connectany": //test enable/disable connect any players.
								{
									if (m_connect_Enable)
									{
										m_connect_Enable = false;
										adm_msg = "Connect any: Disable";
									}
									else
									{
										m_connect_Enable = true;
										adm_msg = "Connect any: Enable";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- SERVER:CONNECTS:WHITELIST:BLACKLIST ----//

								//---- SERVER:DIAGS ----//
								case "/chattest":
								{
									//at_Send_Chat_Message( NULL, "0: Adm Chat Test", 0); //
									/*
									colorStatusChannel
									colorAction
									colorFriendly
									colorImportant
									*/
									GetGame().ChatPlayer("GetGame().ChatPlayer(): Test");
									GetGame().Chat("GetGame().Chat(): Test colorStatusChannel", "colorStatusChannel");
									GetGame().Chat("GetGame().Chat(): Test colorAction", "colorAction");
									GetGame().Chat("GetGame().Chat(): Test colorFriendly", "colorFriendly");
									GetGame().Chat("GetGame().Chat(): Test colorImportant", "colorImportant");
									GetGame().ChatMP(AdminMan, "GetGame().ChatMP(): Test colorStatusChannel", "colorStatusChannel");
									GetGame().ChatMP(AdminMan, "GetGame().ChatMP(): Test colorAction", "colorAction");
									GetGame().ChatMP(AdminMan, "GetGame().ChatMP(): Test colorFriendly", "colorFriendly");
									GetGame().ChatMP(AdminMan, "GetGame().ChatMP(): Test colorImportant", "colorImportant");
									Msgparam = new Param1<string>( "ERPCs.RPC_USER_ACTION_MESSAGE" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									Msgparam = new Param1<string>( "ERPCs.RPC_USER_ACTION_MESSAGES" );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGES, Msgparam, true, AdminIdentity);
								break;
								}
								case "/qtest":
								{
									ScriptCallQueue queue = GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM);
									int q_SCM_remTime = GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).GetRemainingTime(at_Send_Chat_Message);
									int q_CPM_remTime = GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).GetRemainingTime(CountPlayersMessage);
									
									int q_CFC_remTime = GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).GetRemainingTime(CreateFreeCam);
									int q_APH_remTime = GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).GetRemainingTime(AdminPlayerHide);
									int q_AHP_remTime = GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).GetRemainingTime(AdminHoldPosition);

									Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: /qtest: ScriptCallQueue queue = " + queue.ToString());

									Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: /qtest: q_SCM_remTime (at_Send_Chat_Message) = " + q_SCM_remTime.ToString());
									Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: /qtest: q_CPM_remTime (CountPlayersMessage) = " + q_CPM_remTime.ToString());

									Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: /qtest: q_CFC_remTime (CreateFreeCam) = " + q_CFC_remTime.ToString());
									Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: /qtest: q_APH_remTime (AdminPlayerHide) = " + q_APH_remTime.ToString());
									Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: /qtest: q_AHP_remTime (AdminHoldPosition) = " + q_AHP_remTime.ToString());
								break;
								}
								//---- SERVER:DIAGS ----//

								//---- ADMINTOOL:SETTINGS ----//
								case "/gccd":
								{
									if ( cData.Length() > 0 && !cData.Contains(" "))
									{
										m_GChatClear_delay = cData.ToInt();
										adm_msg = "GlobalChat clear new delay: " + m_GChatClear_delay;
									}
									else if (cData.Length() < 1)
									{
										adm_msg = "GlobalChat clear delay: " + m_GChatClear_delay;
									}
									else
									{
										adm_msg = "Parameter error!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- ADMINTOOL:SETTINGS ----//

								//---- SERVER:SETTINGS ----//
								case "/respawntime":
								{
									if ( cData.Length() > 0 && !cData.Contains(" "))
									{
										respawnTime = cData.ToInt();
										adm_msg = "New respawnTime: " + respawnTime;
									}
									else if (cData.Length() < 1)
									{
										adm_msg = "respawnTime: " + respawnTime;
									}
									else
									{
										adm_msg = "Parameter error!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								case "/spawntime":
								{
									if ( cData.Length() > 0 && !cData.Contains(" "))
									{
										spawnTime = cData.ToInt();
										adm_msg = "New spawnTime: " + spawnTime;
									}
									else if (cData.Length() < 1)
									{
										adm_msg = "spawnTime: " + spawnTime;
									}
									else
									{
										adm_msg = "Parameter error!";
									}
									Msgparam = new Param1<string>( adm_msg );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
								//---- SERVER:SETTINGS ----//

								//---- SERVER:CONTROL ----//
								case "/restart":
								{
									Msgparam = new Param1<string>( "Server restart request." );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									ServerWatchdogScriptRequest("restart",cData);
									player_msg = "Server has been restarted!";

								break;
								}
								case "/shutdown": 
								{
									Msgparam = new Param1<string>( "Server shutdown request." );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									ServerWatchdogScriptRequest("shutdown",cData);
									player_msg = "Server has been shutdown!";
								break;
								}
								case "/machinerestart": 
								{
									Msgparam = new Param1<string>( "Host machine restart request." );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									ServerWatchdogScriptRequest("machinerestart",cData);
									player_msg = "Server host has been restarted!";
								break;
								}
								case "/cancel": 
								{
									Msgparam = new Param1<string>( "Cancel request." );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
									ServerWatchdogScriptRequest("cancel",cData);
									player_msg = "Restart/Shutdown cancelled!";
								break;
								}
								//---- SERVER:CONTROL ----//

								//---- DEFAULT ----//
								default: //No command // Unkonown Command //
								{
									Msgparam = new Param1<string>( "Error: Unknown command." );
									GetGame().RPCSingleParam(AdminPlayer, ERPCs.RPC_USER_ACTION_MESSAGE, Msgparam, true, AdminIdentity);
								break;
								}
							}
							//--------------------------//ADMIN COMMANDs CODE END --//
							GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(GlobalChatClear, m_GChatClear_delay, false); //Clear Global Chat !!! Delay = 3ms !!!
							if (player_msg && selectedPlayer)
							{
								Msgparam = new Param1<string>( player_msg );
								GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(at_Send_Chat_Message, m_GChatClear_delay + 3, false, selectedPlayer, player_msg, 1); //Single player //Channel 1 //MY
							}
							else if (player_msg)
							{
								Msgparam = new Param1<string>( player_msg );
								GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).CallLater(at_Send_Chat_Message, m_GChatClear_delay + 3, false, NULL, player_msg, 0); //Global chat //Channel 0 //MY
							}
							adm_ChatRequestExec = false; // onEvent finish work!
							Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: finish processing command: " + cFullCommand + " ::: adm_ChatRequestExec = " + adm_ChatRequestExec.ToString());
						break;
						}
						else
						{
							Print("::: [AdminMod_Class] ::: ADMIN CHAT EVENT: ChatMessageEventTypeID: Player not in m_AdminsList, UID: " + AdminUID + ", AdminPlayer: " + AdminPlayer.ToString() + ", AdminIdentity: " + AdminIdentity.ToString());
						break;
						}
					//--//
				}
			}
		}
	}
	//Admin chat processing end
	//============================================================================================================================================
}
//ADMIN MOD
